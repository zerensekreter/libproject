import sys
import socket
import threading
import time
import serial

def handle_client(client_socket, ser):
    try:
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            ser.write(data)
    except Exception as e:
        print(f"\n[TCP -> Serial] Baglanti kesildi: {e}")
    finally:
        try:
            client_socket.close()
        except:
            pass

def serial_to_tcp(client_socket, ser):
    try:
        while True:
            if ser.in_waiting > 0:
                data = ser.read(ser.in_waiting)
                client_socket.sendall(data)
            time.sleep(0.01)
    except Exception as e:
        print(f"\n[Serial -> TCP] Baglanti kesildi: {e}")
    finally:
        try:
            client_socket.close()
        except:
            pass

def main():
    port = "COM7"
    baud = 9600
    tcp_port = 9999

    print(f"=== RFID Serial-TCP Bridge ===")
    print(f"Seri port aciliyor: {port} @ {baud}...")
    try:
        ser = serial.Serial(port, baud, timeout=0.1)
    except Exception as e:
        print(f"HATA: Seri port acilamadi: {e}")
        return

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", tcp_port))
    server.listen(1)
    print(f"TCP Sunucu baslatildi, dinleniyor: 0.0.0.0:{tcp_port}")
    print("Baglanti bekleniyor (Docker backend'in baglanmasi icin)...")

    try:
        while True:
            client_socket, addr = server.accept()
            print(f"\nDocker Backend baglandi! IP: {addr}")
            
            t1 = threading.Thread(target=handle_client, args=(client_socket, ser), daemon=True)
            t2 = threading.Thread(target=serial_to_tcp, args=(client_socket, ser), daemon=True)
            t1.start()
            t2.start()
    except KeyboardInterrupt:
        print("\nKöprü kapatiliyor...")
    finally:
        ser.close()
        server.close()

if __name__ == "__main__":
    main()
