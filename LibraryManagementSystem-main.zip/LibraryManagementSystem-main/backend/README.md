# Üniversite Kütüphane Yönetim Sistemi - Backend API

FastAPI ile geliştirilmiş kütüphane yönetim sistemi backend API'si.

## 🚀 Hızlı Başlangıç

### Gereksinimler
- Python 3.11+
- PostgreSQL 15+ (veya Docker)
- pip

### 1. Sanal Ortam Oluştur

```bash
cd backend
python -m venv venv

# Windows
.\venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 2. Bağımlılıkları Yükle

```bash
pip install -r requirements.txt
```

### 3. Veritabanı Kurulumu

#### Seçenek A: Docker ile (Önerilen)
```bash
docker-compose up -d postgres
```

#### Seçenek B: Yerel PostgreSQL
1. PostgreSQL yükleyin
2. Veritabanı oluşturun:
```sql
CREATE DATABASE library_db;
CREATE USER library_user WITH PASSWORD 'library_pass';
GRANT ALL PRIVILEGES ON DATABASE library_db TO library_user;
```

### 4. Ortam Değişkenleri

`.env` dosyasını düzenleyin:
```env
DATABASE_URL=postgresql://library_user:library_pass@localhost:5432/library_db
SECRET_KEY=your-super-secret-key-change-this
```

### 5. Veritabanını Başlat

```bash
# Seed data yükle
python -m app.seed
```

### 6. Sunucuyu Başlat

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## 📚 API Dokümantasyonu

Sunucu çalıştıktan sonra:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🔐 Kimlik Doğrulama

API, JWT (JSON Web Token) tabanlı kimlik doğrulama kullanır.

### Giriş Yapma
```bash
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@library.edu.tr&password=admin123"
```

### Token Kullanma
```bash
curl -X GET "http://localhost:8000/api/users/" \
  -H "Authorization: Bearer <your_token>"
```

## 📁 Proje Yapısı

```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI uygulama başlangıcı
│   ├── config.py        # Ayarlar ve ortam değişkenleri
│   ├── database.py      # SQLAlchemy bağlantısı
│   ├── seed.py          # Örnek veri yükleme
│   ├── models/          # SQLAlchemy modelleri
│   │   ├── user.py
│   │   ├── book.py
│   │   ├── loan.py
│   │   ├── announcement.py
│   │   └── contact.py
│   ├── schemas/         # Pydantic şemaları
│   │   ├── user.py
│   │   ├── book.py
│   │   ├── loan.py
│   │   └── auth.py
│   └── routes/          # API endpoint'leri
│       ├── auth.py
│       ├── users.py
│       ├── books.py
│       ├── loans.py
│       ├── announcements.py
│       ├── contact.py
│       └── admin.py
├── requirements.txt
├── docker-compose.yml
├── Dockerfile
└── .env
```

## 🔑 Varsayılan Kullanıcılar

Seed verisi yüklendikten sonra:

| Email | Şifre | Rol |
|-------|-------|-----|
| admin@library.edu.tr | admin123 | Admin |
| ahmet@university.edu.tr | password123 | Öğrenci |
| prof.ozkan@university.edu.tr | password123 | Öğretim Üyesi |

## 🐳 Docker ile Çalıştırma

```bash
# Tüm servisleri başlat
docker-compose up -d

# Logları görüntüle
docker-compose logs -f backend

# Durdur
docker-compose down
```

### Servisler
- **Backend API**: http://localhost:8000
- **PostgreSQL**: localhost:5432
- **pgAdmin**: http://localhost:5050
  - Email: admin@library.edu.tr
  - Şifre: admin123

## 📝 API Endpoints

### Auth
- `POST /api/auth/register` - Kayıt ol
- `POST /api/auth/login` - Giriş yap
- `POST /api/auth/refresh` - Token yenile
- `GET /api/auth/me` - Profil bilgisi

### Users (Admin)
- `GET /api/users/` - Kullanıcı listesi
- `GET /api/users/lookup/{student_id}` - Öğrenci no ile ara
- `GET /api/users/{id}` - Kullanıcı detayı
- `PUT /api/users/{id}` - Güncelle
- `DELETE /api/users/{id}` - Deaktive et

### Books
- `GET /api/books/` - Kitap listesi (filtreleme destekli)
- `GET /api/books/isbn/{isbn}` - ISBN ile ara
- `GET /api/books/categories` - Kategoriler
- `GET /api/books/{id}` - Kitap detayı
- `POST /api/books/` - Kitap ekle (Admin)
- `PUT /api/books/{id}` - Güncelle (Admin)
- `DELETE /api/books/{id}` - Sil (Admin)

### Loans
- `GET /api/loans/` - Ödünç listesi
- `GET /api/loans/my-loans` - Benim ödünçlerim
- `POST /api/loans/checkout` - Ödünç ver (Admin)
- `POST /api/loans/return` - İade al (Admin)

### Announcements
- `GET /api/announcements/` - Duyuru listesi
- `POST /api/announcements/` - Duyuru ekle (Admin)

### Admin
- `GET /api/admin/status` - Sistem durumu
- `GET /api/admin/metrics` - Dashboard metrikleri
- `GET /api/admin/overdue-loans` - Gecikmiş ödünçler
- `GET /api/admin/due-soon` - Yaklaşan iadeler

## 🛠️ Geliştirme

### Testleri Çalıştır
```bash
pytest
```

### Kod Formatı
```bash
black app/
isort app/
```
