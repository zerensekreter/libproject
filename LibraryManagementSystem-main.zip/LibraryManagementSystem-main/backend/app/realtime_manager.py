from __future__ import annotations

import logging
import time
from typing import Dict, Set

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class RealtimeManager:
    """
    User-scoped realtime event bus.
    Best-practice: push tiny events (invalidate) and let client refetch via REST.
    """

    def __init__(self) -> None:
        # user_id -> set(WebSocket)
        self._user_sockets: Dict[str, Set[WebSocket]] = {}
        # simple in-memory throttle: (user_id, event_type) -> last_sent_ts
        self._last_sent: Dict[str, float] = {}

    async def connect_user(self, user_id: str, ws: WebSocket) -> None:
        await ws.accept()
        s = self._user_sockets.setdefault(user_id, set())
        s.add(ws)
        logger.info("realtime user connected (user_id=%s, conns=%s)", user_id, len(s))

    async def disconnect_user(self, user_id: str, ws: WebSocket) -> None:
        s = self._user_sockets.get(user_id)
        if not s:
            return
        s.discard(ws)
        if not s:
            self._user_sockets.pop(user_id, None)
        logger.info("realtime user disconnected (user_id=%s, conns=%s)", user_id, len(self._user_sockets.get(user_id, set())))

    async def _send(self, user_id: str, payload: dict) -> None:
        s = self._user_sockets.get(user_id)
        if not s:
            return
        dead = []
        for ws in list(s):
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.disconnect_user(user_id, ws)

    async def reco_invalidate(self, user_id: str, reason: str = "signal") -> None:
        """
        Notify client that recommendations should be refetched.
        Throttled to avoid spamming during rapid views.
        """
        now = time.time()
        key = f"{user_id}:reco_invalidate"
        last = self._last_sent.get(key, 0.0)
        # Event-aware throttling: chatty signals (book_view/search) should be throttled harder.
        # Critical signals (borrow approval) should arrive ASAP.
        min_interval = 1.0
        if reason in ("book_view", "search"):
            min_interval = 2.0
        elif reason in ("recommendation_click",):
            min_interval = 1.5
        elif reason.startswith("borrow_request_") or reason.startswith("favorite_"):
            min_interval = 0.25
        if (now - last) < min_interval:
            return
        self._last_sent[key] = now
        await self._send(
            user_id,
            {"type": "reco_invalidate", "reason": reason, "ts": int(now * 1000)},
        )


manager = RealtimeManager()


