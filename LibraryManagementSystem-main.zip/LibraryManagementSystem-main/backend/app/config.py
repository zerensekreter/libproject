from pydantic_settings import BaseSettings
from pydantic import ConfigDict
from functools import lru_cache
from typing import List
import os
import secrets

class Settings(BaseSettings):
    # MongoDB
    mongodb_url: str = "mongodb://localhost:27017"
    database_name: str = "library_db"
    # MongoDB timeouts (ms) - dev'de hızlı fail, prod'da gerekirse artırılabilir
    mongodb_server_selection_timeout_ms: int = int(os.getenv("MONGODB_SERVER_SELECTION_TIMEOUT_MS", "5000"))
    mongodb_connect_timeout_ms: int = int(os.getenv("MONGODB_CONNECT_TIMEOUT_MS", "5000"))
    
    # Server
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    
    # CORS - Production'da spesifik origin'ler gerekli
    cors_origins: List[str] = ["http://localhost:8080", "http://localhost:5173", "http://localhost:3000"]

    # Trusted hosts (anti Host-header attacks). Production'da domain allowlist girin.
    allowed_hosts: List[str] = ["localhost", "127.0.0.1"]

    # Request hardening (DoS mitigation)
    max_request_size_bytes: int = 1_000_000  # 1MB default (auth payloads + JSON için yeterli)
    
    # JWT Security
    # - Production'da ENV zorunlu (validate_secret_key ile fail-fast)
    # - Development'da uvicorn --reload restart'larında token'ların bozulmaması için stabil default kullanılır
    secret_key: str = os.getenv("JWT_SECRET_KEY", "dev-jwt-secret-change-me")
    algorithm: str = "HS256"
    # 3 gün = 4320 dakika (prod'da ENV ile override edilebilir)
    access_token_expire_minutes: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "4320"))
    refresh_token_expire_days: int = 7
    
    # App
    app_name: str = "University Library System"
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"  # Default: False
    environment: str = os.getenv("ENVIRONMENT", "production")  # development, staging, production
    
    # Rate Limiting
    rate_limit_requests: int = 100  # requests per window
    rate_limit_window: int = 60  # seconds
    
    # Security
    min_password_length: int = 8
    max_login_attempts: int = 5
    lockout_duration_minutes: int = 15
    
    # RFID Configuration
    rfid_enabled: bool = os.getenv("RFID_ENABLED", "true").lower() == "true"
    rfid_port: str = os.getenv("RFID_PORT", "COM7")
    rfid_baud_rate: int = int(os.getenv("RFID_BAUD_RATE", "9600"))
    rfid_timeout: float = float(os.getenv("RFID_TIMEOUT", "0.1"))
    rfid_read_wait_timeout: int = int(os.getenv("RFID_READ_WAIT_TIMEOUT", "30"))
    
    # Logging
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    
    model_config = ConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )
    
    def is_production(self) -> bool:
        return self.environment == "production"
    
    def validate_secret_key(self) -> bool:
        """Production'da secret key ENV'den gelmeli (runtime'da fail-fast)."""
        if self.is_production() and not os.getenv("JWT_SECRET_KEY"):
            raise ValueError("JWT_SECRET_KEY production ortamında ENV üzerinden set edilmelidir!")
        return True

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()

