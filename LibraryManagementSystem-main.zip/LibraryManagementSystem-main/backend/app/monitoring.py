"""
OpenTelemetry Monitoring Module for Library System
Provides: Tracing, Metrics (CPU, RAM, Disk), Request Logging, Prometheus Export
"""

import time
import psutil
import logging
from typing import Callable
from functools import wraps
from datetime import datetime
from fastapi import FastAPI, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

# Configure structured logging - use default format to avoid correlation_id issues
# Correlation ID will be added by the filter when available
logger = logging.getLogger(__name__)
# Don't configure logging here - let main.py handle it

# Prometheus Metrics
REQUEST_COUNT = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status_code']
)

REQUEST_LATENCY = Histogram(
    'http_request_duration_seconds',
    'HTTP request latency in seconds',
    ['method', 'endpoint'],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0]
)

ERROR_COUNT = Counter(
    'http_errors_total',
    'Total HTTP errors',
    ['method', 'endpoint', 'error_type']
)

ACTIVE_REQUESTS = Gauge(
    'http_active_requests',
    'Number of active HTTP requests'
)

# System Metrics
CPU_USAGE = Gauge('system_cpu_percent', 'CPU usage percentage')
MEMORY_USAGE = Gauge('system_memory_percent', 'Memory usage percentage')
MEMORY_USED = Gauge('system_memory_used_bytes', 'Memory used in bytes')
MEMORY_TOTAL = Gauge('system_memory_total_bytes', 'Total memory in bytes')
DISK_USED = Gauge('system_disk_used_bytes', 'Disk used in bytes')
DISK_TOTAL = Gauge('system_disk_total_bytes', 'Total disk in bytes')
DISK_PERCENT = Gauge('system_disk_percent', 'Disk usage percentage')

# Database Metrics
DB_OPERATIONS = Counter(
    'db_operations_total',
    'Total database operations',
    ['operation', 'collection']
)

# Active Users Metric
ACTIVE_USERS = Gauge('active_users_count', 'Number of active users')


class CorrelationIdFilter(logging.Filter):
    """Add correlation ID to log records"""
    def __init__(self):
        super().__init__()
        self.correlation_id = "-"
    
    def filter(self, record):
        # Always set correlation_id attribute to avoid KeyError
        record.correlation_id = getattr(record, 'correlation_id', self.correlation_id)
        return True


class MonitoringMiddleware(BaseHTTPMiddleware):
    """Middleware for request monitoring and metrics collection"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Generate correlation ID
        correlation_id = f"{datetime.now().strftime('%Y%m%d%H%M%S')}-{id(request)}"
        request.state.correlation_id = correlation_id
        
        # Start timing
        start_time = time.time()
        ACTIVE_REQUESTS.inc()
        
        # Get endpoint
        endpoint = request.url.path
        method = request.method
        
        # Log request
        logger.info(
            f"Request started: {method} {endpoint}",
            extra={'correlation_id': correlation_id}
        )
        
        try:
            response = await call_next(request)
            
            # Calculate latency
            latency = time.time() - start_time
            
            # Record metrics
            REQUEST_COUNT.labels(
                method=method,
                endpoint=endpoint,
                status_code=response.status_code
            ).inc()
            
            REQUEST_LATENCY.labels(
                method=method,
                endpoint=endpoint
            ).observe(latency)
            
            # Log response
            logger.info(
                f"Request completed: {method} {endpoint} - {response.status_code} - {latency:.3f}s",
                extra={'correlation_id': correlation_id}
            )
            
            # Add correlation ID to response headers
            response.headers['X-Correlation-ID'] = correlation_id
            response.headers['X-Response-Time'] = f"{latency:.3f}s"
            
            return response
            
        except Exception as e:
            latency = time.time() - start_time
            
            ERROR_COUNT.labels(
                method=method,
                endpoint=endpoint,
                error_type=type(e).__name__
            ).inc()
            
            logger.error(
                f"Request failed: {method} {endpoint} - {type(e).__name__}: {str(e)}",
                extra={'correlation_id': correlation_id}
            )
            
            raise
            
        finally:
            ACTIVE_REQUESTS.dec()


def update_system_metrics():
    """Update system metrics (CPU, RAM, Disk)"""
    # CPU
    CPU_USAGE.set(psutil.cpu_percent(interval=None))
    
    # Memory
    memory = psutil.virtual_memory()
    MEMORY_USAGE.set(memory.percent)
    MEMORY_USED.set(memory.used)
    MEMORY_TOTAL.set(memory.total)
    
    # Disk
    disk = psutil.disk_usage('/')
    DISK_USED.set(disk.used)
    DISK_TOTAL.set(disk.total)
    DISK_PERCENT.set(disk.percent)


def track_db_operation(operation: str, collection: str):
    """Track database operation"""
    DB_OPERATIONS.labels(operation=operation, collection=collection).inc()


def set_active_users(count: int):
    """Set active users count"""
    ACTIVE_USERS.set(count)


def get_prometheus_metrics() -> bytes:
    """Generate Prometheus metrics output"""
    update_system_metrics()
    return generate_latest()


def get_system_stats() -> dict:
    """Get current system statistics"""
    import sys
    import platform
    import fastapi
    
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    # Network I/O
    net_io = psutil.net_io_counters()
    
    # Process info
    process = psutil.Process()
    process_create_time = datetime.fromtimestamp(process.create_time())
    uptime_seconds = (datetime.now() - process_create_time).total_seconds()
    
    # Calculate uptime string
    hours, remainder = divmod(int(uptime_seconds), 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours > 0:
        uptime_str = f"{hours}s {minutes}dk {seconds}sn"
    elif minutes > 0:
        uptime_str = f"{minutes}dk {seconds}sn"
    else:
        uptime_str = f"{seconds}sn"
    
    # Get request stats from Prometheus counters
    total_requests = 0
    total_errors = 0
    try:
        for metric in REQUEST_COUNT.collect():
            for sample in metric.samples:
                if sample.name == 'http_requests_total':
                    total_requests += int(sample.value)
        for metric in ERROR_COUNT.collect():
            for sample in metric.samples:
                if sample.name == 'http_errors_total':
                    total_errors += int(sample.value)
    except:
        pass
    
    # Calculate average response time from histogram
    avg_response_time = 0.0
    try:
        total_sum = 0
        total_count = 0
        for metric in REQUEST_LATENCY.collect():
            for sample in metric.samples:
                if sample.name.endswith('_sum'):
                    total_sum += sample.value
                elif sample.name.endswith('_count'):
                    total_count += sample.value
        if total_count > 0:
            avg_response_time = round(total_sum / total_count * 1000, 2)  # Convert to ms
    except:
        pass
    
    return {
        "cpu": {
            "percent": cpu_percent,
            "count": psutil.cpu_count(),
            "count_logical": psutil.cpu_count(logical=True)
        },
        "memory": {
            "total_gb": round(memory.total / (1024**3), 2),
            "used_gb": round(memory.used / (1024**3), 2),
            "available_gb": round(memory.available / (1024**3), 2),
            "percent": memory.percent
        },
        "disk": {
            "total_gb": round(disk.total / (1024**3), 2),
            "used_gb": round(disk.used / (1024**3), 2),
            "free_gb": round(disk.free / (1024**3), 2),
            "percent": disk.percent
        },
        "network": {
            "bytes_sent_mb": round(net_io.bytes_sent / (1024**2), 2),
            "bytes_recv_mb": round(net_io.bytes_recv / (1024**2), 2),
            "packets_sent": net_io.packets_sent,
            "packets_recv": net_io.packets_recv
        },
        "process": {
            "memory_mb": round(process.memory_info().rss / (1024**2), 2),
            "cpu_percent": process.cpu_percent(),
            "threads": process.num_threads(),
            "open_files": len(process.open_files())
        },
        "server": {
            "uptime_seconds": int(uptime_seconds),
            "uptime_str": uptime_str,
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "fastapi_version": fastapi.__version__,
            "platform": platform.system(),
            "hostname": platform.node()
        },
        "requests": {
            "total": total_requests,
            "errors": total_errors,
            "avg_response_ms": avg_response_time
        },
        "timestamp": datetime.now().isoformat()
    }


def setup_monitoring(app: FastAPI):
    """Setup monitoring for FastAPI application"""
    # Add middleware
    app.add_middleware(MonitoringMiddleware)
    
    # Add correlation ID filter to all existing handlers
    # This ensures correlation_id is always available in log records
    correlation_filter = CorrelationIdFilter()
    
    # Get root logger and all its handlers
    root_logger = logging.getLogger()
    for handler in root_logger.handlers:
        # Only add filter if not already added
        if not any(isinstance(f, CorrelationIdFilter) for f in handler.filters):
            handler.addFilter(correlation_filter)
    
    # Also add to module logger
    for handler in logger.handlers:
        if not any(isinstance(f, CorrelationIdFilter) for f in handler.filters):
            handler.addFilter(correlation_filter)
    
    logger.info("Monitoring middleware initialized")
