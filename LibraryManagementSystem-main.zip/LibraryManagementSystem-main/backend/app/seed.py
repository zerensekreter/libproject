"""
Seed script for MongoDB
Run with: python -m app.seed
"""
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
from datetime import datetime

from app.config import settings
from app.models.user import User, UserRole
from app.models.book import Book
from app.models.announcement import Announcement, AnnouncementPriority
from app.models.loan import Loan
from app.models.contact import Contact
from app.security.passwords import hash_password

async def seed_database():
    # Connect to MongoDB
    client = AsyncIOMotorClient(settings.mongodb_url)
    
    await init_beanie(
        database=client[settings.database_name],
        document_models=[User, Book, Loan, Announcement, Contact]
    )
    
    # Check if admin exists
    admin_exists = await User.find_one(User.role == UserRole.ADMIN)
    
    if admin_exists:
        print("Admin already exists!")
        print(f"Admin: {admin_exists.email}")
        return
    
    print("Creating admin user...")
    
    # Create admin only
    admin = User(
        email="admin@library.edu.tr",
        student_id="ADMIN001",
        full_name="Sistem Yöneticisi",
        hashed_password=hash_password("admin123"),
        department="Bilgi İşlem",
        role=UserRole.ADMIN,
        max_books=10
    )
    await admin.insert()
    
    print("✅ Admin created successfully!")
    print("Admin: admin@library.edu.tr / admin123")
    print("")
    print("Artık admin panelinden kitap, kullanıcı ve duyuru ekleyebilirsiniz.")
    
    client.close()

async def clear_database():
    """Clear all collections - use with caution"""
    client = AsyncIOMotorClient(settings.mongodb_url)
    
    await init_beanie(
        database=client[settings.database_name],
        document_models=[User, Book, Loan, Announcement, Contact]
    )
    
    print("Clearing database...")
    await User.delete_all()
    await Book.delete_all()
    await Loan.delete_all()
    await Announcement.delete_all()
    await Contact.delete_all()
    print("✅ Database cleared!")
    
    client.close()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--clear":
        asyncio.run(clear_database())
    else:
        asyncio.run(seed_database())
