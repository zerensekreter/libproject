"""
Password hashing utilities.

Why this exists:
- passlib[bcrypt] has compatibility issues with newer `bcrypt` versions and may fail at runtime.
- bcrypt has a hard 72-byte input limit. Truncating is unsafe (collisions).

Approach:
- Normalize passwords for bcrypt:
  - If <= 72 bytes: use as-is
  - If > 72 bytes: hash with SHA-256 and use the 32-byte digest
"""

from __future__ import annotations

import hashlib
from typing import Final

import bcrypt


_BCRYPT_MAX_BYTES: Final[int] = 72


def _normalize_for_bcrypt(password: str) -> bytes:
    raw = password.encode("utf-8")
    if len(raw) <= _BCRYPT_MAX_BYTES:
        return raw
    # Hash long passwords first to avoid truncation collisions
    return hashlib.sha256(raw).digest()


def hash_password(password: str) -> str:
    normalized = _normalize_for_bcrypt(password)
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(normalized, salt).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    normalized = _normalize_for_bcrypt(password)
    try:
        return bcrypt.checkpw(normalized, password_hash.encode("utf-8"))
    except Exception:
        return False


def dummy_hash() -> None:
    """
    Perform a dummy bcrypt hash to reduce user enumeration timing differences.
    Errors are ignored by design.
    """
    try:
        _ = bcrypt.hashpw(b"dummy_password", bcrypt.gensalt())
    except Exception:
        pass








