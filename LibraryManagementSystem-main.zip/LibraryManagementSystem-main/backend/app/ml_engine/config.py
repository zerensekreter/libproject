import os
from pathlib import Path

class MLEngineConfig:
    # Model Ayarları
    MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    EMBEDDING_DIM = 384  # Seçilen modelin çıktı boyutu sabittir
    
    # Dosya Yolları (Docker Volume içinde kalıcı olacak)
    BASE_DIR = Path(__file__).resolve().parent
    ARTIFACTS_DIR = BASE_DIR / "artifacts"
    
    # Model Çıktıları
    FAISS_INDEX_PATH = ARTIFACTS_DIR / "books.index"
    METADATA_PATH = ARTIFACTS_DIR / "books_metadata.pkl" # ID eşleştirmesi için

    # Eğitim Ayarları
    BATCH_SIZE = 32

    # Re-ranking (quality booster)
    # CrossEncoder reranker dramatically improves relevance for natural-language queries.
    ENABLE_CROSS_RERANK = True
    CROSS_RERANK_TOPK = 30  # rerank topK candidates returned by FAISS
    CROSS_RERANK_WEIGHT = 0.75  # blend: cross_score * w + hybrid_score * (1-w)
    # Multilingual reranker (works better for TR than english-only ms-marco models)
    RERANKER_MODEL_NAME = "cross-encoder/mmarco-mMiniLMv2-L12-H384-v1"

    # Hybrid retrieval (industry standard): BM25-lite + FAISS then fuse (RRF)
    ENABLE_HYBRID_RETRIEVAL = True
    SEMANTIC_FETCH_K = 200
    LEXICAL_FETCH_K = 200
    RRF_K = 60.0
    RRF_LEX_WEIGHT = 1.0  # lexical contribution weight in fusion
    BM25_K1 = 1.2
    BM25_B = 0.75

    # Auto indexing strategy (best practice for this project):
    # - Background retrain with debounce after book create/update/delete
    AUTO_RETRAIN_ON_BOOK_CHANGE = True
    AUTO_RETRAIN_DEBOUNCE_SECONDS = 30.0

    # Recommendation weighting (quality knobs)
    WEIGHT_FAVORITE = 3.0
    WEIGHT_LOAN = 2.0
    WEIGHT_VIEW = 1.0
    WEIGHT_RECOMMENDATION_CLICK = 2.5
    # Pending borrow requests should influence recommendations (user intent signal)
    WEIGHT_BORROW_REQUEST = 2.75

    # Recency decay (half-life, in days). Larger -> slower decay.
    HALF_LIFE_DAYS_FAVORITE = 60.0
    HALF_LIFE_DAYS_LOAN = 45.0
    HALF_LIFE_DAYS_VIEW = 14.0
    HALF_LIFE_DAYS_RECOMMENDATION_CLICK = 21.0
    HALF_LIFE_DAYS_BORROW_REQUEST = 30.0

    # Extra ranking signals
    POPULARITY_BOOST = 0.12  # borrow_count influence (0..~0.12)
    AVAILABILITY_PENALTY = 0.15  # penalize unavailable items in recommendations
    DIVERSITY_CATEGORY_LIMIT = 2  # max items per category in a single recommendation list

    @classmethod
    def ensure_directories(cls):
        """Model dosyalarının kaydedileceği klasörü oluşturur."""
        cls.ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)

# Ayarları dışa aç
settings = MLEngineConfig()
settings.ensure_directories()