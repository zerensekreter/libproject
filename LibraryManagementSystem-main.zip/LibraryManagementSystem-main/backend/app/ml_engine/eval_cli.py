from __future__ import annotations

import argparse
import json
from typing import List

from app.ml_engine.evaluation import EvalCase, evaluate
from app.ml_engine.recommender import search_by_text


def _retriever(query: str, limit: int) -> List[str]:
    hits = search_by_text(query, limit=limit)
    return [h.book_id for h in hits]


def main() -> int:
    p = argparse.ArgumentParser(description="Offline evaluation for search quality (Recall/MRR/nDCG).")
    p.add_argument("--file", required=True, help="JSON file with eval cases")
    p.add_argument("--k", type=int, default=10)
    args = p.parse_args()

    with open(args.file, "r", encoding="utf-8") as f:
        raw = json.load(f)

    cases = [EvalCase(query=o["query"], relevant_ids=list(o.get("relevant_ids", []))) for o in raw]
    res = evaluate(cases=cases, k=args.k, retriever=_retriever)
    print(
        json.dumps(
            {
                "k": res.k,
                "cases": res.cases,
                "recall@k": res.recall_at_k,
                "mrr@k": res.mrr_at_k,
                "ndcg@k": res.ndcg_at_k,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())







