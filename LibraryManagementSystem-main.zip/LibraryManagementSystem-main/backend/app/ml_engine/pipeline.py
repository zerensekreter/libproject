import os
import sys
import pickle
from pathlib import Path
from typing import List, Dict

# macOS OpenMP runtime workaround (faiss/torch/numpy can pull multiple libomp copies).
if sys.platform == "darwin":
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
import anyio

# Proje içi importlar (app. ile başladığına dikkat et)
from app.models.book import Book  # Fixed: book (singular) not books (plural)
from app.ml_engine.config import settings

# --- 1. Sınıf: Metin İşleyici ---
class TextPreprocessor:
    @staticmethod
    def enrich_book_text(book: Book) -> str:
        parts = [
            book.title,
            f"Yazar: {book.author}",
            f"Kategori: {book.category or ''}",
            book.description or ""
        ]
        return " ".join(filter(None, parts)).strip()

# --- 2. Sınıf: Model Yöneticisi (LAZY LOADING FIX) ---
class EmbeddingGenerator:
    def __init__(self):
        # DİKKAT: Burada modeli yüklemiyoruz! None yapıyoruz.
        self.model = None
    
    def _load_model(self):
        """Model sadece ilk ihtiyaç duyulduğunda yüklenir."""
        if self.model is None:
            print(f"🔄 AI Modeli RAM'e yükleniyor: {settings.MODEL_NAME}...")
            self.model = SentenceTransformer(settings.MODEL_NAME)
            print("✅ AI Modeli hazır.")
        return self.model

    def generate_embeddings(self, texts: List[str]) -> np.ndarray:
        # Modeli burada çağırıyoruz
        model = self._load_model()
        return model.encode(texts, batch_size=settings.BATCH_SIZE, show_progress_bar=True)

# --- 3. Sınıf: Vektör Deposu ---
class VectorStoreManager:
    def save_index(self, embeddings: np.ndarray, metadata: List[Dict]):
        # Ensure float32 and cosine-sim ready (L2-normalized + inner product)
        embeddings = np.asarray(embeddings, dtype="float32")
        faiss.normalize_L2(embeddings)

        dimension = embeddings.shape[1]
        index = faiss.IndexFlatIP(dimension)
        index.add(embeddings)
        
        # Klasör yoksa oluşturmayı garantiye alalım
        settings.ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
        
        # Atomic-ish write: write to temp then replace
        index_tmp = Path(str(settings.FAISS_INDEX_PATH) + ".tmp")
        meta_tmp = Path(str(settings.METADATA_PATH) + ".tmp")

        faiss.write_index(index, str(index_tmp))
        with open(meta_tmp, "wb") as f:
            pickle.dump(metadata, f)
            f.flush()
            os.fsync(f.fileno())

        os.replace(index_tmp, settings.FAISS_INDEX_PATH)
        os.replace(meta_tmp, settings.METADATA_PATH)
            
        print(f"✅ İndeks kaydedildi: {len(metadata)} kitap.")

# --- 4. Sınıf: Pipeline Yöneticisi ---
class TrainingPipeline:
    def __init__(self):
        self.preprocessor = TextPreprocessor()
        self.generator = EmbeddingGenerator()
        self.store_manager = VectorStoreManager()

    async def run(self):
        print("🚀 Eğitim süreci tetiklendi...")
        
        # A. Veri Çek
        books = await Book.find_all().to_list()
        if not books:
            print("⚠️ Veritabanı boş! Lütfen önce birkaç kitap ekleyin.")
            return

        print(f"📚 {len(books)} kitap işleniyor...")

        # B. Metin Hazırla
        corpus = []
        metadata = []
        for book in books:
            text = self.preprocessor.enrich_book_text(book)
            corpus.append(text)
            metadata.append({
                "mongo_id": str(book.id),
                "title": book.title,
                "author": book.author,
                "isbn": book.isbn,
                "category": book.category,
                # Keep a short snippet for lexical reranking (do not bloat metadata)
                "description": (book.description[:600] if getattr(book, "description", None) else None),
                "updated_at": (book.updated_at.isoformat() if getattr(book, "updated_at", None) else None),
            })

        # C. Vektörle (Model burada devreye girer)
        # Heavy CPU-bound / ML call -> run in thread to avoid blocking event-loop
        embeddings = await anyio.to_thread.run_sync(self.generator.generate_embeddings, corpus)

        # D. Kaydet
        self.store_manager.save_index(embeddings, metadata)
        print("🎉 AI Eğitimi başarıyla tamamlandı!")

# Singleton instance
training_pipeline = TrainingPipeline()