from __future__ import annotations

"""
Debounced background retraining scheduler.

Best practice for small/medium deployments:
- Don't retrain on every single book change immediately (expensive).
- Debounce changes and retrain once after a short quiet period.
- Keep request latency low (do not block HTTP handlers).

NOTE:
For multi-instance production deployments, move this to a job queue (Celery/RQ/Arq)
or an external workflow system. This module is intentionally lightweight.
"""

import asyncio
import logging
from datetime import datetime, UTC
from typing import Optional

from app.ml_engine.config import settings as ml_settings

logger = logging.getLogger(__name__)

_lock = asyncio.Lock()
_task: Optional[asyncio.Task] = None

_last_run_at: Optional[str] = None
_last_error: Optional[str] = None
_running: bool = False
_next_run_at: Optional[str] = None


async def _run_retrain() -> None:
    from app.ml_engine.pipeline import training_pipeline
    from app.ml_engine.recommender import invalidate_cache

    global _last_run_at, _last_error, _running, _next_run_at
    _running = True
    _last_error = None
    _next_run_at = None
    logger.info("AI retrain started (debounced).")
    await training_pipeline.run()
    invalidate_cache()
    _last_run_at = datetime.now(UTC).isoformat()
    _running = False
    logger.info("AI retrain finished (debounced).")


async def _debounced_worker(delay_seconds: float) -> None:
    try:
        await asyncio.sleep(delay_seconds)
        await _run_retrain()
    except asyncio.CancelledError:
        # expected when a new change reschedules the job
        return
    except Exception as e:
        global _last_error, _running
        _running = False
        _last_error = str(e)
        logger.exception("AI retrain failed in scheduler: %s", e)


async def schedule_retrain(*, reason: str = "book_changed") -> None:
    """
    Schedule a retrain after a debounce delay.
    Multiple calls within the debounce window collapse into one execution.
    """
    if not getattr(ml_settings, "AUTO_RETRAIN_ON_BOOK_CHANGE", False):
        return

    delay = float(getattr(ml_settings, "AUTO_RETRAIN_DEBOUNCE_SECONDS", 30.0))
    global _task
    global _next_run_at

    async with _lock:
        if _task and not _task.done():
            _task.cancel()
        _task = asyncio.create_task(_debounced_worker(delay))
        _next_run_at = (datetime.now(UTC)).isoformat()

    logger.info("AI retrain scheduled in %.1fs (reason=%s)", delay, reason)


def get_scheduler_status() -> dict:
    """
    Lightweight status for admin/ops dashboards.
    """
    enabled = bool(getattr(ml_settings, "AUTO_RETRAIN_ON_BOOK_CHANGE", False))
    delay = float(getattr(ml_settings, "AUTO_RETRAIN_DEBOUNCE_SECONDS", 30.0))
    scheduled = bool(_task and not _task.done())
    return {
        "enabled": enabled,
        "debounce_seconds": delay,
        "scheduled": scheduled,
        "running": _running,
        "next_run_at": _next_run_at,
        "last_run_at": _last_run_at,
        "last_error": _last_error,
    }


