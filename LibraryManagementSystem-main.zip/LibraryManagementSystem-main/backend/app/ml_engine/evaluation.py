from __future__ import annotations

"""
Offline evaluation utilities for search/recommendation quality.

Why:
- "Ultra doğruluk" ancak ölçülürse sürdürülebilir.
- Bu modül prod koduna bağımlı olmadan (DB/FAISS ayakta olsa da olmasa da)
  query set'leri üzerinden metrik hesaplamayı hedefler.

Input format (JSON):
[
  {
    "query": "yapay zekaya yeni başlayan biri için kitap öner",
    "relevant_ids": ["<mongo_id_1>", "<mongo_id_2>"]
  }
]
"""

from dataclasses import dataclass
from typing import Iterable, List, Sequence


@dataclass(frozen=True)
class EvalCase:
    query: str
    relevant_ids: List[str]


@dataclass(frozen=True)
class EvalResult:
    k: int
    cases: int
    recall_at_k: float
    mrr_at_k: float
    ndcg_at_k: float


def _dcg(rels: Sequence[int]) -> float:
    import math

    s = 0.0
    for i, rel in enumerate(rels, start=1):
        if rel <= 0:
            continue
        s += (2.0**rel - 1.0) / math.log2(i + 1.0)
    return s


def recall_at_k(retrieved: Sequence[str], relevant: Sequence[str], k: int) -> float:
    if k <= 0:
        return 0.0
    rel = set(relevant)
    if not rel:
        return 0.0
    got = 0
    for rid in retrieved[:k]:
        if rid in rel:
            got += 1
    return got / float(len(rel))


def mrr_at_k(retrieved: Sequence[str], relevant: Sequence[str], k: int) -> float:
    if k <= 0:
        return 0.0
    rel = set(relevant)
    if not rel:
        return 0.0
    for i, rid in enumerate(retrieved[:k], start=1):
        if rid in rel:
            return 1.0 / float(i)
    return 0.0


def ndcg_at_k(retrieved: Sequence[str], relevant: Sequence[str], k: int) -> float:
    if k <= 0:
        return 0.0
    rel = set(relevant)
    if not rel:
        return 0.0

    # binary relevance
    rels = [1 if rid in rel else 0 for rid in retrieved[:k]]
    dcg = _dcg(rels)
    ideal = _dcg([1] * min(k, len(rel)))
    return (dcg / ideal) if ideal > 0 else 0.0


def evaluate(
    *,
    cases: Iterable[EvalCase],
    k: int,
    retriever,  # callable: (query: str, limit: int) -> List[str]
) -> EvalResult:
    cases_list = list(cases)
    if not cases_list:
        return EvalResult(k=k, cases=0, recall_at_k=0.0, mrr_at_k=0.0, ndcg_at_k=0.0)

    r_sum = 0.0
    m_sum = 0.0
    n_sum = 0.0

    for c in cases_list:
        retrieved = retriever(c.query, k)
        r_sum += recall_at_k(retrieved, c.relevant_ids, k)
        m_sum += mrr_at_k(retrieved, c.relevant_ids, k)
        n_sum += ndcg_at_k(retrieved, c.relevant_ids, k)

    denom = float(len(cases_list))
    return EvalResult(
        k=k,
        cases=len(cases_list),
        recall_at_k=r_sum / denom,
        mrr_at_k=m_sum / denom,
        ndcg_at_k=n_sum / denom,
    )







