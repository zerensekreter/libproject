from __future__ import annotations

import os
import sys
import pickle
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from app.ml_engine.config import settings as ml_settings

import threading


def _ensure_openmp_compat() -> None:
    """
    macOS: bazı ML bağımlılıkları (faiss / torch / numpy wheel'leri) aynı prosese birden fazla OpenMP runtime (libomp)
    yükleyebilir ve "OMP Error #15" ile süreci düşürebilir.
    Bu, yaygın kullanılan dev-workaround'udur.
    """
    if sys.platform == "darwin":
        os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")


@dataclass(frozen=True)
class SearchHit:
    book_id: str
    score: float


def _normalize_text(s: str) -> str:
    s = (s or "").lower().strip()
    # basic Turkish-friendly folding (keep it simple & dependency-free)
    s = (
        s.replace("İ", "i")
        .replace("I", "i")
        .replace("ı", "i")
        .replace("ş", "s")
        .replace("Ş", "s")
        .replace("ğ", "g")
        .replace("Ğ", "g")
        .replace("ü", "u")
        .replace("Ü", "u")
        .replace("ö", "o")
        .replace("Ö", "o")
        .replace("ç", "c")
        .replace("Ç", "c")
    )
    # punctuation → space
    for ch in r"""!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~""":
        s = s.replace(ch, " ")
    s = " ".join(s.split())
    return s


def _tokens(s: str) -> List[str]:
    s = _normalize_text(s)
    if not s:
        return []
    toks = [t for t in s.split(" ") if len(t) >= 2]
    return toks


class _BM25Lite:
    """
    Dependency-free BM25 implementation for hybrid retrieval.
    Built once from metadata and kept in-memory.
    """

    def __init__(self, *, docs: List[Tuple[str, str]]):
        # docs: (book_id, text)
        from collections import Counter
        import math

        self._math = math
        self._Counter = Counter

        self.N = len(docs)
        self.doc_tokens: Dict[str, Counter] = {}
        self.doc_len: Dict[str, int] = {}
        df: Dict[str, int] = {}

        total_len = 0
        for bid, text in docs:
            toks = _tokens(text)
            c = Counter(toks)
            self.doc_tokens[bid] = c
            dl = sum(c.values())
            self.doc_len[bid] = dl
            total_len += dl
            # document frequency
            for t in c.keys():
                df[t] = df.get(t, 0) + 1

        self.avgdl = (total_len / self.N) if self.N else 0.0
        self.df = df

    def score(self, *, query: str, bid: str) -> float:
        import math

        q = _tokens(query)
        if not q:
            return 0.0

        tf = self.doc_tokens.get(bid)
        if not tf:
            return 0.0

        dl = float(self.doc_len.get(bid, 0))
        if dl <= 0:
            return 0.0

        N = float(self.N)
        avgdl = float(self.avgdl or 1.0)
        k1 = float(getattr(ml_settings, "BM25_K1", 1.2))
        b = float(getattr(ml_settings, "BM25_B", 0.75))

        s = 0.0
        for term in q:
            f = float(tf.get(term, 0))
            if f <= 0:
                continue
            dft = float(self.df.get(term, 0))
            # Okapi BM25 idf (stable variant)
            idf = math.log(1.0 + (N - dft + 0.5) / (dft + 0.5))
            denom = f + k1 * (1.0 - b + b * (dl / avgdl))
            s += idf * (f * (k1 + 1.0) / max(denom, 1e-9))
        return float(s)

    def topk(self, *, query: str, k: int) -> List[SearchHit]:
        if k <= 0 or self.N <= 0:
            return []
        # brute-force over docs; acceptable for small/medium corpora (and cached)
        scored: List[Tuple[float, str]] = []
        for bid in self.doc_tokens.keys():
            s = self.score(query=query, bid=bid)
            if s > 0:
                scored.append((s, bid))
        scored.sort(key=lambda x: x[0], reverse=True)
        # normalize within top list to 0..1
        top = scored[:k]
        if not top:
            return []
        vals = [t[0] for t in top]
        vmin, vmax = min(vals), max(vals)
        rng = max(vmax - vmin, 1e-9)
        return [SearchHit(book_id=bid, score=float((s - vmin) / rng)) for s, bid in top]


def _jaccard(a: List[str], b: List[str]) -> float:
    if not a or not b:
        return 0.0
    sa, sb = set(a), set(b)
    inter = len(sa & sb)
    union = len(sa | sb)
    if union == 0:
        return 0.0
    return inter / union


def _intent_boost(query: str, book_text: str) -> float:
    """
    Intent-aware boosts (simple but very effective):
    - "yeni başlayan / giriş / başlangıç" → boost beginner-friendly titles
    - AI domain keyword alignment → boost titles/categories containing AI keywords
    """
    qn = _normalize_text(query)
    bn = _normalize_text(book_text)

    boost = 0.0

    beginner_markers = ["yeni baslayan", "baslangic", "giris", "intro", "temel", "50 soruda", "rehber"]
    if any(m in qn for m in beginner_markers):
        if any(m in bn for m in ["baslangic", "giris", "temel", "50 soruda", "rehber"]):
            boost += 0.08

    ai_markers = ["yapay zeka", "artificial intelligence", "machine learning", "derin ogrenme", "deep learning", "sinir ag"]
    if any(m in qn for m in ["yapay zeka", "ai", "artificial intelligence"]):
        if any(m in bn for m in ai_markers):
            boost += 0.12

    return boost


def _rerank(
    *,
    query: str,
    hits: List[SearchHit],
    metadata: List[dict],
    limit: int,
) -> List[SearchHit]:
    """
    Two-stage retrieval best-practice:
    1) FAISS semantic retrieval (fast)
    2) Lightweight lexical + intent rerank (quality boost)

    Score is still in [0..1]-ish range; it's NOT a probability.
    """
    if not hits:
        return []

    q_tokens = _tokens(query)
    meta_by_id: Dict[str, dict] = {str(m.get("mongo_id")): m for m in metadata if m.get("mongo_id")}
    rescored: List[Tuple[float, SearchHit]] = []

    for h in hits:
        m = meta_by_id.get(h.book_id)
        if not m:
            rescored.append((h.score, h))
            continue

        book_blob = " ".join(
            [
                str(m.get("title") or ""),
                str(m.get("author") or ""),
                str(m.get("category") or ""),
                str(m.get("description") or ""),
            ]
        )
        b_tokens = _tokens(book_blob)

        lexical = _jaccard(q_tokens, b_tokens)  # 0..1
        boost = _intent_boost(query, book_blob)  # 0..~0.2

        # Blend:
        # - semantic is primary
        # - lexical is secondary
        final = (0.82 * float(h.score)) + (0.18 * float(lexical)) + float(boost)
        rescored.append((final, SearchHit(book_id=h.book_id, score=final)))

    rescored.sort(key=lambda x: x[0], reverse=True)
    reranked = [h for _, h in rescored[: max(limit, int(getattr(ml_settings, "CROSS_RERANK_TOPK", 30)))]]

    # --- Optional CrossEncoder rerank (best-practice) ---
    if getattr(ml_settings, "ENABLE_CROSS_RERANK", True) and len(reranked) >= 2:
        try:
            _ensure_openmp_compat()
            from sentence_transformers import CrossEncoder

            # cache model on module-level
            global _CROSS_ENCODER  # type: ignore[var-annotated]
            global _CROSS_ENCODER_NAME  # type: ignore[var-annotated]
            global _CROSS_LOCK  # type: ignore[var-annotated]
            if "_CROSS_LOCK" not in globals():
                _CROSS_LOCK = threading.Lock()
            name = getattr(ml_settings, "RERANKER_MODEL_NAME", None) or "cross-encoder/mmarco-mMiniLMv2-L12-H384-v1"
            if "_CROSS_ENCODER" not in globals() or globals().get("_CROSS_ENCODER_NAME") != name:
                with _CROSS_LOCK:
                    if "_CROSS_ENCODER" not in globals() or globals().get("_CROSS_ENCODER_NAME") != name:
                        _CROSS_ENCODER = CrossEncoder(name)
                        _CROSS_ENCODER_NAME = name

            pairs = []
            base_scores = []
            for h in reranked:
                m = meta_by_id.get(h.book_id, {})
                doc = " ".join(
                    [
                        str(m.get("title") or ""),
                        str(m.get("author") or ""),
                        str(m.get("category") or ""),
                        str(m.get("description") or ""),
                    ]
                )
                pairs.append((query, doc))
                base_scores.append(float(h.score))

            ce = np.asarray(_CROSS_ENCODER.predict(pairs), dtype="float32")
            # normalize to 0..1 to blend safely
            ce_min = float(ce.min())
            ce_max = float(ce.max())
            ce_rng = max(ce_max - ce_min, 1e-6)
            ce_norm = (ce - ce_min) / ce_rng

            base = np.asarray(base_scores, dtype="float32")
            b_min = float(base.min())
            b_max = float(base.max())
            b_rng = max(b_max - b_min, 1e-6)
            base_norm = (base - b_min) / b_rng

            w = float(getattr(ml_settings, "CROSS_RERANK_WEIGHT", 0.75))
            blended = (w * ce_norm + (1.0 - w) * base_norm).tolist()

            tmp = list(zip(blended, reranked))
            tmp.sort(key=lambda x: x[0], reverse=True)
            reranked = [SearchHit(book_id=h.book_id, score=float(s)) for s, h in tmp]
        except Exception:
            # if reranker isn't available or fails, keep lexical rerank
            pass

    # normalize output scores to 0..1 for interpretability (not a probability)
    if not reranked:
        return []
    scores = np.asarray([h.score for h in reranked], dtype="float32")
    if len(scores) == 1:
        return [SearchHit(book_id=reranked[0].book_id, score=1.0)]
    s_min = float(scores.min())
    s_max = float(scores.max())
    s_rng = max(s_max - s_min, 1e-6)
    out = [SearchHit(book_id=h.book_id, score=float((h.score - s_min) / s_rng)) for h in reranked[:limit]]
    return out


class _LazyArtifacts:
    def __init__(self) -> None:
        self._index = None
        self._metadata: Optional[List[dict]] = None
        self._id_to_pos: Optional[Dict[str, int]] = None
        self._loaded_mtime: Optional[Tuple[float, float]] = None  # (index_mtime, meta_mtime)
        self._bm25: Optional[_BM25Lite] = None

    def is_ready(self) -> bool:
        return ml_settings.FAISS_INDEX_PATH.exists() and ml_settings.METADATA_PATH.exists()

    def _current_mtime(self) -> Optional[Tuple[float, float]]:
        if not self.is_ready():
            return None
        return (
            ml_settings.FAISS_INDEX_PATH.stat().st_mtime,
            ml_settings.METADATA_PATH.stat().st_mtime,
        )

    def clear(self) -> None:
        self._index = None
        self._metadata = None
        self._id_to_pos = None
        self._loaded_mtime = None
        self._bm25 = None

    def load(self) -> None:
        current = self._current_mtime()
        if current is None:
            raise RuntimeError("AI index hazır değil. Önce eğitim (retrain) çalıştırın.")

        # If already loaded and files haven't changed, keep cache
        if (
            self._index is not None
            and self._metadata is not None
            and self._id_to_pos is not None
            and self._loaded_mtime == current
        ):
            return

        # If files changed, reload
        self.clear()

        _ensure_openmp_compat()
        import faiss

        self._index = faiss.read_index(str(ml_settings.FAISS_INDEX_PATH))
        with open(ml_settings.METADATA_PATH, "rb") as f:
            self._metadata = pickle.load(f)

        self._id_to_pos = {}
        for i, m in enumerate(self._metadata):
            bid = m.get("mongo_id")
            if bid:
                # Persisted metadata may store ObjectId or str; normalize to str everywhere.
                self._id_to_pos[str(bid)] = i
        self._loaded_mtime = current

        # Build BM25-lite once for hybrid retrieval
        try:
            docs: List[Tuple[str, str]] = []
            for m in self._metadata:
                bid = str(m.get("mongo_id") or "")
                if not bid:
                    continue
                blob = " ".join(
                    [
                        str(m.get("title") or ""),
                        str(m.get("author") or ""),
                        str(m.get("category") or ""),
                        str(m.get("description") or ""),
                    ]
                )
                docs.append((bid, blob))
            self._bm25 = _BM25Lite(docs=docs)
        except Exception:
            self._bm25 = None

    @property
    def index(self):
        self.load()
        return self._index

    @property
    def metadata(self) -> List[dict]:
        self.load()
        assert self._metadata is not None
        return self._metadata

    @property
    def id_to_pos(self) -> Dict[str, int]:
        self.load()
        assert self._id_to_pos is not None
        return self._id_to_pos

    @property
    def bm25(self) -> Optional[_BM25Lite]:
        self.load()
        return self._bm25


class _LazyEmbedder:
    def __init__(self) -> None:
        self._model = None

    def embed(self, texts: List[str]) -> np.ndarray:
        if self._model is None:
            _ensure_openmp_compat()
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(ml_settings.MODEL_NAME)
        emb = self._model.encode(texts, batch_size=ml_settings.BATCH_SIZE, show_progress_bar=False)
        emb = np.asarray(emb, dtype="float32")
        # normalize for cosine similarity
        _ensure_openmp_compat()
        import faiss

        faiss.normalize_L2(emb)
        return emb


_artifacts = _LazyArtifacts()
_embedder = _LazyEmbedder()

def is_index_available() -> bool:
    """Best-effort check: are artifacts present on disk?"""
    try:
        return _artifacts.is_ready()
    except Exception:
        return False


def is_book_indexed(book_id: str) -> bool:
    """
    Is this Mongo book id present in current FAISS metadata?
    If index isn't ready or can't be loaded, returns False (never raises).
    """
    try:
        return str(book_id) in _artifacts.id_to_pos
    except Exception:
        return False

def invalidate_cache() -> None:
    """Force reload of FAISS index + metadata on next request (used after retrain)."""
    _artifacts.clear()


def search_by_text(query: str, limit: int = 10) -> List[SearchHit]:
    if limit <= 0:
        return []
    q = query.strip()
    if not q:
        return []

    q_emb = _embedder.embed([q])
    index = _artifacts.index
    metadata = _artifacts.metadata

    # Candidate retrieval:
    # - Semantic (FAISS)
    sem_k = int(getattr(ml_settings, "SEMANTIC_FETCH_K", 200))
    sem_k = min(max(sem_k, limit), 300)
    scores, idxs = index.search(q_emb, sem_k)
    semantic: List[SearchHit] = []
    for pos, score in zip(idxs[0].tolist(), scores[0].tolist()):
        if pos < 0:
            continue
        bid = metadata[pos].get("mongo_id")
        if not bid:
            continue
        semantic.append(SearchHit(book_id=str(bid), score=float(score)))

    # - Lexical (BM25-lite)
    lexical: List[SearchHit] = []
    if getattr(ml_settings, "ENABLE_HYBRID_RETRIEVAL", True):
        bm25 = _artifacts.bm25
        if bm25 is not None:
            lex_k = int(getattr(ml_settings, "LEXICAL_FETCH_K", 200))
            lex_k = min(max(lex_k, limit), 300)
            lexical = bm25.topk(query=q, k=lex_k)

    # Fuse with Reciprocal Rank Fusion (RRF)
    if lexical:
        rrf_k = float(getattr(ml_settings, "RRF_K", 60.0))
        lex_w = float(getattr(ml_settings, "RRF_LEX_WEIGHT", 1.0))

        def _rrf(rank: int) -> float:
            return 1.0 / (rrf_k + float(rank))

        fused: Dict[str, float] = {}
        for r, h in enumerate(semantic, start=1):
            fused[h.book_id] = fused.get(h.book_id, 0.0) + _rrf(r)
        for r, h in enumerate(lexical, start=1):
            fused[h.book_id] = fused.get(h.book_id, 0.0) + lex_w * _rrf(r)

        # convert to hits (keep some headroom for rerank)
        cand = sorted(fused.items(), key=lambda x: x[1], reverse=True)[: max(limit * 10, 80)]
        hits = [SearchHit(book_id=bid, score=float(score)) for bid, score in cand]
    else:
        # semantic-only path
        hits = semantic[: max(limit * 10, limit)]

    return _rerank(query=q, hits=hits, metadata=metadata, limit=limit)


def _user_profile_vector(
    *,
    book_ids_weighted: List[Tuple[str, float]],
) -> Optional[np.ndarray]:
    """
    Build a user embedding as weighted average of interacted book vectors.
    Uses FAISS index vectors via reconstruct().
    """
    if not book_ids_weighted:
        return None

    index = _artifacts.index
    id_to_pos = _artifacts.id_to_pos

    vectors: List[np.ndarray] = []
    weights: List[float] = []

    for bid, w in book_ids_weighted:
        pos = id_to_pos.get(bid)
        if pos is None:
            continue
        try:
            v = np.asarray(index.reconstruct(pos), dtype="float32")
        except Exception:
            continue
        vectors.append(v)
        weights.append(float(w))

    if not vectors:
        return None

    mat = np.vstack(vectors)
    w = np.asarray(weights, dtype="float32").reshape(-1, 1)
    profile = (mat * w).sum(axis=0) / max(float(w.sum()), 1e-6)
    profile = profile.reshape(1, -1).astype("float32")

    _ensure_openmp_compat()
    import faiss

    faiss.normalize_L2(profile)
    return profile


async def recommend_for_user(
    *,
    user_id: str,
    limit: int = 10,
    query: Optional[str] = None,
    exclude_book_ids: Optional[List[str]] = None,
) -> List[SearchHit]:
    """
    Hybrid recommender:
    - Build user profile from (favorites + loans + views)
    - Optionally blend with query embedding
    - Search FAISS index
    """
    if limit <= 0:
        return []

    # Import here to keep ml_engine decoupled and avoid circular imports
    from beanie import PydanticObjectId
    from app.models.extras import Favorite
    from app.models.extras import BorrowRequest, BorrowRequestStatus
    from app.models.loan import Loan
    from app.models.interaction import UserEvent, UserEventType
    from app.models.book import Book

    uid = PydanticObjectId(user_id)

    favorites = await Favorite.find(Favorite.user_id == uid).to_list()
    borrow_requests = (
        await BorrowRequest.find(
            BorrowRequest.user_id == uid,
            BorrowRequest.status == BorrowRequestStatus.PENDING,
        )
        .sort(-BorrowRequest.created_at)
        .limit(50)
        .to_list()
    )
    loans = await Loan.find(Loan.user_id == uid).sort(-Loan.created_at).limit(50).to_list()
    views = (
        await UserEvent.find(UserEvent.user_id == uid, UserEvent.event_type == UserEventType.BOOK_VIEW)
        .sort(-UserEvent.created_at)
        .limit(100)
        .to_list()
    )
    rec_clicks = (
        await UserEvent.find(UserEvent.user_id == uid, UserEvent.event_type == UserEventType.RECOMMENDATION_CLICK)
        .sort(-UserEvent.created_at)
        .limit(100)
        .to_list()
    )

    from datetime import datetime, UTC
    import math

    def _decay(created_at: datetime, half_life_days: float) -> float:
        # Exponential decay: weight * 0.5^(age/half_life)
        if half_life_days <= 0:
            return 1.0
        # MongoDB'den timezone-naive datetime gelebilir (eski kayıtlar / farklı driver ayarları).
        # Biz tüm hesaplarda UTC aware kullanıyoruz; bu yüzden burada normalize ediyoruz.
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=UTC)
        age_days = max((datetime.now(UTC) - created_at).total_seconds(), 0.0) / 86400.0
        return math.pow(0.5, age_days / half_life_days)

    # Aggregate per-book weights (more stable + cheaper than duplicating vectors for repeated events)
    by_book: dict[str, float] = {}

    def _add(bid: str, w: float) -> None:
        if not bid:
            return
        by_book[bid] = float(by_book.get(bid, 0.0)) + float(w)

    for f in favorites:
        w = float(getattr(ml_settings, "WEIGHT_FAVORITE", 3.0)) * _decay(
            f.created_at, float(getattr(ml_settings, "HALF_LIFE_DAYS_FAVORITE", 60.0))
        )
        _add(str(f.book_id), w)
    for br in borrow_requests:
        w = float(getattr(ml_settings, "WEIGHT_BORROW_REQUEST", 2.75)) * _decay(
            br.created_at, float(getattr(ml_settings, "HALF_LIFE_DAYS_BORROW_REQUEST", 30.0))
        )
        _add(str(br.book_id), w)
    for l in loans:
        w = float(getattr(ml_settings, "WEIGHT_LOAN", 2.0)) * _decay(
            l.created_at, float(getattr(ml_settings, "HALF_LIFE_DAYS_LOAN", 45.0))
        )
        _add(str(l.book_id), w)
    for v in views:
        if v.book_id:
            w = float(getattr(ml_settings, "WEIGHT_VIEW", 1.0)) * _decay(
                v.created_at, float(getattr(ml_settings, "HALF_LIFE_DAYS_VIEW", 14.0))
            )
            _add(str(v.book_id), w)
    for c in rec_clicks:
        if c.book_id:
            w = float(getattr(ml_settings, "WEIGHT_RECOMMENDATION_CLICK", 2.5)) * _decay(
                c.created_at, float(getattr(ml_settings, "HALF_LIFE_DAYS_RECOMMENDATION_CLICK", 21.0))
            )
            _add(str(c.book_id), w)

    weighted: List[Tuple[str, float]] = list(by_book.items())

    q = (query or "").strip()
    exclude = set(exclude_book_ids or [])

    # CPU-bound part (embeddings + faiss + rerank) → run in threadpool
    import anyio

    hits = await anyio.to_thread.run_sync(
        _recommend_for_user_cpu,
        weighted,
        q,
        exclude,
        int(limit),
    )

    # Post-processing (async): add availability/popularity adjustments + simple diversity
    if not hits:
        return []
    ids = [PydanticObjectId(h.book_id) for h in hits]
    books = await Book.find({"_id": {"$in": ids}}).to_list()
    by_id = {str(b.id): b for b in books}

    pop_boost = float(getattr(ml_settings, "POPULARITY_BOOST", 0.12))
    avail_pen = float(getattr(ml_settings, "AVAILABILITY_PENALTY", 0.15))
    cat_limit = int(getattr(ml_settings, "DIVERSITY_CATEGORY_LIMIT", 2))

    rescored: List[SearchHit] = []
    for h in hits:
        b = by_id.get(h.book_id)
        score = float(h.score)
        if b:
            # popularity: log-scaled
            import math

            score += pop_boost * math.log1p(max(int(getattr(b, "borrow_count", 0)), 0)) / 5.0
            if int(getattr(b, "available_copies", 0)) <= 0:
                score -= avail_pen
        rescored.append(SearchHit(book_id=h.book_id, score=score))

    rescored.sort(key=lambda x: x.score, reverse=True)

    # diversity: limit per category
    out: List[SearchHit] = []
    cat_counts: dict = {}
    for h in rescored:
        b = by_id.get(h.book_id)
        cat = (getattr(b, "category", None) or "Genel") if b else "Genel"
        cnt = cat_counts.get(cat, 0)
        if cnt >= cat_limit:
            continue
        cat_counts[cat] = cnt + 1
        out.append(h)
        if len(out) >= int(limit):
            break

    # normalize to 0..1 for UI
    if not out:
        return []
    sc = np.asarray([h.score for h in out], dtype="float32")
    if len(sc) == 1:
        return [SearchHit(book_id=out[0].book_id, score=1.0)]
    smin = float(sc.min())
    smax = float(sc.max())
    srng = max(smax - smin, 1e-6)
    return [SearchHit(book_id=h.book_id, score=float((h.score - smin) / srng)) for h in out]


def _recommend_for_user_cpu(
    weighted: List[Tuple[str, float]],
    q: str,
    exclude: set,
    limit: int,
) -> List[SearchHit]:
    profile = _user_profile_vector(book_ids_weighted=weighted)
    q_vec = _embedder.embed([q]) if q else None

    if profile is None and q_vec is None:
        return []

    if profile is None:
        final = q_vec
    elif q_vec is None:
        final = profile
    else:
        final = (profile * 0.7 + q_vec * 0.3).astype("float32")
        _ensure_openmp_compat()
        import faiss

        faiss.normalize_L2(final)

    index = _artifacts.index
    metadata = _artifacts.metadata

    fetch_k = min(max(limit * 10, limit), 250)
    scores, idxs = index.search(final, fetch_k)

    hits: List[SearchHit] = []
    for pos, score in zip(idxs[0].tolist(), scores[0].tolist()):
        if pos < 0:
            continue
        bid = str(metadata[pos].get("mongo_id") or "")
        if not bid or bid in exclude:
            continue
        hits.append(SearchHit(book_id=str(bid), score=float(score)))
        if len(hits) >= fetch_k:
            break

    if q:
        return _rerank(query=q, hits=hits, metadata=metadata, limit=limit)

    # normalize
    if not hits:
        return []
    sc = np.asarray([h.score for h in hits], dtype="float32")
    if len(sc) == 1:
        return [SearchHit(book_id=hits[0].book_id, score=1.0)]
    smin = float(sc.min())
    smax = float(sc.max())
    srng = max(smax - smin, 1e-6)
    return [SearchHit(book_id=h.book_id, score=float((h.score - smin) / srng)) for h in hits[:limit]]


