from fastapi import WebSocket
from typing import Dict, List, Set
import json
import logging

logger = logging.getLogger(__name__)


class ConnectionManager:
    """WebSocket bağlantı yöneticisi - Canlı destek için"""
    
    def __init__(self):
        # Kullanıcı bağlantıları: session_id -> WebSocket
        self.user_connections: Dict[str, WebSocket] = {}
        # Admin bağlantıları: user_id -> WebSocket
        self.admin_connections: Dict[str, WebSocket] = {}
        # Hangi admin'lerin online olduğunu takip et
        self.online_admins: Set[str] = set()
        # Yazıyor durumu: session_id -> {"user": bool, "admin": bool}
        self.typing_status: Dict[str, Dict[str, bool]] = {}
    
    async def connect_user(self, session_id: str, websocket: WebSocket):
        """Kullanıcı WebSocket bağlantısını kabul et"""
        await websocket.accept()
        self.user_connections[session_id] = websocket
        self.typing_status[session_id] = {"user": False, "admin": False}
        logger.info(f"User connected to session: {session_id}")
        
        # Admin online durumunu kullanıcıya bildir
        # IMPORTANT: Use the accepted websocket instance directly to avoid races
        # during rapid reconnects (session_id mapping might temporarily point to a different socket).
        try:
            await websocket.send_json({
                "type": "admin_status",
                "online": len(self.online_admins) > 0
            })
        except Exception as e:
            logger.error(f"Error sending initial admin_status to user {session_id}: {e}")
            await self.disconnect_user(session_id)
    
    async def connect_admin(self, admin_id: str, websocket: WebSocket):
        """Admin WebSocket bağlantısını kabul et"""
        await websocket.accept()
        self.admin_connections[admin_id] = websocket
        self.online_admins.add(admin_id)
        logger.info(f"Admin connected: {admin_id}")
        
        # Tüm aktif kullanıcılara admin online bildirimi
        await self.broadcast_admin_status(True)
    
    async def disconnect_user(self, session_id: str):
        """Kullanıcı bağlantısını kapat"""
        if session_id in self.user_connections:
            del self.user_connections[session_id]
            logger.info(f"User disconnected from session: {session_id}")
        if session_id in self.typing_status:
            del self.typing_status[session_id]
    
    async def disconnect_admin(self, admin_id: str):
        """Admin bağlantısını kapat"""
        if admin_id in self.admin_connections:
            del self.admin_connections[admin_id]
            self.online_admins.discard(admin_id)
            logger.info(f"Admin disconnected: {admin_id}")
            
            # Eğer hiç admin kalmadıysa offline bildirimi
            if len(self.online_admins) == 0:
                await self.broadcast_admin_status(False)
    
    async def send_to_user(self, session_id: str, message: dict):
        """Belirli bir oturumdaki kullanıcıya mesaj gönder"""
        if session_id in self.user_connections:
            try:
                await self.user_connections[session_id].send_json(message)
            except Exception as e:
                logger.error(f"Error sending to user {session_id}: {e}")
                await self.disconnect_user(session_id)
    
    async def send_to_admin(self, admin_id: str, message: dict):
        """Belirli bir admin'e mesaj gönder"""
        if admin_id in self.admin_connections:
            try:
                await self.admin_connections[admin_id].send_json(message)
            except Exception as e:
                logger.error(f"Error sending to admin {admin_id}: {e}")
                await self.disconnect_admin(admin_id)
    
    async def broadcast_to_admins(self, message: dict):
        """Tüm admin'lere mesaj gönder"""
        disconnected = []
        for admin_id, websocket in self.admin_connections.items():
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to admin {admin_id}: {e}")
                disconnected.append(admin_id)
        
        # Bağlantısı kopanları temizle
        for admin_id in disconnected:
            await self.disconnect_admin(admin_id)
    
    async def broadcast_admin_status(self, online: bool):
        """Tüm kullanıcılara admin online durumunu bildir"""
        message = {"type": "admin_status", "online": online}
        disconnected = []
        for session_id, websocket in self.user_connections.items():
            try:
                await websocket.send_json(message)
            except Exception:
                disconnected.append(session_id)
        
        for session_id in disconnected:
            await self.disconnect_user(session_id)
    
    async def set_typing(self, session_id: str, sender_type: str, is_typing: bool):
        """Yazıyor durumunu güncelle ve karşı tarafa bildir"""
        if session_id not in self.typing_status:
            self.typing_status[session_id] = {"user": False, "admin": False}
        
        self.typing_status[session_id][sender_type] = is_typing
        
        # Karşı tarafa bildir
        if sender_type == "user":
            # Admin'lere bildir
            await self.broadcast_to_admins({
                "type": "typing",
                "session_id": session_id,
                "is_typing": is_typing
            })
        else:
            # Kullanıcıya bildir
            await self.send_to_user(session_id, {
                "type": "typing",
                "is_typing": is_typing
            })
    
    def is_user_online(self, session_id: str) -> bool:
        """Kullanıcının online olup olmadığını kontrol et"""
        return session_id in self.user_connections
    
    def is_any_admin_online(self) -> bool:
        """Herhangi bir admin'in online olup olmadığını kontrol et"""
        return len(self.online_admins) > 0
    
    def get_online_user_sessions(self) -> List[str]:
        """Online kullanıcıların session ID'lerini döndür"""
        return list(self.user_connections.keys())


# Global connection manager instance
manager = ConnectionManager()
