from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel, EmailStr
from datetime import datetime

from app.models.contact import Contact, ContactStatus
from app.models.user import User
from app.routes.auth import get_admin_user

router = APIRouter()

class ContactCreate(BaseModel):
    name: str
    email: EmailStr
    subject: str
    message: str

class ContactResponse(BaseModel):
    id: str
    name: str
    email: str
    subject: str
    message: str
    status: ContactStatus
    created_at: datetime

@router.post("/", response_model=ContactResponse)
async def create_contact(data: ContactCreate):
    """Submit contact form (public)"""
    contact = Contact(**data.model_dump())
    await contact.insert()
    
    return ContactResponse(
        id=str(contact.id),
        name=contact.name,
        email=contact.email,
        subject=contact.subject,
        message=contact.message,
        status=contact.status,
        created_at=contact.created_at
    )

@router.get("/", response_model=List[ContactResponse])
async def get_contacts(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_admin_user)
):
    """Get all contacts (admin only)"""
    contacts = await Contact.find().sort(-Contact.created_at).skip(skip).limit(limit).to_list()
    
    return [ContactResponse(
        id=str(c.id),
        name=c.name,
        email=c.email,
        subject=c.subject,
        message=c.message,
        status=c.status,
        created_at=c.created_at
    ) for c in contacts]

@router.delete("/{contact_id}")
async def delete_contact(
    contact_id: str,
    current_user: User = Depends(get_admin_user)
):
    """Delete contact (admin only)"""
    contact = await Contact.get(PydanticObjectId(contact_id))
    if not contact:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    await contact.delete()
    return {"message": "Contact deleted"}
