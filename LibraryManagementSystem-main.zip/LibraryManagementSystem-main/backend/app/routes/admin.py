from fastapi import APIRouter, Depends
from datetime import datetime, timedelta, UTC
import pickle

from app.models.user import User
from app.models.book import Book
from app.models.loan import Loan, LoanStatus
from app.routes.auth import get_admin_user

router = APIRouter()

@router.get("/status")
async def get_system_status():
    """Get system health status"""
    return {
        "status": "healthy",
        "database": "MongoDB",
        "timestamp": datetime.now(UTC).isoformat()
    }

@router.get("/metrics")
async def get_dashboard_metrics(current_user: User = Depends(get_admin_user)):
    """Get dashboard metrics (admin only)"""
    # Book stats
    total_books = await Book.count()
    available_books = await Book.find(Book.available_copies > 0).count()
    
    # User stats
    total_users = await User.count()
    active_users = await User.find(User.is_active == True).count()
    
    # Loan stats
    total_loans = await Loan.count()
    active_loans = await Loan.find(Loan.status == LoanStatus.ACTIVE).count()
    overdue_loans = await Loan.find(Loan.status == LoanStatus.OVERDUE).count()
    
    # Popular books
    popular = await Book.find().sort(-Book.borrow_count).limit(5).to_list()
    
    return {
        "books": {
            "total": total_books,
            "available": available_books
        },
        "users": {
            "total": total_users,
            "active": active_users
        },
        "loans": {
            "total": total_loans,
            "active": active_loans,
            "overdue": overdue_loans
        },
        "popular_books": [
            {"id": str(b.id), "title": b.title, "borrow_count": b.borrow_count}
            for b in popular
        ]
    }

@router.get("/overdue-loans")
async def get_overdue_loans(current_user: User = Depends(get_admin_user)):
    """Get all overdue loans"""
    # Update overdue status
    now = datetime.now(UTC)
    await Loan.find(
        Loan.status == LoanStatus.ACTIVE,
        Loan.due_date < now
    ).update({"$set": {"status": LoanStatus.OVERDUE}})
    
    # Get overdue loans
    overdue = await Loan.find(Loan.status == LoanStatus.OVERDUE).to_list()
    
    return [{
        "loan_id": str(l.id),
        "user_name": l.user_name,
        "user_email": l.user_email,
        "book_title": l.book_title,
        "due_date": l.due_date.isoformat(),
        "days_overdue": (now - l.due_date).days,
        "estimated_fine": (now - l.due_date).days * 5.0
    } for l in overdue]


@router.post("/ai/retrain")
async def retrain_ai(current_user: User = Depends(get_admin_user)):
    """
    AI (FAISS index + metadata) eğitimini tetikler.
    Not: Ağır bir iş olabilir; gerekirse ileride background job'a alınabilir.
    """
    # Lazy import to avoid loading faiss/model at startup
    from app.ml_engine.pipeline import training_pipeline
    from app.ml_engine.recommender import invalidate_cache

    await training_pipeline.run()
    invalidate_cache()
    return {"status": "ok", "message": "AI eğitim tamamlandı, index güncellendi."}


@router.get("/ai/status")
async def ai_status(current_user: User = Depends(get_admin_user)):
    """
    Enterprise ops endpoint:
    - FAISS index/metadata dosya durumu
    - index ntotal
    - scheduler status (auto indexing)
    """
    from app.ml_engine.config import settings as ml_settings
    from app.ml_engine.scheduler import get_scheduler_status

    index_path = ml_settings.FAISS_INDEX_PATH
    meta_path = ml_settings.METADATA_PATH

    index_exists = index_path.exists()
    meta_exists = meta_path.exists()

    ntotal = None
    dim = None
    if index_exists:
        try:
            import os
            import sys
            if sys.platform == "darwin":
                os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
            import faiss

            idx = faiss.read_index(str(index_path))
            ntotal = int(idx.ntotal)
            dim = int(idx.d)
        except Exception:
            ntotal = None
            dim = None

    meta_len = None
    if meta_exists:
        try:
            with open(meta_path, "rb") as f:
                meta = pickle.load(f)
            meta_len = int(len(meta))
        except Exception:
            meta_len = None

    return {
        "artifacts": {
            "index": {
                "path": str(index_path),
                "exists": index_exists,
                "mtime": (datetime.fromtimestamp(index_path.stat().st_mtime, UTC).isoformat() if index_exists else None),
                "size_bytes": (int(index_path.stat().st_size) if index_exists else None),
                "ntotal": ntotal,
                "dim": dim,
            },
            "metadata": {
                "path": str(meta_path),
                "exists": meta_exists,
                "mtime": (datetime.fromtimestamp(meta_path.stat().st_mtime, UTC).isoformat() if meta_exists else None),
                "size_bytes": (int(meta_path.stat().st_size) if meta_exists else None),
                "len": meta_len,
            },
        },
        "auto_indexing": get_scheduler_status(),
    }
