from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel, field_validator
from datetime import datetime
import re
import logging

from app.models.book import Book
from app.models.user import User
from app.models.loan import Loan, LoanStatus
from app.routes.auth import get_admin_user

router = APIRouter()
logger = logging.getLogger(__name__)

# Helper function to sanitize regex input
def sanitize_search_input(text: str, max_length: int = 100) -> str:
    """Sanitize input for safe regex usage"""
    if not text:
        return ""
    # Truncate and escape special regex characters
    text = text[:max_length].strip()
    return re.escape(text)

class BookCreate(BaseModel):
    isbn: str
    title: str
    author: str
    publisher: Optional[str] = None
    publish_year: Optional[int] = None
    language: str = "Türkçe"
    category: Optional[str] = None
    dewey_code: Optional[str] = None
    pages: Optional[int] = None
    location: Optional[str] = None
    description: Optional[str] = None
    cover_image: Optional[str] = None
    total_copies: int = 1
    
    @field_validator('isbn')
    @classmethod
    def validate_isbn(cls, v: str) -> str:
        # Remove hyphens and spaces
        v = re.sub(r'[-\s]', '', v)
        if len(v) < 10 or len(v) > 13:
            raise ValueError('ISBN 10-13 karakter arası olmalı')
        if not v.isalnum():
            raise ValueError('ISBN sadece harf ve rakam içerebilir')
        return v
    
    @field_validator('title', 'author')
    @classmethod
    def validate_required_text(cls, v: str) -> str:
        if len(v) < 1 or len(v) > 500:
            raise ValueError('Metin 1-500 karakter arası olmalı')
        return v.strip()
    
    @field_validator('total_copies')
    @classmethod
    def validate_copies(cls, v: int) -> int:
        if v < 1 or v > 1000:
            raise ValueError('Kopya sayısı 1-1000 arası olmalı')
        return v

    @field_validator("total_copies", mode="before")
    @classmethod
    def coerce_total_copies(cls, v):
        # Frontend can send null/"" if input cleared; default safely to 1
        if v is None or v == "":
            return 1
        return v

    @field_validator("publish_year", "pages", mode="before")
    @classmethod
    def coerce_optional_ints(cls, v):
        # Treat empty string as missing
        if v is None or v == "":
            return None
        return v
    
    @field_validator('publish_year')
    @classmethod  
    def validate_year(cls, v: Optional[int]) -> Optional[int]:
        if v is not None:
            if v < 1000 or v > datetime.now().year + 1:
                raise ValueError('Geçersiz yayın yılı')
        return v

class BookResponse(BaseModel):
    id: str
    isbn: str
    title: str
    author: str
    publisher: Optional[str] = None
    publish_year: Optional[int] = None
    language: str
    category: Optional[str] = None
    dewey_code: Optional[str] = None
    pages: Optional[int] = None
    total_copies: int
    available_copies: int
    location: Optional[str] = None
    description: Optional[str] = None
    cover_image: Optional[str] = None
    borrow_count: int

@router.get("/", response_model=List[BookResponse])
async def get_books(
    skip: int = Query(0, ge=0, le=10000),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None, max_length=100),
    category: Optional[str] = Query(None, max_length=100),
    available_only: bool = False
):
    """Get all books with filtering"""
    query = {}
    
    if search:
        # Sanitize search input to prevent NoSQL injection
        safe_search = sanitize_search_input(search)
        query["$or"] = [
            {"title": {"$regex": safe_search, "$options": "i"}},
            {"author": {"$regex": safe_search, "$options": "i"}},
            {"isbn": {"$regex": safe_search, "$options": "i"}}
        ]
    
    if category:
        # Exact match for category (no regex needed)
        query["category"] = sanitize_search_input(category)
    
    if available_only:
        query["available_copies"] = {"$gt": 0}
    
    books = await Book.find(query).skip(skip).limit(limit).to_list()

    
    return [BookResponse(
        id=str(b.id),
        isbn=b.isbn,
        title=b.title,
        author=b.author,
        publisher=b.publisher,
        publish_year=b.publish_year,
        language=b.language,
        category=b.category,
        dewey_code=getattr(b, 'dewey_code', None),
        pages=b.pages,
        total_copies=b.total_copies,
        available_copies=b.available_copies,
        location=b.location,
        description=b.description,
        cover_image=b.cover_image,
        borrow_count=b.borrow_count
    ) for b in books]

@router.get("/isbn/{isbn}", response_model=BookResponse)
async def get_book_by_isbn(isbn: str):
    """Get book by ISBN (for autofill)"""
    book = await Book.find_one(Book.isbn == isbn)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    return BookResponse(
        id=str(book.id),
        isbn=book.isbn,
        title=book.title,
        author=book.author,
        publisher=book.publisher,
        publish_year=book.publish_year,
        language=book.language,
        category=book.category,
        dewey_code=getattr(book, 'dewey_code', None),
        pages=book.pages,
        total_copies=book.total_copies,
        available_copies=book.available_copies,
        location=book.location,
        description=book.description,
        cover_image=book.cover_image,
        borrow_count=book.borrow_count
    )

@router.get("/categories")
async def get_categories():
    """Get all unique categories"""
    books = await Book.find().to_list()
    categories = list(set(b.category for b in books if b.category))
    return categories

@router.get("/{book_id}", response_model=BookResponse)
async def get_book(book_id: str):
    """Get book by ID"""
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    return BookResponse(
        id=str(book.id),
        isbn=book.isbn,
        title=book.title,
        author=book.author,
        publisher=book.publisher,
        publish_year=book.publish_year,
        language=book.language,
        category=book.category,
        dewey_code=getattr(book, 'dewey_code', None),
        pages=book.pages,
        total_copies=book.total_copies,
        available_copies=book.available_copies,
        location=book.location,
        description=book.description,
        cover_image=book.cover_image,
        borrow_count=book.borrow_count
    )

@router.post("/", response_model=BookResponse)
async def create_book(
    book_data: BookCreate,
    current_user: User = Depends(get_admin_user)
):
    """Create a new book (admin only)"""
    # Check if ISBN exists
    if await Book.find_one(Book.isbn == book_data.isbn):
        raise HTTPException(status_code=400, detail="Book with this ISBN already exists")
    
    book = Book(
        **book_data.model_dump(),
        available_copies=book_data.total_copies
    )
    await book.insert()

    # Best-practice for this project: schedule debounced background retrain.
    # This ensures newly created books are indexed shortly after creation.
    try:
        from app.ml_engine.scheduler import schedule_retrain

        await schedule_retrain(reason="book_created")
    except Exception:
        # Never fail the request because AI indexing failed to schedule
        logger.exception("Failed to schedule AI retrain after book creation")
    
    return BookResponse(
        id=str(book.id),
        isbn=book.isbn,
        title=book.title,
        author=book.author,
        publisher=book.publisher,
        publish_year=book.publish_year,
        language=book.language,
        category=book.category,
        dewey_code=getattr(book, 'dewey_code', None),
        pages=book.pages,
        total_copies=book.total_copies,
        available_copies=book.available_copies,
        location=book.location,
        description=book.description,
        cover_image=book.cover_image,
        borrow_count=book.borrow_count
    )

@router.delete("/{book_id}")
async def delete_book(
    book_id: str,
    current_user: User = Depends(get_admin_user)
):
    """Delete a book (admin only)"""
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    # Check active loans
    active_loans = await Loan.find(
        Loan.book_id == book.id,
        Loan.status == LoanStatus.ACTIVE
    ).count()
    
    if active_loans > 0:
        raise HTTPException(status_code=400, detail="Cannot delete book with active loans")
    
    await book.delete()

    try:
        from app.ml_engine.scheduler import schedule_retrain

        await schedule_retrain(reason="book_deleted")
    except Exception:
        logger.exception("Failed to schedule AI retrain after book deletion")
    
    return {"message": "Book deleted successfully"}


class BookUpdate(BaseModel):
    isbn: Optional[str] = None
    title: Optional[str] = None
    author: Optional[str] = None
    publisher: Optional[str] = None
    publish_year: Optional[int] = None
    language: Optional[str] = None
    category: Optional[str] = None
    dewey_code: Optional[str] = None
    pages: Optional[int] = None
    location: Optional[str] = None
    description: Optional[str] = None
    cover_image: Optional[str] = None
    total_copies: Optional[int] = None


@router.put("/{book_id}", response_model=BookResponse)
async def update_book(
    book_id: str,
    update_data: BookUpdate,
    current_user: User = Depends(get_admin_user)
):
    """Update a book (admin only)"""
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    update_dict = update_data.model_dump(exclude_unset=True)
    
    # If updating total_copies, adjust available_copies accordingly
    if "total_copies" in update_dict:
        diff = update_dict["total_copies"] - book.total_copies
        book.available_copies = max(0, book.available_copies + diff)
    
    for key, value in update_dict.items():
        if value is not None:
            setattr(book, key, value)
    
    await book.save()

    try:
        from app.ml_engine.scheduler import schedule_retrain

        await schedule_retrain(reason="book_updated")
    except Exception:
        logger.exception("Failed to schedule AI retrain after book update")
    
    return BookResponse(
        id=str(book.id),
        isbn=book.isbn,
        title=book.title,
        author=book.author,
        publisher=book.publisher,
        publish_year=book.publish_year,
        language=book.language,
        category=book.category,
        dewey_code=getattr(book, 'dewey_code', None),
        pages=book.pages,
        total_copies=book.total_copies,
        available_copies=book.available_copies,
        location=book.location,
        description=book.description,
        cover_image=book.cover_image,
        borrow_count=book.borrow_count
    )

