from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, Query
from typing import List, Optional
from datetime import datetime, UTC
from beanie import PydanticObjectId
from pydantic import BaseModel
from jose import JWTError, jwt
import logging

from app.config import settings
from app.models.user import User, UserRole
from app.models.support import SupportSession, ChatMessage, SessionStatus, SenderType
from app.models.extras import UserNotification
from app.routes.auth import get_current_active_user, get_admin_user
from app.websocket_manager import manager

router = APIRouter()
logger = logging.getLogger(__name__)

# Otomatik karşılama mesajı
WELCOME_MESSAGE = "Merhaba! Size nasıl yardımcı olabilirim? Yetkili en kısa sürede size dönüş yapacaktır."


# Response Models
class SessionResponse(BaseModel):
    id: str
    user_id: str
    user_name: str
    user_email: str
    status: str
    last_message_at: str
    last_message_preview: Optional[str]
    unread_count: int
    user_unread_count: int
    created_at: str
    closed_at: Optional[str]
    is_online: bool = False


class MessageResponse(BaseModel):
    id: str
    session_id: str
    sender_id: Optional[str]
    sender_name: str
    sender_type: str
    content: str
    delivered: bool = False
    is_read: bool
    created_at: str


class SendMessageRequest(BaseModel):
    content: str


# Helper function to verify WebSocket token
async def verify_ws_token(token: str) -> Optional[User]:
    """WebSocket bağlantısı için token doğrulama"""
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        
        if user_id is None or token_type != "access":
            return None
        
        user = await User.get(PydanticObjectId(user_id))
        if user is None or not user.is_active:
            return None
        return user
    except JWTError:
        return None


# REST API Endpoints

@router.post("/sessions", response_model=SessionResponse)
async def create_or_get_session(user: User = Depends(get_current_active_user)):
    """Yeni destek oturumu başlat veya mevcut aktif oturumu döndür"""
    # Mevcut aktif oturum var mı kontrol et
    existing_session = await SupportSession.find_one(
        SupportSession.user_id == user.id,
        SupportSession.status == SessionStatus.ACTIVE
    )
    
    if existing_session:
        return SessionResponse(
            id=str(existing_session.id),
            user_id=str(existing_session.user_id),
            user_name=existing_session.user_name,
            user_email=existing_session.user_email,
            status=existing_session.status.value,
            last_message_at=existing_session.last_message_at.isoformat(),
            last_message_preview=existing_session.last_message_preview,
            unread_count=existing_session.unread_count,
            user_unread_count=existing_session.user_unread_count,
            created_at=existing_session.created_at.isoformat(),
            closed_at=existing_session.closed_at.isoformat() if existing_session.closed_at else None,
            is_online=manager.is_any_admin_online()
        )
    
    # Yeni oturum oluştur
    session = SupportSession(
        user_id=user.id,
        user_name=user.full_name,
        user_email=user.email
    )
    await session.insert()
    
    # Otomatik karşılama mesajı ekle
    welcome_msg = ChatMessage(
        session_id=session.id,
        sender_id=None,
        sender_name="Sistem",
        sender_type=SenderType.SYSTEM,
        content=WELCOME_MESSAGE,
        is_read=False
    )
    await welcome_msg.insert()
    
    # Session'ı güncelle
    session.last_message_preview = WELCOME_MESSAGE[:50] + "..." if len(WELCOME_MESSAGE) > 50 else WELCOME_MESSAGE
    session.user_unread_count = 1
    await session.save()
    
    logger.info(f"New support session created: {session.id} for user: {user.email}")
    
    return SessionResponse(
        id=str(session.id),
        user_id=str(session.user_id),
        user_name=session.user_name,
        user_email=session.user_email,
        status=session.status.value,
        last_message_at=session.last_message_at.isoformat(),
        last_message_preview=session.last_message_preview,
        unread_count=session.unread_count,
        user_unread_count=session.user_unread_count,
        created_at=session.created_at.isoformat(),
        closed_at=None,
        is_online=manager.is_any_admin_online()
    )


@router.get("/sessions", response_model=List[SessionResponse])
async def list_sessions(
    status: Optional[str] = None,
    admin: User = Depends(get_admin_user)
):
    """Admin: Tüm destek oturumlarını listele"""
    query = {}
    if status:
        query["status"] = status
    
    sessions = await SupportSession.find(query).sort("-last_message_at").to_list()
    
    return [
        SessionResponse(
            id=str(s.id),
            user_id=str(s.user_id),
            user_name=s.user_name,
            user_email=s.user_email,
            status=s.status.value,
            last_message_at=s.last_message_at.isoformat(),
            last_message_preview=s.last_message_preview,
            unread_count=s.unread_count,
            user_unread_count=s.user_unread_count,
            created_at=s.created_at.isoformat(),
            closed_at=s.closed_at.isoformat() if s.closed_at else None,
            is_online=manager.is_user_online(str(s.id))
        )
        for s in sessions
    ]


@router.get("/sessions/{session_id}/messages", response_model=List[MessageResponse])
async def get_messages(
    session_id: str,
    skip: int = 0,
    limit: int = 50,
    user: User = Depends(get_current_active_user)
):
    """Oturum mesaj geçmişini getir"""
    session = await SupportSession.get(PydanticObjectId(session_id))
    if not session:
        raise HTTPException(status_code=404, detail="Oturum bulunamadı")
    
    # Yetki kontrolü: Kendi oturumu veya admin
    if session.user_id != user.id and user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Bu oturuma erişim yetkiniz yok")
    
    messages = await ChatMessage.find(
        ChatMessage.session_id == PydanticObjectId(session_id)
    ).sort("created_at").skip(skip).limit(limit).to_list()
    
    # Okundu olarak işaretle
    if user.role == UserRole.ADMIN:
        # Admin mesajları okudu - unread_count sıfırla
        session.unread_count = 0
        await session.save()
        await ChatMessage.find(
            ChatMessage.session_id == PydanticObjectId(session_id),
            {"sender_type": SenderType.USER.value},
            ChatMessage.is_read == False
        ).update({"$set": {"is_read": True}})
    else:
        # Kullanıcı mesajları okudu
        session.user_unread_count = 0
        await session.save()
        # Admin ve system mesajlarını okundu işaretle
        await ChatMessage.find(
            ChatMessage.session_id == PydanticObjectId(session_id),
            {"sender_type": {"$in": [SenderType.ADMIN.value, SenderType.SYSTEM.value]}},
            ChatMessage.is_read == False
        ).update({"$set": {"is_read": True}})

        # Mark support notifications as read for this user
        try:
            await UserNotification.find(
                UserNotification.user_id == user.id,
                UserNotification.notification_type == "support",
                UserNotification.is_read == False,
            ).update({"$set": {"is_read": True}})
        except Exception:
            logger.exception("Failed to mark support notifications as read")
    
    return [
        MessageResponse(
            id=str(m.id),
            session_id=str(m.session_id),
            sender_id=str(m.sender_id) if m.sender_id else None,
            sender_name=m.sender_name,
            sender_type=m.sender_type.value,
            content=m.content,
            delivered=bool(getattr(m, "delivered", False)),
            is_read=m.is_read,
            created_at=m.created_at.isoformat()
        )
        for m in messages
    ]


@router.get("/my-session", response_model=Optional[SessionResponse])
async def get_my_session(user: User = Depends(get_current_active_user)):
    """Kullanıcının aktif destek oturumunu getir"""
    session = await SupportSession.find_one(
        SupportSession.user_id == user.id,
        SupportSession.status == SessionStatus.ACTIVE
    )
    
    if not session:
        return None
    
    return SessionResponse(
        id=str(session.id),
        user_id=str(session.user_id),
        user_name=session.user_name,
        user_email=session.user_email,
        status=session.status.value,
        last_message_at=session.last_message_at.isoformat(),
        last_message_preview=session.last_message_preview,
        unread_count=session.unread_count,
        user_unread_count=session.user_unread_count,
        created_at=session.created_at.isoformat(),
        closed_at=None,
        is_online=manager.is_any_admin_online()
    )


@router.get("/my-unread-count")
async def get_my_unread_count(user: User = Depends(get_current_active_user)):
    """Kullanıcının okunmamış destek mesajı sayısı"""
    session = await SupportSession.find_one(
        SupportSession.user_id == user.id,
        SupportSession.status == SessionStatus.ACTIVE
    )
    
    if not session:
        return {"unread_count": 0}
    
    return {"unread_count": session.user_unread_count}


@router.get("/admin/unread-count")
async def get_admin_unread_count(admin: User = Depends(get_admin_user)):
    """Admin için toplam okunmamış mesaj sayısı"""
    sessions = await SupportSession.find(
        SupportSession.status == SessionStatus.ACTIVE
    ).to_list()
    
    total_unread = sum(s.unread_count for s in sessions)
    return {"unread_count": total_unread}


@router.post("/sessions/{session_id}/close")
async def close_session(
    session_id: str,
    admin: User = Depends(get_admin_user)
):
    """Admin: Oturumu kapat"""
    session = await SupportSession.get(PydanticObjectId(session_id))
    if not session:
        raise HTTPException(status_code=404, detail="Oturum bulunamadı")
    
    session.status = SessionStatus.CLOSED
    session.closed_at = datetime.now(UTC)
    await session.save()
    
    # Kullanıcıya bildir
    await manager.send_to_user(session_id, {
        "type": "session_closed",
        "message": "Bu destek oturumu kapatıldı."
    })
    
    logger.info(f"Support session closed: {session_id} by admin: {admin.email}")
    
    return {"message": "Oturum kapatıldı"}


@router.post("/sessions/{session_id}/reopen")
async def reopen_session(
    session_id: str,
    admin: User = Depends(get_admin_user)
):
    """Admin: Kapalı oturumu yeniden aç"""
    session = await SupportSession.get(PydanticObjectId(session_id))
    if not session:
        raise HTTPException(status_code=404, detail="Oturum bulunamadı")
    
    session.status = SessionStatus.ACTIVE
    session.closed_at = None
    await session.save()
    
    logger.info(f"Support session reopened: {session_id} by admin: {admin.email}")
    
    return {"message": "Oturum yeniden açıldı"}


@router.get("/history", response_model=List[SessionResponse])
async def get_session_history(
    skip: int = 0,
    limit: int = 20,
    user: User = Depends(get_current_active_user)
):
    """Kullanıcının destek oturum geçmişi"""
    sessions = await SupportSession.find(
        SupportSession.user_id == user.id
    ).sort("-created_at").skip(skip).limit(limit).to_list()
    
    return [
        SessionResponse(
            id=str(s.id),
            user_id=str(s.user_id),
            user_name=s.user_name,
            user_email=s.user_email,
            status=s.status.value,
            last_message_at=s.last_message_at.isoformat(),
            last_message_preview=s.last_message_preview,
            unread_count=s.unread_count,
            user_unread_count=s.user_unread_count,
            created_at=s.created_at.isoformat(),
            closed_at=s.closed_at.isoformat() if s.closed_at else None,
            is_online=False
        )
        for s in sessions
    ]


# WebSocket Endpoints
# NOTE: Admin endpoint MUST be defined before user endpoint to avoid routing conflict
# where "admin" would be treated as a session_id

@router.websocket("/ws/admin")
async def websocket_admin(
    websocket: WebSocket,
    token: str = Query(...)
):
    """Admin için WebSocket bağlantısı"""
    # Token doğrulama
    user = await verify_ws_token(token)
    if not user or user.role != UserRole.ADMIN:
        await websocket.close(code=4001, reason="Unauthorized")
        return
    
    admin_id = str(user.id)
    await manager.connect_admin(admin_id, websocket)

    # When an admin comes online, mark pending user messages as delivered for currently online user sessions
    try:
        for sid in manager.get_online_user_sessions():
            try:
                await ChatMessage.find(
                    ChatMessage.session_id == PydanticObjectId(sid),
                    {"sender_type": SenderType.USER.value},
                    {"delivered": {"$ne": True}},
                ).update({"$set": {"delivered": True}})
                await manager.send_to_user(sid, {"type": "messages_delivered", "session_id": sid})
            except Exception:
                # best-effort; never block admin connect
                continue
    except Exception:
        logger.exception("Failed to mark delivered on admin connect")
    
    try:
        while True:
            data = await websocket.receive_json()
            
            if data.get("type") == "typing":
                # Yazıyor bildirimi
                session_id = data.get("session_id")
                if session_id:
                    await manager.set_typing(session_id, "admin", data.get("is_typing", False))
            
            elif data.get("type") == "message":
                # Yeni mesaj
                session_id = data.get("session_id")
                content = data.get("content", "").strip()
                
                if not session_id or not content:
                    continue
                
                # Oturum kontrolü
                session = await SupportSession.get(PydanticObjectId(session_id))
                if not session or session.status == SessionStatus.CLOSED:
                    await manager.send_to_admin(admin_id, {
                        "type": "error",
                        "message": "Oturum bulunamadı veya kapalı"
                    })
                    continue
                
                # Yazıyor durumunu kapat
                await manager.set_typing(session_id, "admin", False)
                
                # Mesajı kaydet
                message = ChatMessage(
                    session_id=session.id,
                    sender_id=user.id,
                    sender_name=user.full_name,
                    sender_type=SenderType.ADMIN,
                    content=content
                )
                await message.insert()
                
                # Oturumu güncelle
                session.last_message_at = datetime.now(UTC)
                session.last_message_preview = content[:50] + "..." if len(content) > 50 else content
                session.user_unread_count += 1
                await session.save()

                # Create a notification for the user (shows up on Header bell)
                try:
                    notif = UserNotification(
                        user_id=session.user_id,
                        notification_type="support",
                        message=f"Yeni destek mesajı: {content[:80]}",
                    )
                    await notif.insert()
                except Exception:
                    # never break chat flow due to notification
                    logger.exception("Failed to create support notification")
                
                # Kullanıcıya bildir
                await manager.send_to_user(session_id, {
                    "type": "new_message",
                    "message": {
                        "id": str(message.id),
                        "session_id": session_id,
                        "sender_id": str(user.id),
                        "sender_name": user.full_name,
                        "sender_type": "admin",
                        "content": content,
                        "delivered": True,
                        "is_read": False,
                        "created_at": message.created_at.isoformat()
                    }
                })
                
                # Admin'in kendi mesajını onaylama + diğer admin'lere bildir
                await manager.broadcast_to_admins({
                    "type": "message_sent",
                    "session_id": session_id,
                    "message": {
                        "id": str(message.id),
                        "session_id": session_id,
                        "sender_id": str(user.id),
                        "sender_name": user.full_name,
                        "sender_type": "admin",
                        "content": content,
                        "delivered": True,
                        "is_read": False,
                        "created_at": message.created_at.isoformat()
                    }
                })
            
            elif data.get("type") == "mark_read":
                # Mesajları okundu olarak işaretle
                session_id = data.get("session_id")
                if session_id:
                    session = await SupportSession.get(PydanticObjectId(session_id))
                    if session:
                        session.unread_count = 0
                        await session.save()
                        await ChatMessage.find(
                            ChatMessage.session_id == PydanticObjectId(session_id),
                            {"sender_type": SenderType.USER.value},
                            ChatMessage.is_read == False
                        ).update({"$set": {"is_read": True}})
                        # Notify user for WhatsApp-like blue ticks
                        await manager.send_to_user(str(session.id), {"type": "messages_read", "session_id": str(session.id)})
    
    except WebSocketDisconnect:
        await manager.disconnect_admin(admin_id)
    except Exception as e:
        logger.error(f"WebSocket error for admin {admin_id}: {e}")
        await manager.disconnect_admin(admin_id)


@router.websocket("/ws/{session_id}")
async def websocket_user(
    websocket: WebSocket,
    session_id: str,
    token: str = Query(...)
):
    """Kullanıcı için WebSocket bağlantısı"""
    # Token doğrulama
    user = await verify_ws_token(token)
    if not user:
        await websocket.close(code=4001, reason="Unauthorized")
        return
    
    # Oturum kontrolü
    try:
        session = await SupportSession.get(PydanticObjectId(session_id))
    except Exception:
        await websocket.close(code=4004, reason="Invalid session ID")
        return
        
    if not session or session.user_id != user.id:
        await websocket.close(code=4004, reason="Session not found")
        return
    
    if session.status == SessionStatus.CLOSED:
        await websocket.close(code=4003, reason="Session is closed")
        return
    
    # Bağlantıyı kabul et
    await manager.connect_user(session_id, websocket)
    
    try:
        while True:
            data = await websocket.receive_json()
            
            if data.get("type") == "typing":
                # Yazıyor bildirimi
                await manager.set_typing(session_id, "user", data.get("is_typing", False))
            
            elif data.get("type") == "message":
                # Yeni mesaj
                content = data.get("content", "").strip()
                if not content:
                    continue
                
                # Yazıyor durumunu kapat
                await manager.set_typing(session_id, "user", False)
                
                # Mesajı kaydet
                delivered = manager.is_any_admin_online()
                message = ChatMessage(
                    session_id=session.id,
                    sender_id=user.id,
                    sender_name=user.full_name,
                    sender_type=SenderType.USER,
                    content=content,
                    delivered=delivered,
                )
                await message.insert()
                
                # Oturumu güncelle
                session.last_message_at = datetime.now(UTC)
                session.last_message_preview = content[:50] + "..." if len(content) > 50 else content
                session.unread_count += 1
                await session.save()
                
                # Admin'lere bildir
                await manager.broadcast_to_admins({
                    "type": "new_message",
                    "session_id": session_id,
                    "message": {
                        "id": str(message.id),
                        "session_id": session_id,
                        "sender_id": str(user.id),
                        "sender_name": user.full_name,
                        "sender_type": "user",
                        "content": content,
                        "delivered": delivered,
                        "is_read": False,
                        "created_at": message.created_at.isoformat()
                    }
                })
                
                # Kullanıcının kendi mesajını onaylama
                await manager.send_to_user(session_id, {
                    "type": "message_sent",
                    "message": {
                        "id": str(message.id),
                        "session_id": session_id,
                        "sender_id": str(user.id),
                        "sender_name": user.full_name,
                        "sender_type": "user",
                        "content": content,
                        "delivered": delivered,
                        "is_read": False,
                        "created_at": message.created_at.isoformat()
                    }
                })
    
    except WebSocketDisconnect:
        await manager.disconnect_user(session_id)
    except Exception as e:
        logger.error(f"WebSocket error for user session {session_id}: {e}")
        await manager.disconnect_user(session_id)


@router.get("/admin/online-status")
async def get_admin_online_status():
    """Admin'lerin online durumunu kontrol et (public endpoint)"""
    return {"online": manager.is_any_admin_online()}
