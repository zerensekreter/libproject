from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel
from datetime import datetime

from app.models.announcement import Announcement, AnnouncementPriority
from app.models.user import User
from app.routes.auth import get_admin_user

router = APIRouter()

class AnnouncementCreate(BaseModel):
    title: str
    content: str
    priority: AnnouncementPriority = AnnouncementPriority.MEDIUM
    is_pinned: bool = False

class AnnouncementResponse(BaseModel):
    id: str
    title: str
    content: str
    priority: AnnouncementPriority
    is_pinned: bool
    is_active: bool
    created_at: datetime

@router.get("/", response_model=List[AnnouncementResponse])
async def get_announcements(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    active_only: bool = True
):
    """Get all announcements"""
    query = {}
    if active_only:
        query["is_active"] = True
    
    announcements = await Announcement.find(query).sort(-Announcement.is_pinned, -Announcement.created_at).skip(skip).limit(limit).to_list()
    
    return [AnnouncementResponse(
        id=str(a.id),
        title=a.title,
        content=a.content,
        priority=a.priority,
        is_pinned=a.is_pinned,
        is_active=a.is_active,
        created_at=a.created_at
    ) for a in announcements]

@router.post("/", response_model=AnnouncementResponse)
async def create_announcement(
    data: AnnouncementCreate,
    current_user: User = Depends(get_admin_user)
):
    """Create announcement (admin only)"""
    from app.models.extras import UserNotification
    
    announcement = Announcement(**data.model_dump())
    await announcement.insert()
    
    # Create notifications for all active users
    users = await User.find(User.is_active == True).to_list()
    for user in users:
        notification = UserNotification(
            user_id=user.id,
            announcement_id=announcement.id,
            announcement_title=announcement.title
        )
        await notification.insert()
    
    return AnnouncementResponse(
        id=str(announcement.id),
        title=announcement.title,
        content=announcement.content,
        priority=announcement.priority,
        is_pinned=announcement.is_pinned,
        is_active=announcement.is_active,
        created_at=announcement.created_at
    )

@router.delete("/{announcement_id}")
async def delete_announcement(
    announcement_id: str,
    current_user: User = Depends(get_admin_user)
):
    """Delete announcement (admin only)"""
    announcement = await Announcement.get(PydanticObjectId(announcement_id))
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    
    await announcement.delete()
    return {"message": "Announcement deleted"}


class AnnouncementUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    priority: Optional[str] = None
    is_pinned: Optional[bool] = None
    is_active: Optional[bool] = None


@router.put("/{announcement_id}", response_model=AnnouncementResponse)
async def update_announcement(
    announcement_id: str,
    update_data: AnnouncementUpdate,
    current_user: User = Depends(get_admin_user)
):
    """Update announcement (admin only)"""
    announcement = await Announcement.get(PydanticObjectId(announcement_id))
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    
    if update_data.title is not None:
        announcement.title = update_data.title
    if update_data.content is not None:
        announcement.content = update_data.content
    if update_data.priority is not None:
        announcement.priority = AnnouncementPriority(update_data.priority)
    if update_data.is_pinned is not None:
        announcement.is_pinned = update_data.is_pinned
    if update_data.is_active is not None:
        announcement.is_active = update_data.is_active
    
    await announcement.save()
    
    return AnnouncementResponse(
        id=str(announcement.id),
        title=announcement.title,
        content=announcement.content,
        priority=announcement.priority,
        is_pinned=announcement.is_pinned,
        is_active=announcement.is_active,
        created_at=announcement.created_at
    )

