from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from datetime import datetime, timedelta, UTC
from jose import JWTError, jwt
from typing import Optional
from pydantic import BaseModel, EmailStr, field_validator
from beanie import PydanticObjectId
from slowapi import Limiter
from slowapi.util import get_remote_address
import re
import logging

from app.config import settings
from app.models.user import User, UserRole
from app.security.passwords import hash_password, verify_password, dummy_hash

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")
logger = logging.getLogger(__name__)

# Rate limiter for auth routes
limiter = Limiter(key_func=get_remote_address)

# Password validation regex
PASSWORD_REGEX = re.compile(
    r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
)

# Schemas
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    student_id: str
    full_name: str
    department: Optional[str] = None
    
    @field_validator('password')
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < settings.min_password_length:
            raise ValueError(f'Şifre en az {settings.min_password_length} karakter olmalı')
        if len(v) > 128:
            raise ValueError('Şifre çok uzun')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Şifre en az bir büyük harf içermeli')
        if not re.search(r'[a-z]', v):
            raise ValueError('Şifre en az bir küçük harf içermeli')
        if not re.search(r'\d', v):
            raise ValueError('Şifre en az bir rakam içermeli')
        return v
    
    @field_validator('student_id')
    @classmethod
    def validate_student_id(cls, v: str) -> str:
        if not v.isalnum():
            raise ValueError('Öğrenci numarası sadece harf ve rakam içerebilir')
        if len(v) < 5 or len(v) > 20:
            raise ValueError('Öğrenci numarası 5-20 karakter arası olmalı')
        return v
    
    @field_validator('full_name')
    @classmethod
    def validate_full_name(cls, v: str) -> str:
        if len(v) < 2 or len(v) > 100:
            raise ValueError('İsim 2-100 karakter arası olmalı')
        # Basic XSS prevention
        if re.search(r'[<>"\']', v):
            raise ValueError('İsim geçersiz karakterler içeriyor')
        return v.strip()

class UserResponse(BaseModel):
    id: str
    email: str
    student_id: str
    full_name: str
    department: Optional[str] = None
    role: UserRole
    is_active: bool
    is_verified: bool
    max_books: int

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(UTC) + (expires_delta or timedelta(minutes=settings.access_token_expire_minutes))
    to_encode.update({
        "exp": expire,
        "iat": datetime.now(UTC),  # Issued at
        "type": "access"
    })
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)

async def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        
        if user_id is None or token_type != "access":
            raise credentials_exception
    except JWTError as e:
        logger.warning(f"JWT validation failed: {e}")
        raise credentials_exception
    
    try:
        user = await User.get(PydanticObjectId(user_id))
    except Exception:
        raise credentials_exception
        
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    if not current_user.is_active:
        raise HTTPException(status_code=403, detail="User account is deactivated")
    return current_user

async def get_admin_user(current_user: User = Depends(get_current_active_user)) -> User:
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

@router.post("/register", response_model=UserResponse)
@limiter.limit("5/minute")  # Rate limit registration
async def register(request: Request, user_data: RegisterRequest):
    # Check if email exists (case-insensitive)
    email_lower = user_data.email.lower()
    if await User.find_one({"email": {"$regex": f"^{re.escape(email_lower)}$", "$options": "i"}}):
        raise HTTPException(status_code=400, detail="Bu e-posta adresi zaten kayıtlı")
    
    # Check if student_id exists
    if await User.find_one(User.student_id == user_data.student_id):
        raise HTTPException(status_code=400, detail="Bu öğrenci numarası zaten kayıtlı")
    
    # Create user
    user = User(
        email=email_lower,  # Store lowercase
        student_id=user_data.student_id,
        full_name=user_data.full_name,
        department=user_data.department,
        hashed_password=hash_password(user_data.password),
    )
    await user.insert()
    
    logger.info(f"New user registered: {user.student_id}")
    
    return UserResponse(
        id=str(user.id),
        email=user.email,
        student_id=user.student_id,
        full_name=user.full_name,
        department=user.department,
        role=user.role,
        is_active=user.is_active,
        is_verified=user.is_verified,
        max_books=user.max_books
    )

@router.post("/login", response_model=Token)
@limiter.limit("10/minute")  # Rate limit login attempts
async def login(request: Request, form_data: OAuth2PasswordRequestForm = Depends()):
    # Case-insensitive email lookup
    email_lower = form_data.username.lower()
    user = await User.find_one({"email": {"$regex": f"^{re.escape(email_lower)}$", "$options": "i"}})
    
    # Generic error message to prevent user enumeration
    invalid_credentials = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="E-posta veya şifre hatalı",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    if not user:
        # Still hash to prevent timing attacks - use bcrypt directly to avoid passlib initialization
        dummy_hash()
        raise invalid_credentials
    
    if not verify_password(form_data.password, user.hashed_password):
        logger.warning(f"Failed login attempt for: {email_lower}")
        raise invalid_credentials
    
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Hesabınız devre dışı bırakılmış")
        
    if not getattr(user, 'is_verified', False):
        raise HTTPException(status_code=403, detail="Hesabınız henüz onay sürecindedir. Sisteme giriş yapabilmek için lütfen kütüphane görevlisi ile iletişime geçerek hesabınızı onaylatınız.")
    
    # Update last login
    user.last_login = datetime.now(UTC)
    await user.save()
    
    access_token = create_access_token(
        data={"sub": str(user.id), "role": user.role.value}
    )
    
    logger.info(f"User logged in: {user.student_id}")
    
    return Token(access_token=access_token)

@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_active_user)):
    return UserResponse(
        id=str(current_user.id),
        email=current_user.email,
        student_id=current_user.student_id,
        full_name=current_user.full_name,
        department=current_user.department,
        role=current_user.role,
        is_active=current_user.is_active,
        is_verified=current_user.is_verified,
        max_books=current_user.max_books
    )

