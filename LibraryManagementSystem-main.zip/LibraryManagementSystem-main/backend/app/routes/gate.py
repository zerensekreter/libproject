"""
Kapı Güvenlik Kontrol API'si.

Kütüphane çıkış kapısındaki RFID okuyucu ile entegre çalışır.
Ödünç verilmemiş kitaplar için alarm tetikler.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
import logging

from app.models.book import Book
from app.models.book_copy import BookCopy
from app.models.loan import Loan, LoanStatus
from app.models.user import User
from app.routes.auth import get_admin_user

router = APIRouter()
logger = logging.getLogger(__name__)


# ── Schemas ───────────────────────────────────────────────

class GateCheckRequest(BaseModel):
    uid: str

class GateCheckResponse(BaseModel):
    allowed: bool
    alarm: bool = False
    book_title: Optional[str] = None
    borrower: Optional[str] = None
    message: Optional[str] = None


# ── Endpoints ─────────────────────────────────────────────

@router.post("/check", response_model=GateCheckResponse)
async def gate_check(
    data: GateCheckRequest,
    current_user: User = Depends(get_admin_user),
):
    """
    Kapı kontrol sistemi.
    
    RFID UID geldiğinde:
    1. BookCopy bul
    2. Aktif Loan kontrol et
    3. Ödünç verilmişse → allowed=True
    4. Ödünç verilmemişse → allowed=False, alarm=True
    5. Bilinmeyen UID → allowed=False, alarm=True
    """
    uid = data.uid.upper().strip()

    # BookCopy bul
    book_copy = await BookCopy.find_one(BookCopy.rfid_uid == uid)
    if not book_copy:
        logger.warning(f"Kapı kontrol: Bilinmeyen RFID UID={uid}")
        return GateCheckResponse(
            allowed=False,
            alarm=True,
            message="Bilinmeyen RFID etiketi",
        )

    # Kitap bilgisini al
    book = await Book.get(book_copy.book_id)
    book_title = book.title if book else "Bilinmeyen kitap"

    # Aktif loan kontrolü (bu book_copy_id ile VEYA bu book_copy_rfid ile)
    active_loan = await Loan.find_one(
        {
            "$or": [
                {"book_copy_id": book_copy.id},
                {"book_copy_rfid": uid},
            ],
            "status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]},
        }
    )

    if active_loan:
        # Kitap ödünç verilmiş — geçişe izin ver
        borrower_name = active_loan.user_name or "Bilinmeyen"
        logger.info(f"Kapı kontrol: İZİN VERİLDİ — '{book_title}' (ödünç alan: {borrower_name})")
        return GateCheckResponse(
            allowed=True,
            alarm=False,
            book_title=book_title,
            borrower=borrower_name,
        )
    else:
        # Kitap ödünç verilmemiş — ALARM
        logger.warning(f"Kapı kontrol: ALARM — '{book_title}' ödünç alınmadan çıkarılmaya çalışılıyor!")
        return GateCheckResponse(
            allowed=False,
            alarm=True,
            book_title=book_title,
            message="Bu kitap ödünç alınmamış! Güvenlik alarmı tetiklendi.",
        )
