from __future__ import annotations

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from typing import Optional
from jose import JWTError, jwt
from beanie import PydanticObjectId

from app.config import settings
from app.models.user import User
from app.realtime_manager import manager

router = APIRouter()


async def _verify_ws_token(token: str) -> Optional[User]:
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        if not user_id or token_type != "access":
            return None
        user = await User.get(PydanticObjectId(user_id))
        if user is None or not user.is_active:
            return None
        return user
    except JWTError:
        return None


@router.websocket("/ws")
async def websocket_realtime(websocket: WebSocket, token: str = Query(...)):
    """
    User-scoped realtime channel.
    Client receives tiny events and refetches via REST (recommended).
    """
    user = await _verify_ws_token(token)
    if not user:
        await websocket.close(code=4001, reason="Unauthorized")
        return

    uid = str(user.id)
    await manager.connect_user(uid, websocket)
    try:
        while True:
            # We don't require client -> server messages for now.
            # Keep the connection alive by reading frames.
            await websocket.receive_text()
    except WebSocketDisconnect:
        await manager.disconnect_user(uid, websocket)
    except Exception:
        await manager.disconnect_user(uid, websocket)


