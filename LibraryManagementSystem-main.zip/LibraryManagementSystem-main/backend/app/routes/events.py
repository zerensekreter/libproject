from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from beanie import PydanticObjectId

from app.models.user import User
from app.models.book import Book
from app.models.interaction import UserEvent, UserEventType
from app.routes.auth import get_current_active_user
from app.realtime_manager import manager as realtime_manager


router = APIRouter()


class SearchEventRequest(BaseModel):
    query: str


@router.post("/book-view/{book_id}")
async def track_book_view(book_id: str, current_user: User = Depends(get_current_active_user)):
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")

    ev = UserEvent(
        user_id=current_user.id,
        event_type=UserEventType.BOOK_VIEW,
        book_id=book.id,
        metadata={
            "isbn": book.isbn,
            "title": book.title,
        },
    )
    await ev.insert()
    # Reco invalidation push (best-effort)
    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="book_view")
    except Exception:
        pass
    return {"status": "ok"}


@router.post("/search")
async def track_search(data: SearchEventRequest, current_user: User = Depends(get_current_active_user)):
    q = data.query.strip()
    if not q:
        raise HTTPException(status_code=400, detail="query is required")

    ev = UserEvent(
        user_id=current_user.id,
        event_type=UserEventType.SEARCH,
        query=q,
    )
    await ev.insert()
    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="search")
    except Exception:
        pass
    return {"status": "ok"}


@router.post("/recommendation-click/{book_id}")
async def track_recommendation_click(book_id: str, current_user: User = Depends(get_current_active_user)):
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")

    ev = UserEvent(
        user_id=current_user.id,
        event_type=UserEventType.RECOMMENDATION_CLICK,
        book_id=book.id,
        metadata={
            "isbn": book.isbn,
            "title": book.title,
        },
    )
    await ev.insert()
    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="recommendation_click")
    except Exception:
        pass
    return {"status": "ok"}



