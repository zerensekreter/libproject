from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel
from datetime import datetime, timedelta, UTC
import logging

from app.models.user import User
from app.models.book import Book
from app.models.extras import BorrowRequest, BorrowRequestStatus, Favorite, UserNotification
from app.models.announcement import Announcement
from app.models.loan import Loan, LoanStatus
from app.routes.auth import get_current_active_user, get_admin_user
from app.security.passwords import verify_password, hash_password
from app.realtime_manager import manager as realtime_manager

router = APIRouter()
logger = logging.getLogger(__name__)

# ============== FAVORITES ==============

class FavoriteResponse(BaseModel):
    id: str
    book_id: str
    book_title: str
    book_author: str
    book_isbn: str
    created_at: datetime


@router.get("/favorites", response_model=List[FavoriteResponse])
async def get_my_favorites(current_user: User = Depends(get_current_active_user)):
    """Get current user's favorites"""
    favorites = await Favorite.find(Favorite.user_id == current_user.id).to_list()
    return [FavoriteResponse(
        id=str(f.id),
        book_id=str(f.book_id),
        book_title=f.book_title,
        book_author=f.book_author,
        book_isbn=f.book_isbn,
        created_at=f.created_at
    ) for f in favorites]


@router.post("/favorites/{book_id}")
async def add_favorite(book_id: str, current_user: User = Depends(get_current_active_user)):
    """Add book to favorites"""
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    # Check if already favorited
    existing = await Favorite.find_one(
        Favorite.user_id == current_user.id,
        Favorite.book_id == book.id
    )
    if existing:
        raise HTTPException(status_code=400, detail="Zaten favorilerinizde")
    
    favorite = Favorite(
        user_id=current_user.id,
        book_id=book.id,
        book_title=book.title,
        book_author=book.author,
        book_isbn=book.isbn
    )
    await favorite.insert()
    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="favorite_add")
    except Exception:
        pass
    return {"message": "Book added to favorites"}


@router.delete("/favorites/{book_id}")
async def remove_favorite(book_id: str, current_user: User = Depends(get_current_active_user)):
    """Remove book from favorites"""
    favorite = await Favorite.find_one(
        Favorite.user_id == current_user.id,
        Favorite.book_id == PydanticObjectId(book_id)
    )
    if not favorite:
        raise HTTPException(status_code=404, detail="Favorite not found")
    
    await favorite.delete()
    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="favorite_remove")
    except Exception:
        pass
    return {"message": "Book removed from favorites"}


@router.get("/favorites/check/{book_id}")
async def check_favorite(book_id: str, current_user: User = Depends(get_current_active_user)):
    """Check if book is in favorites"""
    favorite = await Favorite.find_one(
        Favorite.user_id == current_user.id,
        Favorite.book_id == PydanticObjectId(book_id)
    )
    return {"is_favorite": favorite is not None}


# ============== BORROW REQUESTS ==============

class BorrowRequestResponse(BaseModel):
    id: str
    user_id: str
    book_id: str
    user_name: str
    book_title: str
    book_isbn: str
    status: str
    created_at: datetime
    processed_at: Optional[datetime] = None


@router.get("/borrow-requests", response_model=List[BorrowRequestResponse])
async def get_borrow_requests(
    status: Optional[str] = None,
    current_user: User = Depends(get_admin_user)
):
    """Get all borrow requests (admin only)"""
    query = {}
    if status:
        query["status"] = status
    
    requests = await BorrowRequest.find(query).sort(-BorrowRequest.created_at).to_list()
    return [BorrowRequestResponse(
        id=str(r.id),
        user_id=str(r.user_id),
        book_id=str(r.book_id),
        user_name=r.user_name,
        book_title=r.book_title,
        book_isbn=r.book_isbn,
        status=r.status.value,
        created_at=r.created_at,
        processed_at=r.processed_at
    ) for r in requests]


@router.post("/borrow-requests/{book_id}")
async def create_borrow_request(book_id: str, current_user: User = Depends(get_current_active_user)):
    """Create a borrow request"""
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    if book.available_copies <= 0:
        raise HTTPException(status_code=400, detail="No available copies")

    # Enforce global limit: active loans + pending requests <= max_books
    max_books = int(getattr(current_user, "max_books", 5) or 5)
    active_loans = await Loan.find(
        Loan.user_id == current_user.id,
        {"status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]}}
    ).count()
    pending_requests = await BorrowRequest.find(
        BorrowRequest.user_id == current_user.id,
        BorrowRequest.status == BorrowRequestStatus.PENDING,
    ).count()
    if (active_loans + pending_requests) >= max_books:
        raise HTTPException(
            status_code=400,
            detail=f"Aktif ödünçleriniz veya bekleyen talepleriniz limitte ({active_loans + pending_requests}/{max_books}).",
        )

    # Prevent requesting a book that's already actively loaned by this user
    existing_loan = await Loan.find_one(
        Loan.user_id == current_user.id,
        Loan.book_id == book.id,
        {"status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]}}
    )
    if existing_loan:
        raise HTTPException(status_code=400, detail="Bu kitap zaten aktif ödünçlerinizde")
    
    # Check if already has pending request for this book
    existing = await BorrowRequest.find_one(
        BorrowRequest.user_id == current_user.id,
        BorrowRequest.book_id == book.id,
        BorrowRequest.status == BorrowRequestStatus.PENDING
    )
    if existing:
        raise HTTPException(status_code=400, detail="Zaten bu kitabı almak için istek oluşturdunuz")
    
    request = BorrowRequest(
        user_id=current_user.id,
        book_id=book.id,
        user_name=current_user.full_name,
        user_email=current_user.email,
        book_title=book.title,
        book_isbn=book.isbn
    )
    await request.insert()
    
    # Create notification for the user
    notification = UserNotification(
        user_id=current_user.id,
        notification_type="borrow_request",
        book_id=book.id,
        message=f"\"{book.title}\" için ödünç alma isteğiniz gönderildi"
    )
    await notification.insert()

    # Reco invalidation push (best-effort)
    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="borrow_request_created")
    except Exception:
        pass
    
    return {"message": "Borrow request created successfully", "request_id": str(request.id), "status": request.status.value}


@router.get("/borrow-requests/me", response_model=List[BorrowRequestResponse])
async def get_my_borrow_requests(
    status: Optional[str] = None,
    book_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """Get current user's borrow requests (user-only)."""
    query: dict = {"user_id": current_user.id}
    if status:
        query["status"] = status
    if book_id:
        query["book_id"] = PydanticObjectId(book_id)

    requests = await BorrowRequest.find(query).sort(-BorrowRequest.created_at).to_list()
    return [
        BorrowRequestResponse(
            id=str(r.id),
            user_id=str(r.user_id),
            book_id=str(r.book_id),
            user_name=r.user_name,
            book_title=r.book_title,
            book_isbn=r.book_isbn,
            status=r.status.value,
            created_at=r.created_at,
            processed_at=r.processed_at,
        )
        for r in requests
    ]


@router.delete("/borrow-requests/{request_id}")
async def cancel_my_borrow_request(
    request_id: str,
    current_user: User = Depends(get_current_active_user),
):
    """Cancel (withdraw) a pending borrow request (user-only)."""
    req = await BorrowRequest.get(PydanticObjectId(request_id))
    if not req or req.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Request not found")

    if req.status != BorrowRequestStatus.PENDING:
        raise HTTPException(status_code=400, detail="Only pending requests can be cancelled")

    req.status = BorrowRequestStatus.CANCELLED
    req.processed_at = datetime.now(UTC)
    await req.save()

    await UserNotification(
        user_id=current_user.id,
        notification_type="borrow_request",
        book_id=req.book_id,
        message=f"\"{req.book_title}\" için ödünç alma talebinizi geri aldınız.",
    ).insert()

    try:
        await realtime_manager.reco_invalidate(str(current_user.id), reason="borrow_request_cancelled")
    except Exception:
        pass

    return {"message": "Borrow request cancelled", "request_id": str(req.id), "status": req.status.value}


class ProcessBorrowRequest(BaseModel):
    action: str  # "approve" or "reject"
    notes: Optional[str] = None
    due_days: int = 14


@router.post("/borrow-requests/{request_id}/process")
async def process_borrow_request(
    request_id: str,
    data: ProcessBorrowRequest,
    current_user: User = Depends(get_admin_user)
):
    """Process (approve/reject) a borrow request"""
    logger.info("process_borrow_request called (request_id=%s, action=%s)", request_id, getattr(data, "action", None))
    request = await BorrowRequest.get(PydanticObjectId(request_id))
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if request.status != BorrowRequestStatus.PENDING:
        raise HTTPException(status_code=400, detail="Request already processed")
    
    # Always fetch current entities to prevent stale state issues
    user = await User.get(request.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    book = await Book.get(request.book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")

    action = (data.action or "").strip().lower()

    if action == "approve":
        if not user.is_active:
            raise HTTPException(status_code=400, detail="User account is deactivated")

        # Enforce loan limit
        active_loans = await Loan.find(
            Loan.user_id == user.id,
            {"status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]}}
        ).count()
        if active_loans >= user.max_books:
            raise HTTPException(status_code=400, detail=f"User has reached maximum loan limit ({user.max_books})")

        # Prevent duplicate active loan for same book
        existing_loan = await Loan.find_one(
            Loan.user_id == user.id,
            Loan.book_id == book.id,
            {"status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]}}
        )
        if existing_loan:
            raise HTTPException(status_code=400, detail="User already has an active loan for this book")

        if book.available_copies <= 0:
            raise HTTPException(status_code=400, detail="No available copies")

        # Create loan (same behavior as /loans/checkout)
        due_days = int(data.due_days or 14)
        if due_days < 1 or due_days > 60:
            raise HTTPException(status_code=400, detail="Invalid due_days (1..60)")

        loan = Loan(
            user_id=user.id,
            book_id=book.id,
            user_name=user.full_name,
            user_email=user.email,
            book_title=book.title,
            book_isbn=book.isbn,
            due_date=datetime.now(UTC) + timedelta(days=due_days),
            status=LoanStatus.ACTIVE,
            notes=data.notes,
        )

        # Update stock & popularity
        book.available_copies -= 1
        book.borrow_count += 1

        # Persist (best-effort ordering: create loan first; if book save fails, revert loan)
        await loan.insert()
        try:
            await book.save()
        except Exception as e:
            await loan.delete()
            raise HTTPException(status_code=500, detail=f"Failed to update book availability: {e}")

        request.status = BorrowRequestStatus.APPROVED
        request.admin_notes = data.notes
        request.processed_at = datetime.now(UTC)
        await request.save()

        # Notify user
        await UserNotification(
            user_id=user.id,
            notification_type="borrow_request",
            book_id=book.id,
            message=f"\"{book.title}\" ödünç alma isteğiniz onaylandı. Son iade: {loan.due_date.date().isoformat()}",
        ).insert()

        try:
            await realtime_manager.reco_invalidate(str(user.id), reason="borrow_request_approved")
        except Exception:
            pass

        logger.info(
            "borrow_request approved -> loan created (request_id=%s, loan_id=%s, user_id=%s, book_id=%s)",
            str(request.id),
            str(loan.id),
            str(user.id),
            str(book.id),
        )
        return {"message": "Request approved and loan created", "loan_id": str(loan.id)}

    if action == "reject":
        request.status = BorrowRequestStatus.REJECTED
        request.admin_notes = data.notes
        request.processed_at = datetime.now(UTC)
        await request.save()

        await UserNotification(
            user_id=user.id,
            notification_type="borrow_request",
            book_id=book.id,
            message=f"\"{book.title}\" ödünç alma isteğiniz reddedildi.",
        ).insert()

        try:
            await realtime_manager.reco_invalidate(str(user.id), reason="borrow_request_rejected")
        except Exception:
            pass

        return {"message": "Request rejected"}

    raise HTTPException(status_code=400, detail="Invalid action")


# ============== NOTIFICATIONS ==============

class NotificationResponse(BaseModel):
    id: str
    announcement_id: Optional[str] = None
    announcement_title: Optional[str] = None
    book_id: Optional[str] = None
    notification_type: str = "announcement"
    message: Optional[str] = None
    is_read: bool
    created_at: datetime


@router.get("/notifications", response_model=List[NotificationResponse])
async def get_my_notifications(current_user: User = Depends(get_current_active_user)):
    """Get current user's notifications"""
    notifications = await UserNotification.find(
        UserNotification.user_id == current_user.id
    ).sort(-UserNotification.created_at).limit(20).to_list()
    
    return [NotificationResponse(
        id=str(n.id),
        announcement_id=str(n.announcement_id) if n.announcement_id else None,
        announcement_title=n.announcement_title,
        book_id=str(getattr(n, "book_id", None)) if getattr(n, "book_id", None) else None,
        notification_type=n.notification_type,
        message=n.message,
        is_read=n.is_read,
        created_at=n.created_at
    ) for n in notifications]


@router.get("/notifications/unread-count")
async def get_unread_count(current_user: User = Depends(get_current_active_user)):
    """Get count of unread notifications"""
    count = await UserNotification.find(
        UserNotification.user_id == current_user.id,
        UserNotification.is_read == False
    ).count()
    return {"count": count}


@router.post("/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, current_user: User = Depends(get_current_active_user)):
    """Mark notification as read"""
    notification = await UserNotification.get(PydanticObjectId(notification_id))
    if not notification or notification.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Notification not found")
    
    notification.is_read = True
    await notification.save()
    return {"message": "Notification marked as read"}


@router.post("/notifications/read-all")
async def mark_all_notifications_read(current_user: User = Depends(get_current_active_user)):
    """Mark all notifications as read"""
    await UserNotification.find(
        UserNotification.user_id == current_user.id,
        UserNotification.is_read == False
    ).update_many({"$set": {"is_read": True}})
    return {"message": "All notifications marked as read"}


# ============== PASSWORD CHANGE ==============

class PasswordChange(BaseModel):
    current_password: str
    new_password: str


@router.post("/change-password")
async def change_password(data: PasswordChange, current_user: User = Depends(get_current_active_user)):
    """Change current user's password"""
    # Verify current password
    if not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    
    if len(data.new_password) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters")
    
    # Update password
    current_user.hashed_password = hash_password(data.new_password)
    current_user.updated_at = datetime.now(UTC)
    await current_user.save()
    
    return {"message": "Password changed successfully"}
