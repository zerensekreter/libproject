from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from typing import List, Optional

import anyio
import logging
from beanie import PydanticObjectId

from app.models.book import Book
from app.models.user import User
from app.routes.auth import get_current_active_user
from app.ml_engine.recommender import search_by_text, recommend_for_user
from app.models.interaction import UserEvent, UserEventType


router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/me/debug")
async def recommend_for_me_debug(
    include_history: bool = Query(False, description="Ödünç/favori/izlenen kitapları da sonuçta göster"),
    current_user: User = Depends(get_current_active_user),
):
    """
    Prod'a taşımadan önce doğrulama için güvenli debug çıktısı:
    - kullanıcının sinyal sayıları (favori/ödünç/view/click)
    - çıkarılan top kategori/yazar
    - AI index hazır mı (dolaylı: recommend_for_user'ın RuntimeError verip vermediği)
    """
    from collections import Counter, defaultdict
    from app.models.extras import Favorite
    from app.models.extras import BorrowRequest, BorrowRequestStatus
    from app.models.loan import Loan
    from app.ml_engine.recommender import is_book_indexed, is_index_available

    favs = await Favorite.find(Favorite.user_id == current_user.id).limit(500).to_list()
    borrow_requests = await BorrowRequest.find(
        BorrowRequest.user_id == current_user.id,
        BorrowRequest.status == BorrowRequestStatus.PENDING,
    ).limit(500).to_list()
    loans = await Loan.find(Loan.user_id == current_user.id).limit(500).to_list()
    views = await UserEvent.find(
        UserEvent.user_id == current_user.id,
        UserEvent.event_type == UserEventType.BOOK_VIEW,
    ).limit(1000).to_list()
    clicks = await UserEvent.find(
        UserEvent.user_id == current_user.id,
        UserEvent.event_type == UserEventType.RECOMMENDATION_CLICK,
    ).limit(1000).to_list()

    exclude: List[str] = []
    if not include_history:
        exclude = [str(f.book_id) for f in favs] + [str(l.book_id) for l in loans]

    # Build seed set for analysis
    seed_ids: List[PydanticObjectId] = []
    for f in favs:
        seed_ids.append(PydanticObjectId(str(f.book_id)))
    for br in borrow_requests:
        seed_ids.append(PydanticObjectId(str(br.book_id)))
    for l in loans:
        seed_ids.append(PydanticObjectId(str(l.book_id)))
    for ev in views:
        if ev.book_id:
            seed_ids.append(PydanticObjectId(str(ev.book_id)))
    for ev in clicks:
        if ev.book_id:
            seed_ids.append(PydanticObjectId(str(ev.book_id)))

    # Frequency signals (important: repeated views should matter)
    view_counts = defaultdict(int)
    for ev in views:
        if ev.book_id:
            view_counts[str(ev.book_id)] += 1
    click_counts = defaultdict(int)
    for ev in clicks:
        if ev.book_id:
            click_counts[str(ev.book_id)] += 1

    seed_books = await Book.find({"_id": {"$in": seed_ids}}).to_list() if seed_ids else []

    fav_set = {str(f.book_id) for f in favs}
    loan_set = {str(l.book_id) for l in loans}
    req_set = {str(br.book_id) for br in borrow_requests}

    cat_counter: Counter[str] = Counter()
    author_counter: Counter[str] = Counter()
    for b in seed_books:
        bid = str(b.id)
        # Base weight + stronger signals + *frequency* (views/clicks)
        w = 1.0
        if bid in fav_set:
            w += 3.0
        if bid in req_set:
            w += 3.5
        if bid in loan_set:
            w += 4.0
        # frequency-aware boosts (cap to avoid explosions)
        v = float(min(int(view_counts.get(bid, 0)), 50))
        c = float(min(int(click_counts.get(bid, 0)), 50))
        w += 0.25 * v
        w += 0.75 * c

        if b.category:
            cat_counter[b.category] += w
        if b.author:
            author_counter[b.author] += w

    # Top viewed books for debugging
    top_viewed_ids = [bid for bid, _ in sorted(view_counts.items(), key=lambda x: x[1], reverse=True)[:10]]
    top_viewed_books = []
    if top_viewed_ids:
        try:
            oids = [PydanticObjectId(x) for x in top_viewed_ids]
            vb = await Book.find({"_id": {"$in": oids}}).to_list()
            byid = {str(b.id): b for b in vb}
            for bid in top_viewed_ids:
                b = byid.get(bid)
                if not b:
                    continue
                top_viewed_books.append({
                    "id": bid,
                    "title": b.title,
                    "author": b.author,
                    "category": b.category,
                    "views": int(view_counts.get(bid, 0)),
                    "in_ai_index": bool(is_book_indexed(bid)),
                })
        except Exception:
            top_viewed_books = []

    ai_ok = True
    ai_error = None
    try:
        _ = await recommend_for_user(
            user_id=str(current_user.id),
            limit=3,
            query=None,
            exclude_book_ids=exclude,
        )
    except RuntimeError as e:
        ai_ok = False
        ai_error = str(e)
    except Exception as e:
        ai_ok = False
        ai_error = f"unexpected_error: {e}"

    return {
        "user_id": str(current_user.id),
        "signals": {
            "favorites": len(favs),
            "borrow_requests_pending": len(borrow_requests),
            "loans": len(loans),
            "book_views": len(views),
            "recommendation_clicks": len(clicks),
        },
        "top_categories": [c for c, _ in cat_counter.most_common(5)],
        "top_authors": [a for a, _ in author_counter.most_common(5)],
        "top_viewed_books": top_viewed_books,
        "exclude_count": len(exclude),
        "ai_index_available": ai_ok and is_index_available(),
        "ai_error": ai_error,
    }


class RecommendationBook(BaseModel):
    """
    Frontend'in kartları için gereken alanları döner (BookResponse uyumlu) + skor.
    Bu sayede öneri kartlarında yanlışlıkla 'Tükendi' görünmesi ve kapakların kaybolması önlenir.
    """
    id: str
    isbn: str
    title: str
    author: str
    publisher: Optional[str] = None
    publish_year: Optional[int] = None
    language: str
    category: Optional[str] = None
    pages: Optional[int] = None
    total_copies: int
    available_copies: int
    location: Optional[str] = None
    description: Optional[str] = None
    cover_image: Optional[str] = None
    borrow_count: int = 0

    score: float = 0.0
    # UI-friendly score (0..100). Not a probability; normalized for readability.
    score_pct: int = 0


class QueryRequest(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    limit: int = Field(default=10, ge=1, le=50)


async def _fallback_personalized_books(
    *,
    user: User,
    limit: int,
    exclude_book_ids: List[str],
) -> List[Book]:
    """
    FAISS / embedding tabanlı öneri boş dönerse (cold-start veya index mismatch),
    kullanıcı etkileşimlerinden (favori/ödünç/görüntüleme/tıklama) kategori+yazar temelli
    deterministik bir fallback üretir.
    """
    # Local imports to avoid circular deps and keep route module light.
    from collections import Counter
    from app.models.extras import Favorite
    from app.models.extras import BorrowRequest, BorrowRequestStatus
    from app.models.loan import Loan

    favs = await Favorite.find(Favorite.user_id == user.id).sort(-Favorite.created_at).limit(50).to_list()
    borrow_requests = (
        await BorrowRequest.find(
            BorrowRequest.user_id == user.id,
            BorrowRequest.status == BorrowRequestStatus.PENDING,
        )
        .sort(-BorrowRequest.created_at)
        .limit(50)
        .to_list()
    )
    loans = await Loan.find(Loan.user_id == user.id).sort(-Loan.created_at).limit(50).to_list()
    views = (
        await UserEvent.find(
            UserEvent.user_id == user.id,
            UserEvent.event_type == UserEventType.BOOK_VIEW,
        )
        .sort(-UserEvent.created_at)
        .limit(100)
        .to_list()
    )
    clicks = (
        await UserEvent.find(
            UserEvent.user_id == user.id,
            UserEvent.event_type == UserEventType.RECOMMENDATION_CLICK,
        )
        .sort(-UserEvent.created_at)
        .limit(100)
        .to_list()
    )

    seed_ids: List[PydanticObjectId] = []
    for f in favs:
        seed_ids.append(PydanticObjectId(str(f.book_id)))
    for br in borrow_requests:
        seed_ids.append(PydanticObjectId(str(br.book_id)))
    for l in loans:
        seed_ids.append(PydanticObjectId(str(l.book_id)))
    for ev in views:
        if ev.book_id:
            seed_ids.append(PydanticObjectId(str(ev.book_id)))
    for ev in clicks:
        if ev.book_id:
            seed_ids.append(PydanticObjectId(str(ev.book_id)))

    # Nothing to personalize from
    if not seed_ids:
        return []

    seed_books = await Book.find({"_id": {"$in": seed_ids}}).to_list()
    if not seed_books:
        return []

    # Weighted signals: favorites/loans stronger than views/clicks (frequency-aware)
    from collections import defaultdict
    view_counts = defaultdict(int)
    for ev in views:
        if ev.book_id:
            view_counts[str(ev.book_id)] += 1
    click_counts = defaultdict(int)
    for ev in clicks:
        if ev.book_id:
            click_counts[str(ev.book_id)] += 1

    fav_set = {str(f.book_id) for f in favs}
    loan_set = {str(l.book_id) for l in loans}
    req_set = {str(br.book_id) for br in borrow_requests}

    cat_counter: Counter[str] = Counter()
    author_counter: Counter[str] = Counter()
    for b in seed_books:
        bid = str(b.id)
        w = 1.0
        if str(b.id) in fav_set:
            w += 3.0
        if bid in req_set:
            w += 3.5
        if str(b.id) in loan_set:
            w += 4.0
        # frequency-aware boosts (cap to avoid explosions)
        v = float(min(int(view_counts.get(bid, 0)), 50))
        c = float(min(int(click_counts.get(bid, 0)), 50))
        w += 0.25 * v
        w += 0.75 * c
        if b.category:
            cat_counter[b.category] += w
        if b.author:
            author_counter[b.author] += w

    top_categories = [c for c, _ in cat_counter.most_common(3)]
    top_authors = [a for a, _ in author_counter.most_common(3)]
    if not top_categories and not top_authors:
        return []

    ors: List[dict] = []
    if top_categories:
        ors.append({"category": {"$in": top_categories}})
    if top_authors:
        ors.append({"author": {"$in": top_authors}})

    query: dict = {"$or": ors} if ors else {}

    # Exclude history if requested
    if exclude_book_ids:
        try:
            exclude_oids = [PydanticObjectId(x) for x in exclude_book_ids]
            query = {"$and": [query, {"_id": {"$nin": exclude_oids}}]} if query else {"_id": {"$nin": exclude_oids}}
        except Exception:
            # If anything goes wrong with ids, keep query without exclude rather than failing recommendations.
            pass

    # Prefer popular+newer
    return await Book.find(query).sort(-Book.borrow_count, -Book.created_at).limit(limit).to_list()


@router.post("/query", response_model=List[RecommendationBook])
async def recommend_by_query(data: QueryRequest):
    """
    Doğal dil metne göre kitap önerisi (semantic search).
    """
    try:
        # CPU-bound (embedding + faiss + rerank) → do not block event-loop
        hits = await anyio.to_thread.run_sync(search_by_text, data.text, data.limit)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))

    ids = [PydanticObjectId(h.book_id) for h in hits]
    if not ids:
        return []

    # Beanie operator helpers can vary by version; raw MongoDB query is the most reliable.
    books = await Book.find({"_id": {"$in": ids}}).to_list()
    by_id = {str(b.id): b for b in books}

    out: List[RecommendationBook] = []
    for h in hits:
        b = by_id.get(h.book_id)
        if not b:
            continue
        out.append(
            RecommendationBook(
                id=str(b.id),
                isbn=b.isbn,
                title=b.title,
                author=b.author,
                category=b.category,
                publisher=b.publisher,
                publish_year=b.publish_year,
                language=b.language,
                pages=b.pages,
                total_copies=b.total_copies,
                available_copies=b.available_copies,
                location=b.location,
                description=b.description,
                cover_image=b.cover_image,
                borrow_count=b.borrow_count,
                score=h.score,
                score_pct=max(0, min(100, int(round(h.score * 100)))),
            )
        )
    return out


@router.get("/me", response_model=List[RecommendationBook])
async def recommend_for_me(
    limit: int = Query(10, ge=1, le=50),
    q: Optional[str] = Query(None, description="İsteğe bağlı: kullanıcı profili + query hibrit öneri"),
    include_history: bool = Query(False, description="Ödünç/favori/izlenen kitapları da sonuçta göster"),
    current_user: User = Depends(get_current_active_user),
):
    """
    Kişiselleştirilmiş öneri:
    - favorites + loans + book_view event’lerinden user profil embedding’i oluşturur.
    - istenirse `q` ile hibritleştirir.
    """
    exclude: List[str] = []
    if not include_history:
        # exclude favorites + loans by default
        from app.models.extras import Favorite
        from app.models.loan import Loan

        favs = await Favorite.find(Favorite.user_id == current_user.id).to_list()
        loans = await Loan.find(Loan.user_id == current_user.id).to_list()
        exclude = [str(f.book_id) for f in favs] + [str(l.book_id) for l in loans]

    hits = []
    try:
        hits = await recommend_for_user(
            user_id=str(current_user.id),
            limit=limit,
            query=q,
            exclude_book_ids=exclude,
        )
    except RuntimeError as e:
        # Critical UX: if AI index isn't ready (or temporarily unavailable), DO NOT fail the endpoint.
        # Instead, fallback to deterministic personalization from user history so the UI actually changes.
        logger.warning("recommend_for_user unavailable, falling back (user_id=%s): %s", str(current_user.id), str(e))
        hits = []
    except Exception as e:
        logger.exception("recommend_for_user failed unexpectedly (user_id=%s): %s", str(current_user.id), str(e))
        raise HTTPException(status_code=500, detail="Öneri sistemi şu an hata verdi. Lütfen tekrar deneyin.")

    ids = [PydanticObjectId(h.book_id) for h in hits]
    if not ids:
        # Cold-start fallback: latest books
        personalized = await _fallback_personalized_books(
            user=current_user,
            limit=limit,
            exclude_book_ids=exclude,
        )
        latest = personalized or (await Book.find().sort(-Book.created_at).limit(limit).to_list())
        return [
            RecommendationBook(
                id=str(b.id),
                isbn=b.isbn,
                title=b.title,
                author=b.author,
                publisher=b.publisher,
                publish_year=b.publish_year,
                language=b.language,
                category=b.category,
                pages=b.pages,
                total_copies=b.total_copies,
                available_copies=b.available_copies,
                location=b.location,
                description=b.description,
                cover_image=b.cover_image,
                borrow_count=b.borrow_count,
                score=0.0,
                score_pct=0,
            )
            for b in latest
        ]

    books = await Book.find({"_id": {"$in": ids}}).to_list()
    by_id = {str(b.id): b for b in books}

    out: List[RecommendationBook] = []
    for h in hits:
        b = by_id.get(h.book_id)
        if not b:
            continue
        out.append(
            RecommendationBook(
                id=str(b.id),
                isbn=b.isbn,
                title=b.title,
                author=b.author,
                category=b.category,
                publisher=b.publisher,
                publish_year=b.publish_year,
                language=b.language,
                pages=b.pages,
                total_copies=b.total_copies,
                available_copies=b.available_copies,
                location=b.location,
                description=b.description,
                cover_image=b.cover_image,
                borrow_count=b.borrow_count,
                score=h.score,
                score_pct=max(0, min(100, int(round(h.score * 100)))),
            )
        )
    return out


