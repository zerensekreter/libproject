from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel

from app.models.user import User, UserRole
from app.models.loan import Loan, LoanStatus
from app.routes.auth import get_current_active_user, get_admin_user

router = APIRouter()

class UserResponse(BaseModel):
    id: str
    email: str
    student_id: str
    full_name: str
    department: Optional[str] = None
    role: UserRole
    is_active: bool
    is_verified: bool
    max_books: int
    borrowed_books: int = 0

@router.get("/", response_model=List[UserResponse])
async def get_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    current_user: User = Depends(get_admin_user)
):
    """Get all users (admin only)"""
    query = {}
    
    if search:
        query = {
            "$or": [
                {"full_name": {"$regex": search, "$options": "i"}},
                {"email": {"$regex": search, "$options": "i"}},
                {"student_id": {"$regex": search, "$options": "i"}}
            ]
        }
    
    users = await User.find(query).skip(skip).limit(limit).to_list()
    
    result = []
    for user in users:
        # Count active loans
        borrowed = await Loan.find(
            Loan.user_id == user.id,
            Loan.status == LoanStatus.ACTIVE
        ).count()
        
        result.append(UserResponse(
            id=str(user.id),
            email=user.email,
            student_id=user.student_id,
            full_name=user.full_name,
            department=user.department,
            role=user.role,
            is_active=user.is_active,
            is_verified=getattr(user, 'is_verified', False),
            max_books=user.max_books,
            borrowed_books=borrowed
        ))
    
    return result

@router.get("/lookup/{student_id}", response_model=UserResponse)
async def lookup_user_by_student_id(
    student_id: str,
    current_user: User = Depends(get_admin_user)
):
    """Lookup user by student ID (for admin autofill)"""
    user = await User.find_one(User.student_id == student_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    borrowed = await Loan.find(
        Loan.user_id == user.id,
        Loan.status == LoanStatus.ACTIVE
    ).count()
    
    return UserResponse(
        id=str(user.id),
        email=user.email,
        student_id=user.student_id,
        full_name=user.full_name,
        department=user.department,
        role=user.role,
        is_active=user.is_active,
        is_verified=getattr(user, 'is_verified', False),
        max_books=user.max_books,
        borrowed_books=borrowed
    )

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """Get user by ID"""
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check access
    if str(current_user.id) != user_id and current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Access denied")
    
    borrowed = await Loan.find(
        Loan.user_id == user.id,
        Loan.status == LoanStatus.ACTIVE
    ).count()
    
    return UserResponse(
        id=str(user.id),
        email=user.email,
        student_id=user.student_id,
        full_name=user.full_name,
        department=user.department,
        role=user.role,
        is_active=user.is_active,
        is_verified=getattr(user, 'is_verified', False),
        max_books=user.max_books,
        borrowed_books=borrowed
    )

@router.delete("/{user_id}")
async def deactivate_user(
    user_id: str,
    current_user: User = Depends(get_admin_user)
):
    """Deactivate user (admin only)"""
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.is_active = False
    await user.save()
    
    return {"message": "User deactivated successfully"}


class UserUpdate(BaseModel):
    role: Optional[str] = None
    password: Optional[str] = None
    is_active: Optional[bool] = None
    is_verified: Optional[bool] = None
    max_books: Optional[int] = None


@router.put("/{user_id}")
async def update_user(
    user_id: str,
    update_data: UserUpdate,
    current_user: User = Depends(get_admin_user)
):
    """Update user role, password, status (admin only)"""
    from app.security.passwords import hash_password
    
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if update_data.role:
        if update_data.role not in ["student", "faculty", "admin"]:
            raise HTTPException(status_code=400, detail="Invalid role")
        user.role = UserRole(update_data.role)
    
    if update_data.password:
        if len(update_data.password) < 6:
            raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
        user.hashed_password = hash_password(update_data.password)
    
    if update_data.is_active is not None:
        user.is_active = update_data.is_active
        
    if update_data.is_verified is not None:
        user.is_verified = update_data.is_verified
    
    if update_data.max_books is not None:
        user.max_books = update_data.max_books
    
    await user.save()
    
    return {"message": "User updated successfully"}


class UserDetailResponse(BaseModel):
    id: str
    email: str
    student_id: str
    full_name: str
    department: Optional[str] = None
    role: str
    is_active: bool
    is_verified: bool
    max_books: int
    borrowed_books: int = 0
    loans: list = []


@router.get("/{user_id}/detail")
async def get_user_detail(
    user_id: str,
    current_user: User = Depends(get_admin_user)
):
    """Get user detail with loan history (admin only)"""
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get all loans for this user
    loans = await Loan.find(Loan.user_id == user.id).to_list()
    
    loan_list = []
    for loan in loans:
        loan_list.append({
            "id": str(loan.id),
            "book_title": loan.book_title,
            "checkout_at": loan.checkout_at.isoformat() if loan.checkout_at else None,
            "due_date": loan.due_date.isoformat() if loan.due_date else None,
            "returned_at": loan.returned_at.isoformat() if loan.returned_at else None,
            "status": loan.status.value,
            "fine_amount": loan.fine_amount
        })
    
    borrowed_count = len([l for l in loans if l.status == LoanStatus.ACTIVE])
    
    return UserDetailResponse(
        id=str(user.id),
        email=user.email,
        student_id=user.student_id,
        full_name=user.full_name,
        department=user.department,
        role=user.role.value,
        is_active=user.is_active,
        is_verified=getattr(user, 'is_verified', False),
        max_books=user.max_books,
        borrowed_books=borrowed_count,
        loans=loan_list
    )

