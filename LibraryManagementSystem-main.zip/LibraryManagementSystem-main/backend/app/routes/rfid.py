"""
RFID API Endpointleri.

- GET  /api/v1/rfid/read                                → Anlık kart okuma
- GET  /api/v1/rfid/status                              → RFID servis durumu
- GET  /api/v1/rfid/lookup/{uid}                        → UID ile BookCopy bilgisi
- POST /api/v1/rfid/scan-lookup                         → Donanım taraması + kitap arama
- GET  /api/v1/rfid/copies/{book_id}                    → Kitaba ait tüm kopyaları listele
- DELETE /api/v1/rfid/copies/{copy_id}                  → RFID etiketini sil (BookCopy kaldır)
- POST /api/v1/books/{book_id}/assign-rfid              → Kitaba RFID ata (BookCopy oluştur)
- POST /api/v1/books/{book_id}/start-rfid-assignment    → RFID atama akışı (donanım okuma + otomatik oluşturma)
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from typing import Optional, List
from pydantic import BaseModel
from beanie import PydanticObjectId
import logging

from app.models.book import Book
from app.models.book_copy import BookCopy, BookCopyStatus
from app.models.user import User
from app.routes.auth import get_admin_user

router = APIRouter()
assign_router = APIRouter()  # Ayrı router — /api/v1/books prefix'i ile mount edilecek
logger = logging.getLogger(__name__)


# ── Pydantic Schemas ──────────────────────────────────────

class RFIDReadResponse(BaseModel):
    uid: Optional[str] = None
    read_at: Optional[str] = None

class RFIDStatusResponse(BaseModel):
    connected: bool
    last_uid: Optional[str] = None
    last_read_at: Optional[str] = None

class AssignRFIDRequest(BaseModel):
    timeout: int = 30
    rfid_uid: Optional[str] = None  # Manuel UID girişi (opsiyonel)

class BookCopyResponse(BaseModel):
    id: str
    book_id: str
    rfid_uid: str
    status: BookCopyStatus
    location: Optional[str] = None
    notes: Optional[str] = None
    book_title: Optional[str] = None
    book_isbn: Optional[str] = None
    book_author: Optional[str] = None
    book_cover: Optional[str] = None
    created_at: Optional[str] = None


class StartAssignmentRequest(BaseModel):
    timeout: int = 30


class ScanLookupRequest(BaseModel):
    timeout: int = 10


class ScanLookupResponse(BaseModel):
    uid: Optional[str] = None
    found: bool = False
    copy: Optional[BookCopyResponse] = None
    message: str = ""


# ── Helper ────────────────────────────────────────────────

def _get_rfid_service(request: Request):
    """RFID servisini app state'den al. Yoksa hata fırlat."""
    rfid_service = getattr(request.app.state, "rfid_service", None)
    if rfid_service is None:
        raise HTTPException(
            status_code=503,
            detail="RFID servisi aktif değil. RFID_ENABLED=true olarak ayarlayın ve okuyucuyu bağlayın."
        )
    return rfid_service


# ── Endpoints ─────────────────────────────────────────────

@router.get("/read", response_model=RFIDReadResponse)
async def read_rfid_card(
    request: Request,
    timeout: int = 5,
    current_user: User = Depends(get_admin_user),
):
    """
    RFID okuyucudan anlık kart oku.
    Kart okuyucu üzerinde kart varsa UID döndürür.
    """
    rfid_service = _get_rfid_service(request)

    uid = await rfid_service.wait_for_card(timeout=timeout)

    if uid:
        return RFIDReadResponse(
            uid=uid,
            read_at=rfid_service.get_last_uid().get("read_at"),
        )

    return RFIDReadResponse(uid=None, read_at=None)


@router.get("/status", response_model=RFIDStatusResponse)
async def rfid_status(
    request: Request,
    current_user: User = Depends(get_admin_user),
):
    """RFID servis durumunu döndür."""
    rfid_service = getattr(request.app.state, "rfid_service", None)

    if rfid_service is None:
        return RFIDStatusResponse(connected=False)

    status = rfid_service.get_status()
    return RFIDStatusResponse(**status)


@router.get("/lookup/{uid}", response_model=BookCopyResponse)
async def lookup_rfid(
    uid: str,
    current_user: User = Depends(get_admin_user),
):
    """UID ile BookCopy bilgisi getir."""
    book_copy = await BookCopy.find_one(BookCopy.rfid_uid == uid.upper())
    if not book_copy:
        raise HTTPException(status_code=404, detail="Bu RFID UID'ye ait kitap kopyası bulunamadı")

    book = await Book.get(book_copy.book_id)

    return BookCopyResponse(
        id=str(book_copy.id),
        book_id=str(book_copy.book_id),
        rfid_uid=book_copy.rfid_uid,
        status=book_copy.status,
        location=book_copy.location,
        notes=book_copy.notes,
        book_title=book.title if book else None,
        book_isbn=book.isbn if book else None,
        book_author=book.author if book else None,
        book_cover=book.cover_image if book else None,
        created_at=book_copy.created_at.isoformat() if book_copy.created_at else None,
    )


@router.post("/scan-lookup", response_model=ScanLookupResponse)
async def scan_and_lookup(
    request: Request,
    data: ScanLookupRequest = ScanLookupRequest(),
    current_user: User = Depends(get_admin_user),
):
    """
    RFID donanımından kart oku ve BookCopy veritabanında ara.
    Kart bulunursa kitap bilgilerini döndürür.
    """
    rfid_service = _get_rfid_service(request)

    uid = await rfid_service.wait_for_card(timeout=data.timeout)
    if not uid:
        return ScanLookupResponse(
            uid=None,
            found=False,
            message=f"RFID kartı {data.timeout} saniye içinde okunamadı.",
        )

    uid = uid.upper().strip()

    book_copy = await BookCopy.find_one(BookCopy.rfid_uid == uid)
    if not book_copy:
        return ScanLookupResponse(
            uid=uid,
            found=False,
            message=f"UID '{uid}' sistemde kayıtlı değil.",
        )

    book = await Book.get(book_copy.book_id)

    return ScanLookupResponse(
        uid=uid,
        found=True,
        copy=BookCopyResponse(
            id=str(book_copy.id),
            book_id=str(book_copy.book_id),
            rfid_uid=book_copy.rfid_uid,
            status=book_copy.status,
            location=book_copy.location,
            notes=book_copy.notes,
            book_title=book.title if book else None,
            book_isbn=book.isbn if book else None,
            book_author=book.author if book else None,
            book_cover=book.cover_image if book else None,
            created_at=book_copy.created_at.isoformat() if book_copy.created_at else None,
        ),
        message=f"Kitap bulundu: {book.title if book else 'Bilinmeyen'}",
    )


@router.get("/copies/{book_id}", response_model=List[BookCopyResponse])
async def get_book_copies(
    book_id: str,
    current_user: User = Depends(get_admin_user),
):
    """Bir kitaba ait tüm fiziksel kopyaları (BookCopy) listele."""
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Kitap bulunamadı")

    copies = await BookCopy.find(BookCopy.book_id == book.id).to_list()

    return [
        BookCopyResponse(
            id=str(c.id),
            book_id=str(c.book_id),
            rfid_uid=c.rfid_uid,
            status=c.status,
            location=c.location,
            notes=c.notes,
            book_title=book.title,
            book_isbn=book.isbn,
            book_author=book.author,
            book_cover=book.cover_image,
            created_at=c.created_at.isoformat() if c.created_at else None,
        )
        for c in copies
    ]


@router.delete("/copies/{copy_id}")
async def delete_book_copy(
    copy_id: str,
    current_user: User = Depends(get_admin_user),
):
    """
    RFID etiketini sil (BookCopy kaldır).
    Book.total_copies ve available_copies güncellenir.
    """
    book_copy = await BookCopy.get(PydanticObjectId(copy_id))
    if not book_copy:
        raise HTTPException(status_code=404, detail="Kitap kopyası bulunamadı")

    book = await Book.get(book_copy.book_id)

    await book_copy.delete()

    if book:
        book.total_copies = max(0, book.total_copies - 1)
        if book_copy.status == BookCopyStatus.AVAILABLE:
            book.available_copies = max(0, book.available_copies - 1)
        await book.save()
        logger.info(f"RFID silindi: Book='{book.title}' UID={book_copy.rfid_uid}")

    return {"message": "RFID etiketi başarıyla silindi"}

@assign_router.post("/{book_id}/assign-rfid", response_model=BookCopyResponse)
async def assign_rfid_to_book(
    book_id: str,
    request: Request,
    data: AssignRFIDRequest = AssignRFIDRequest(),
    current_user: User = Depends(get_admin_user),
):
    """
    Kitaba RFID etiketi ata ve yeni BookCopy oluştur.
    
    İş akışı:
    1. rfid_uid verilmişse onu kullan, yoksa okuyucudan oku
    2. UID'nin başka bir BookCopy'de kullanılmadığını kontrol et
    3. Yeni BookCopy oluştur
    4. Book.total_copies ve available_copies güncelle
    """
    # Kitabı bul
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Kitap bulunamadı")

    # UID belirle
    uid = data.rfid_uid
    if not uid:
        # Okuyucudan oku
        rfid_service = _get_rfid_service(request)
        uid = await rfid_service.wait_for_card(timeout=data.timeout)
        if not uid:
            raise HTTPException(
                status_code=408,
                detail=f"RFID kartı {data.timeout} saniye içinde okunamadı. Lütfen kartı okuyucuya yaklaştırın."
            )

    uid = uid.upper().strip()

    # UID benzersizlik kontrolü
    existing = await BookCopy.find_one(BookCopy.rfid_uid == uid)
    if existing:
        existing_book = await Book.get(existing.book_id)
        raise HTTPException(
            status_code=409,
            detail=f"Bu RFID etiketi zaten '{existing_book.title if existing_book else 'bilinmeyen'}' kitabına atanmış."
        )

    # BookCopy oluştur
    book_copy = BookCopy(
        book_id=book.id,
        rfid_uid=uid,
        status=BookCopyStatus.AVAILABLE,
        location=book.location,
    )
    await book_copy.insert()

    # Book kopya sayılarını güncelle
    book.total_copies += 1
    book.available_copies += 1
    await book.save()

    logger.info(f"RFID atandı: Book='{book.title}' UID={uid} CopyID={book_copy.id}")

    return BookCopyResponse(
        id=str(book_copy.id),
        book_id=str(book_copy.book_id),
        rfid_uid=book_copy.rfid_uid,
        status=book_copy.status,
        location=book_copy.location,
        notes=book_copy.notes,
        book_title=book.title,
        book_isbn=book.isbn,
        book_author=book.author,
        book_cover=book.cover_image,
        created_at=book_copy.created_at.isoformat() if book_copy.created_at else None,
    )


@assign_router.post("/{book_id}/start-rfid-assignment", response_model=BookCopyResponse)
async def start_rfid_assignment(
    book_id: str,
    request: Request,
    data: StartAssignmentRequest = StartAssignmentRequest(),
    current_user: User = Depends(get_admin_user),
):
    """
    RFID atama akışı (UX dostu).

    Donanımdan kart okur, benzersizlik kontrolü yapar ve
    otomatik olarak BookCopy oluşturur.
    """
    book = await Book.get(PydanticObjectId(book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Kitap bulunamadı")

    rfid_service = _get_rfid_service(request)
    uid = await rfid_service.wait_for_card(timeout=data.timeout)
    if not uid:
        raise HTTPException(
            status_code=408,
            detail=f"RFID kartı {data.timeout} saniye içinde okunamadı. Lütfen kartı okuyucuya yaklaştırın.",
        )

    uid = uid.upper().strip()

    # UID benzersizlik kontrolü
    existing = await BookCopy.find_one(BookCopy.rfid_uid == uid)
    if existing:
        existing_book = await Book.get(existing.book_id)
        raise HTTPException(
            status_code=409,
            detail=f"Bu RFID etiketi zaten '{existing_book.title if existing_book else 'bilinmeyen'}' kitabına atanmış.",
        )

    # BookCopy oluştur
    book_copy = BookCopy(
        book_id=book.id,
        rfid_uid=uid,
        status=BookCopyStatus.AVAILABLE,
        location=book.location,
    )
    await book_copy.insert()

    # Book kopya sayılarını güncelle
    book.total_copies += 1
    book.available_copies += 1
    await book.save()

    logger.info(f"RFID atama akışı tamamlandı: Book='{book.title}' UID={uid} CopyID={book_copy.id}")

    return BookCopyResponse(
        id=str(book_copy.id),
        book_id=str(book_copy.book_id),
        rfid_uid=book_copy.rfid_uid,
        status=book_copy.status,
        location=book_copy.location,
        notes=book_copy.notes,
        book_title=book.title,
        book_isbn=book.isbn,
        book_author=book.author,
        book_cover=book.cover_image,
        created_at=book_copy.created_at.isoformat() if book_copy.created_at else None,
    )
