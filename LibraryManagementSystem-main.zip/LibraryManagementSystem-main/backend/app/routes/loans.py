from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel
from datetime import datetime, timedelta, UTC

from app.models.loan import Loan, LoanStatus
from app.models.book import Book
from app.models.book_copy import BookCopy, BookCopyStatus
from app.models.user import User, UserRole
from app.routes.auth import get_current_active_user, get_admin_user

router = APIRouter()

class LoanCheckout(BaseModel):
    user_id: str
    book_id: str
    due_days: int = 14

class LoanReturn(BaseModel):
    loan_id: str
    notes: Optional[str] = None

class LoanResponse(BaseModel):
    id: str
    user_id: str
    book_id: str
    user_name: Optional[str] = None
    book_title: Optional[str] = None
    checkout_at: datetime
    due_date: datetime
    returned_at: Optional[datetime] = None
    status: LoanStatus
    fine_amount: float

@router.get("/", response_model=List[LoanResponse])
async def get_loans(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    status: Optional[LoanStatus] = None,
    current_user: User = Depends(get_current_active_user)
):
    """Get loans"""
    query = {}
    
    # Non-admin sees only their loans
    if current_user.role != UserRole.ADMIN:
        query["user_id"] = current_user.id
    
    if status:
        query["status"] = status
    
    loans = await Loan.find(query).sort(-Loan.checkout_at).skip(skip).limit(limit).to_list()
    
    return [LoanResponse(
        id=str(l.id),
        user_id=str(l.user_id),
        book_id=str(l.book_id),
        user_name=l.user_name,
        book_title=l.book_title,
        checkout_at=l.checkout_at,
        due_date=l.due_date,
        returned_at=l.returned_at,
        status=l.status,
        fine_amount=l.fine_amount
    ) for l in loans]

@router.get("/my-loans", response_model=List[LoanResponse])
async def get_my_loans(current_user: User = Depends(get_current_active_user)):
    """Get current user's active loans"""
    loans = await Loan.find(
        Loan.user_id == current_user.id,
        {"status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]}}
    ).to_list()
    
    return [LoanResponse(
        id=str(l.id),
        user_id=str(l.user_id),
        book_id=str(l.book_id),
        user_name=l.user_name,
        book_title=l.book_title,
        checkout_at=l.checkout_at,
        due_date=l.due_date,
        returned_at=l.returned_at,
        status=l.status,
        fine_amount=l.fine_amount
    ) for l in loans]

@router.post("/checkout", response_model=LoanResponse)
async def checkout_book(
    data: LoanCheckout,
    current_user: User = Depends(get_admin_user)
):
    """Checkout a book to a user (admin only)"""
    # Get user
    user = await User.get(PydanticObjectId(data.user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if not user.is_active:
        raise HTTPException(status_code=400, detail="User account is deactivated")
    
    # Check loan limit
    active_loans = await Loan.find(
        Loan.user_id == user.id,
        Loan.status == LoanStatus.ACTIVE
    ).count()
    
    if active_loans >= user.max_books:
        raise HTTPException(status_code=400, detail=f"User has reached maximum loan limit ({user.max_books})")
    
    # Get book
    book = await Book.get(PydanticObjectId(data.book_id))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    
    if book.available_copies <= 0:
        raise HTTPException(status_code=400, detail="No available copies")
    
    # Create loan
    loan = Loan(
        user_id=user.id,
        book_id=book.id,
        user_name=user.full_name,
        user_email=user.email,
        book_title=book.title,
        book_isbn=book.isbn,
        due_date=datetime.now(UTC) + timedelta(days=data.due_days)
    )
    
    # Update book
    book.available_copies -= 1
    book.borrow_count += 1
    
    await loan.insert()
    await book.save()
    
    return LoanResponse(
        id=str(loan.id),
        user_id=str(loan.user_id),
        book_id=str(loan.book_id),
        user_name=loan.user_name,
        book_title=loan.book_title,
        checkout_at=loan.checkout_at,
        due_date=loan.due_date,
        returned_at=loan.returned_at,
        status=loan.status,
        fine_amount=loan.fine_amount
    )

@router.post("/return", response_model=LoanResponse)
async def return_book(
    data: LoanReturn,
    current_user: User = Depends(get_admin_user)
):
    """Return a book (admin only)"""
    loan = await Loan.get(PydanticObjectId(data.loan_id))
    if not loan:
        raise HTTPException(status_code=404, detail="Loan not found")
    
    if loan.status == LoanStatus.RETURNED:
        raise HTTPException(status_code=400, detail="Book already returned")
    
    # Calculate fine
    fine = 0.0
    if datetime.now(UTC) > loan.due_date:
        days_overdue = (datetime.now(UTC) - loan.due_date).days
        fine = days_overdue * 5.0
    
    # Update loan
    loan.returned_at = datetime.now(UTC)
    loan.status = LoanStatus.RETURNED
    loan.fine_amount = fine
    loan.notes = data.notes
    
    # Update book
    book = await Book.get(loan.book_id)
    if book:
        book.available_copies += 1
        await book.save()
    
    await loan.save()
    
    return LoanResponse(
        id=str(loan.id),
        user_id=str(loan.user_id),
        book_id=str(loan.book_id),
        user_name=loan.user_name,
        book_title=loan.book_title,
        checkout_at=loan.checkout_at,
        due_date=loan.due_date,
        returned_at=loan.returned_at,
        status=loan.status,
        fine_amount=loan.fine_amount
    )


@router.get("/history", response_model=List[LoanResponse])
async def get_loan_history(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=500),
    current_user: User = Depends(get_admin_user)
):
    """Get all loan history (admin only) - chronological order"""
    loans = await Loan.find().sort(-Loan.checkout_at).skip(skip).limit(limit).to_list()
    
    return [LoanResponse(
        id=str(l.id),
        user_id=str(l.user_id),
        book_id=str(l.book_id),
        user_name=l.user_name,
        book_title=l.book_title,
        checkout_at=l.checkout_at,
        due_date=l.due_date,
        returned_at=l.returned_at,
        status=l.status,
        fine_amount=l.fine_amount
    ) for l in loans]


@router.get("/overdue", response_model=List[LoanResponse])
async def get_overdue_loans(
    current_user: User = Depends(get_admin_user)
):
    """Get all overdue loans (admin only)"""
    now = datetime.now(UTC)
    
    # Find active loans past due date
    loans = await Loan.find(
        Loan.status == LoanStatus.ACTIVE,
        Loan.due_date < now
    ).sort(-Loan.due_date).to_list()
    
    # Update status to overdue
    for loan in loans:
        if loan.status != LoanStatus.OVERDUE:
            loan.status = LoanStatus.OVERDUE
            await loan.save()
    
    return [LoanResponse(
        id=str(l.id),
        user_id=str(l.user_id),
        book_id=str(l.book_id),
        user_name=l.user_name,
        book_title=l.book_title,
        checkout_at=l.checkout_at,
        due_date=l.due_date,
        returned_at=l.returned_at,
        status=l.status,
        fine_amount=l.fine_amount
    ) for l in loans]


# ── RFID Tabanlı Ödünç İşlemleri ──────────────────────────

class BorrowByRFIDRequest(BaseModel):
    user_id: str
    rfid_uid: str
    due_days: int = 14


@router.post("/borrow-by-rfid", response_model=LoanResponse)
async def borrow_by_rfid(
    data: BorrowByRFIDRequest,
    current_user: User = Depends(get_admin_user),
):
    """
    RFID etiketli kitabı ödünç ver.
    
    İş akışı:
    1. rfid_uid ile BookCopy bul
    2. BookCopy durumunu kontrol et (available olmalı)
    3. İlişkili Book'u getir
    4. Kullanıcı limiti kontrol et
    5. Loan oluştur (book_copy_id ve book_copy_rfid ile)
    6. BookCopy.status = borrowed
    7. Book.available_copies -= 1
    """
    rfid_uid = data.rfid_uid.upper().strip()

    # Kullanıcıyı bul
    user = await User.get(PydanticObjectId(data.user_id))
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    if not user.is_active:
        raise HTTPException(status_code=400, detail="Kullanıcı hesabı devre dışı")

    # Loan limiti kontrol et
    active_loans = await Loan.find(
        Loan.user_id == user.id,
        Loan.status == LoanStatus.ACTIVE,
    ).count()

    if active_loans >= user.max_books:
        raise HTTPException(
            status_code=400,
            detail=f"Kullanıcı maksimum ödünç limitine ulaştı ({user.max_books})"
        )

    # BookCopy bul
    book_copy = await BookCopy.find_one(BookCopy.rfid_uid == rfid_uid)
    if not book_copy:
        raise HTTPException(
            status_code=404,
            detail=f"Bu RFID UID'ye ({rfid_uid}) ait kitap kopyası bulunamadı"
        )

    if book_copy.status != BookCopyStatus.AVAILABLE:
        raise HTTPException(
            status_code=400,
            detail=f"Bu kitap kopyası şu anda uygun değil (durum: {book_copy.status.value})"
        )

    # İlişkili kitabı bul
    book = await Book.get(book_copy.book_id)
    if not book:
        raise HTTPException(status_code=404, detail="İlişkili kitap bulunamadı")

    # Loan oluştur
    loan = Loan(
        user_id=user.id,
        book_id=book.id,
        book_copy_id=book_copy.id,
        book_copy_rfid=rfid_uid,
        user_name=user.full_name,
        user_email=user.email,
        book_title=book.title,
        book_isbn=book.isbn,
        due_date=datetime.now(UTC) + timedelta(days=data.due_days),
    )

    # BookCopy durumunu güncelle
    book_copy.status = BookCopyStatus.BORROWED
    book_copy.updated_at = datetime.now(UTC)

    # Book kopya sayısını güncelle
    book.available_copies = max(0, book.available_copies - 1)
    book.borrow_count += 1

    await loan.insert()
    await book_copy.save()
    await book.save()

    return LoanResponse(
        id=str(loan.id),
        user_id=str(loan.user_id),
        book_id=str(loan.book_id),
        user_name=loan.user_name,
        book_title=loan.book_title,
        checkout_at=loan.checkout_at,
        due_date=loan.due_date,
        returned_at=loan.returned_at,
        status=loan.status,
        fine_amount=loan.fine_amount,
    )


class ReturnByRFIDRequest(BaseModel):
    rfid_uid: str
    notes: Optional[str] = None


@router.post("/return-by-rfid", response_model=LoanResponse)
async def return_by_rfid(
    data: ReturnByRFIDRequest,
    current_user: User = Depends(get_admin_user),
):
    """
    RFID etiketli kitabı iade et.
    
    İş akışı:
    1. rfid_uid ile aktif Loan bul
    2. Gecikme cezası hesapla
    3. Loan'ı kapat
    4. BookCopy.status = available
    5. Book.available_copies += 1
    """
    rfid_uid = data.rfid_uid.upper().strip()

    # Aktif loan bul
    active_loan = await Loan.find_one(
        {
            "book_copy_rfid": rfid_uid,
            "status": {"$in": [LoanStatus.ACTIVE, LoanStatus.OVERDUE]},
        }
    )

    if not active_loan:
        raise HTTPException(
            status_code=404,
            detail=f"Bu RFID UID'ye ({rfid_uid}) ait aktif ödünç kaydı bulunamadı"
        )

    # Gecikme cezası hesapla
    fine = 0.0
    now = datetime.now(UTC)
    if now > active_loan.due_date:
        days_overdue = (now - active_loan.due_date).days
        fine = days_overdue * 5.0

    # Loan'ı güncelle
    active_loan.returned_at = now
    active_loan.status = LoanStatus.RETURNED
    active_loan.fine_amount = fine
    active_loan.notes = data.notes

    # BookCopy durumunu güncelle
    book_copy = await BookCopy.find_one(BookCopy.rfid_uid == rfid_uid)
    if book_copy:
        book_copy.status = BookCopyStatus.AVAILABLE
        book_copy.updated_at = now
        await book_copy.save()

    # Book kopya sayısını güncelle
    book = await Book.get(active_loan.book_id)
    if book:
        book.available_copies += 1
        await book.save()

    await active_loan.save()

    return LoanResponse(
        id=str(active_loan.id),
        user_id=str(active_loan.user_id),
        book_id=str(active_loan.book_id),
        user_name=active_loan.user_name,
        book_title=active_loan.book_title,
        checkout_at=active_loan.checkout_at,
        due_date=active_loan.due_date,
        returned_at=active_loan.returned_at,
        status=active_loan.status,
        fine_amount=active_loan.fine_amount,
    )
