from beanie import Document, Indexed
from pydantic import EmailStr, Field
from typing import Optional
from datetime import datetime, UTC
from enum import Enum

class UserRole(str, Enum):
    STUDENT = "student"
    FACULTY = "faculty"
    ADMIN = "admin"

class User(Document):
    email: Indexed(EmailStr, unique=True)
    student_id: Indexed(str, unique=True)
    full_name: str
    hashed_password: str
    department: Optional[str] = None
    role: UserRole = UserRole.STUDENT
    is_active: bool = True
    is_verified: bool = False
    avatar_url: Optional[str] = None
    max_books: int = 5
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    last_login: Optional[datetime] = None
    
    class Settings:
        name = "users"
        
    class Config:
        json_schema_extra = {
            "example": {
                "email": "ahmet@university.edu.tr",
                "student_id": "2021010001",
                "full_name": "Ahmet Yılmaz",
                "department": "Bilgisayar Mühendisliği",
                "role": "student",
                "is_verified": False
            }
        }


