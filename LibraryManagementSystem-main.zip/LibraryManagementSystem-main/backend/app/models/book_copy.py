from beanie import Document, PydanticObjectId, Indexed
from pydantic import Field
from typing import Optional
from datetime import datetime, UTC
from enum import Enum


class BookCopyStatus(str, Enum):
    AVAILABLE = "available"
    BORROWED = "borrowed"
    LOST = "lost"
    DAMAGED = "damaged"
    MAINTENANCE = "maintenance"


class BookCopy(Document):
    """
    Fiziksel kitap kopyasını temsil eder.
    Her kopyanın benzersiz bir RFID etiketi vardır.
    Aynı kitaptan (Book) birden fazla kopya bulunabilir.
    """
    book_id: Indexed(PydanticObjectId)
    rfid_uid: Indexed(str, unique=True)
    status: BookCopyStatus = BookCopyStatus.AVAILABLE
    location: Optional[str] = None
    notes: Optional[str] = None

    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    class Settings:
        name = "book_copies"
