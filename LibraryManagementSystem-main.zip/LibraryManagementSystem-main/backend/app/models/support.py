from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional
from datetime import datetime, UTC
from enum import Enum


class SessionStatus(str, Enum):
    ACTIVE = "active"
    CLOSED = "closed"


class SenderType(str, Enum):
    USER = "user"
    ADMIN = "admin"
    SYSTEM = "system"


class SupportSession(Document):
    """Kullanıcı-admin arasındaki destek oturumu"""
    user_id: PydanticObjectId
    user_name: str
    user_email: str
    status: SessionStatus = SessionStatus.ACTIVE
    last_message_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    last_message_preview: Optional[str] = None
    unread_count: int = 0  # Admin için okunmamış mesaj sayısı
    user_unread_count: int = 0  # Kullanıcı için okunmamış mesaj sayısı
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    closed_at: Optional[datetime] = None
    
    class Settings:
        name = "support_sessions"


class ChatMessage(Document):
    """Oturum içindeki mesajlar"""
    session_id: PydanticObjectId
    sender_id: Optional[PydanticObjectId] = None  # System mesajları için None
    sender_name: str
    sender_type: SenderType
    content: str
    # WhatsApp-like delivery for USER->ADMIN messages (single tick vs double tick).
    # delivered=True means at least one admin was online / message was deliverable to admin UI.
    delivered: bool = False
    is_read: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    
    class Settings:
        name = "chat_messages"
