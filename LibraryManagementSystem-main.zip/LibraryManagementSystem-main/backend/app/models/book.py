from beanie import Document, Indexed
from pydantic import Field
from typing import Optional
from datetime import datetime, UTC

class Book(Document):
    isbn: Indexed(str, unique=True)
    title: Indexed(str)
    author: Indexed(str)
    publisher: Optional[str] = None
    publish_year: Optional[int] = None
    language: str = "Türkçe"
    category: Optional[str] = None
    dewey_code: Optional[str] = None
    pages: Optional[int] = None
    
    total_copies: int = 1
    available_copies: int = 1
    
    location: Optional[str] = None
    description: Optional[str] = None
    cover_image: Optional[str] = None
    
    borrow_count: int = 0
    rating_average: float = 0.0
    rating_count: int = 0
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    
    class Settings:
        name = "books"



