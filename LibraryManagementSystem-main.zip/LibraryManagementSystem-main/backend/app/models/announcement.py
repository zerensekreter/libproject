from beanie import Document
from pydantic import Field
from typing import Optional
from datetime import datetime, UTC
from enum import Enum

class AnnouncementPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class Announcement(Document):
    title: str
    content: str
    priority: AnnouncementPriority = AnnouncementPriority.MEDIUM
    is_pinned: bool = False
    is_active: bool = True
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    expires_at: Optional[datetime] = None
    
    class Settings:
        name = "announcements"
