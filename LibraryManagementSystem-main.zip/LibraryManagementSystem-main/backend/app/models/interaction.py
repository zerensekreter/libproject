from __future__ import annotations

from beanie import Document, Indexed, PydanticObjectId
from pydantic import Field
from typing import Optional, Dict, Any
from datetime import datetime, UTC
from enum import Enum


class UserEventType(str, Enum):
    BOOK_VIEW = "book_view"
    SEARCH = "search"
    RECOMMENDATION_CLICK = "recommendation_click"


class UserEvent(Document):
    """
    Lightweight event stream for recommendation signals.
    Keep it append-only.
    """

    user_id: Indexed(PydanticObjectId)
    # Note: Beanie's Indexed() cannot wrap Enum types reliably (it subclasses the type).
    # We'll keep it as Enum (stored as str) and index at DB-level via Settings.indexes if needed.
    event_type: UserEventType

    book_id: Optional[PydanticObjectId] = None
    query: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    class Settings:
        name = "user_events"
        indexes = [
            "user_id",
            "event_type",
            "created_at",
        ]


