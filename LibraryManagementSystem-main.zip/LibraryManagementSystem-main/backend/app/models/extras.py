from beanie import Document
from pydantic import Field
from typing import Optional, List
from datetime import datetime, UTC
from enum import Enum
from beanie import PydanticObjectId


class BorrowRequestStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


class BorrowRequest(Document):
    user_id: PydanticObjectId
    book_id: PydanticObjectId
    user_name: str
    user_email: str
    book_title: str
    book_isbn: str
    status: BorrowRequestStatus = BorrowRequestStatus.PENDING
    admin_notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    processed_at: Optional[datetime] = None
    
    class Settings:
        name = "borrow_requests"


class Favorite(Document):
    user_id: PydanticObjectId
    book_id: PydanticObjectId
    book_title: str
    book_author: str
    book_isbn: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    
    class Settings:
        name = "favorites"


class UserNotification(Document):
    user_id: PydanticObjectId
    announcement_id: Optional[PydanticObjectId] = None
    announcement_title: Optional[str] = None
    # Optional context for deep-linking (enterprise UX)
    book_id: Optional[PydanticObjectId] = None
    notification_type: str = "announcement"  # announcement, borrow_request, system
    message: Optional[str] = None
    is_read: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    
    class Settings:
        name = "user_notifications"
