from beanie import Document, PydanticObjectId, Indexed
from pydantic import Field
from typing import Optional
from datetime import datetime, timedelta, UTC
from enum import Enum

class LoanStatus(str, Enum):
    ACTIVE = "active"
    RETURNED = "returned"
    OVERDUE = "overdue"
    LOST = "lost"

class Loan(Document):
    user_id: Indexed(PydanticObjectId)
    book_id: Indexed(PydanticObjectId)
    
    # Store denormalized data for faster queries
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    book_title: Optional[str] = None
    book_isbn: Optional[str] = None
    
    checkout_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    due_date: datetime = Field(default_factory=lambda: datetime.now(UTC) + timedelta(days=14))
    returned_at: Optional[datetime] = None
    
    # RFID entegrasyonu — geriye uyumlu opsiyonel alanlar
    book_copy_id: Optional[PydanticObjectId] = None
    book_copy_rfid: Optional[str] = None
    
    status: LoanStatus = LoanStatus.ACTIVE
    fine_amount: float = 0.0
    notes: Optional[str] = None
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    
    class Settings:
        name = "loans"



