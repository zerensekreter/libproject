from beanie import Document
from pydantic import EmailStr, Field
from datetime import datetime, UTC
from enum import Enum

class ContactStatus(str, Enum):
    NEW = "new"
    READ = "read"
    REPLIED = "replied"
    CLOSED = "closed"

class Contact(Document):
    name: str
    email: EmailStr
    subject: str
    message: str
    status: ContactStatus = ContactStatus.NEW
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    
    class Settings:
        name = "contacts"
