from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
from app.config import settings

# MongoDB client
client = None

async def init_db():
    """Initialize MongoDB connection and Beanie ODM"""
    global client
    client = AsyncIOMotorClient(
        settings.mongodb_url,
        serverSelectionTimeoutMS=getattr(settings, "mongodb_server_selection_timeout_ms", 5000),
        connectTimeoutMS=getattr(settings, "mongodb_connect_timeout_ms", 5000),
    )

    # Fail fast with a clear error if MongoDB is not reachable
    try:
        await client.admin.command({"ping": 1})
    except Exception as e:
        # Close client to avoid dangling sockets
        try:
            client.close()
        except Exception:
            pass
        raise RuntimeError(
            "MongoDB'ye bağlanılamadı. "
            "Lütfen MongoDB'nin çalıştığını doğrulayın (localhost:27017) veya MONGODB_URL ayarını düzeltin. "
            f"Detay: {e}"
        ) from e
    
    # Import models here to avoid circular imports
    from app.models.user import User
    from app.models.book import Book
    from app.models.book_copy import BookCopy
    from app.models.loan import Loan
    from app.models.announcement import Announcement
    from app.models.contact import Contact
    from app.models.extras import BorrowRequest, Favorite, UserNotification
    from app.models.support import SupportSession, ChatMessage
    from app.models.interaction import UserEvent
    
    await init_beanie(
        database=client[settings.database_name],
        document_models=[
            User,
            Book,
            BookCopy,
            Loan,
            Announcement,
            Contact,
            BorrowRequest,
            Favorite,
            UserNotification,
            SupportSession,
            ChatMessage,
            UserEvent,
        ]
    )
    

async def close_db():
    """Close MongoDB connection"""
    global client
    if client:
        client.close()
        
