import os
import sys

# macOS OpenMP runtime workaround:
# Some ML deps (faiss / torch / numpy wheels) can pull multiple OpenMP runtimes and crash the process.
# This keeps dev environment stable on Darwin. If you want to disable it, set KMP_DUPLICATE_LIB_OK=FALSE explicitly.
if sys.platform == "darwin":
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

from fastapi.responses import ORJSONResponse
from fastapi import FastAPI, Response, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from starlette.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import logging
import time

from app.config import settings
from app.database import init_db, close_db
from app.routes import auth, users, books, loans, announcements, contact, admin, extras, support, recommendations, events, realtime, rfid, gate
from app.monitoring import setup_monitoring, get_prometheus_metrics, get_system_stats



# Configure structured logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Rate limiter setup
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[f"{settings.rate_limit_requests}/minute"]
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info(f"Starting {settings.app_name} in {settings.environment} mode")
    # Fail-fast security checks
    settings.validate_secret_key()
    await init_db()
    logger.info("Database connection established")
    
    # RFID Service başlatma
    app.state.rfid_service = None
    if settings.rfid_enabled:
        try:
            from app.services.rfid import RFIDService, RDM6300Reader
            reader = RDM6300Reader(
                port=settings.rfid_port,
                baud_rate=settings.rfid_baud_rate,
                timeout=settings.rfid_timeout,
            )
            rfid_service = RFIDService(reader)
            await rfid_service.start()
            app.state.rfid_service = rfid_service
            logger.info(f"RFID service started on {settings.rfid_port}")
        except Exception as e:
            logger.warning(f"RFID service failed to start: {e} — continuing without RFID")
            app.state.rfid_service = None
    else:
        logger.info("RFID service disabled (RFID_ENABLED=false)")
    
    yield
    # Shutdown
    logger.info("Shutting down application")
    
    # RFID Service durdurma
    if getattr(app.state, 'rfid_service', None):
        try:
            await app.state.rfid_service.stop()
        except Exception as e:
            logger.warning(f"RFID service shutdown error: {e}")
    
    await close_db()

# Create FastAPI app
app = FastAPI(
    default_response_class=ORJSONResponse,
    title=settings.app_name,
    description="Üniversite Kütüphane Yönetim Sistemi API - MongoDB",
    version="2.0.0",
    lifespan=lifespan,
    docs_url="/docs" if not settings.is_production() else None,  # Disable docs only in production
    redoc_url="/redoc" if not settings.is_production() else None,
)

# Rate limiter state
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Trusted hosts (prevent Host header attacks) - keep permissive in dev if needed
if settings.is_production():
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.allowed_hosts or ["*"])

# Gzip compression (perf) - safe for JSON responses
app.add_middleware(GZipMiddleware, minimum_size=800)

# CORS middleware - MUST be before other middlewares to handle preflight requests
# In development, allow all localhost ports using regex
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins if settings.is_production() else ["http://localhost:8080", "http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:8080", "http://127.0.0.1:5173", "http://127.0.0.1:3000"],
    allow_origin_regex=r"http://localhost:\d+|http://127\.0\.0\.1:\d+" if not settings.is_production() else None,  # Allow any localhost port in dev
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],  # Include OPTIONS for preflight
    allow_headers=["Authorization", "Content-Type", "Accept", "Origin", "X-Requested-With"],  # Specific headers
    expose_headers=["X-RateLimit-Limit", "X-RateLimit-Remaining", "X-RateLimit-Reset"],
    max_age=600,  # Cache preflight for 10 minutes
)

# Setup monitoring (after CORS middleware)
setup_monitoring(app)

# Request size limiter (DoS mitigation)
@app.middleware("http")
async def limit_request_size(request: Request, call_next):
    # If Content-Length is present, enforce hard limit early
    cl = request.headers.get("content-length")
    if cl:
        try:
            if int(cl) > int(settings.max_request_size_bytes):
                return JSONResponse(status_code=413, content={"detail": "Request entity too large"})
        except Exception:
            # ignore malformed header
            pass
    return await call_next(request)

# Security Headers Middleware
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    
    # Security headers
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # HSTS should only be sent over HTTPS and in production
    if settings.is_production() and request.url.scheme == "https":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    response.headers["Cross-Origin-Resource-Policy"] = "same-site"

    # CSP: This API is not meant to serve arbitrary webpages. We keep a strict CSP by default.
    # However, Swagger/ReDoc pages load assets from CDN; a too-strict CSP results in a blank page.
    path = request.url.path
    is_docs = path in ("/docs", "/redoc", "/openapi.json") or path.startswith("/docs/")
    if is_docs and not settings.is_production():
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "img-src 'self' https://fastapi.tiangolo.com data:; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "connect-src 'self'; "
            "frame-ancestors 'none'"
        )
    else:
        response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
    
    # Request timing
    process_time = time.time() - start_time
    if not settings.is_production():
        response.headers["X-Process-Time"] = str(process_time)
    
    # Log request (except health checks)
    if request.url.path not in ["/health", "/metrics"]:
        logger.debug(f"{request.method} {request.url.path} - {response.status_code} - {process_time:.3f}s")
    
    return response

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    import traceback
    
    # Log full error details
    error_traceback = traceback.format_exc()
    logger.error(f"Unhandled exception on {request.method} {request.url.path}: {exc}\n{error_traceback}")
    
    # Print to console for development
    if not settings.is_production():
        print(f"\n{'='*80}")
        print(f"ERROR: {exc.__class__.__name__}: {exc}")
        print(f"Path: {request.method} {request.url.path}")
        print(f"{'='*80}")
        print(error_traceback)
        print(f"{'='*80}\n")
    
    # Don't expose internal errors in production
    if settings.is_production():
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"}
        )
    
    # In development, show full error details
    return JSONResponse(
        status_code=500,
        content={
            "detail": str(exc),
            "type": exc.__class__.__name__,
            "traceback": error_traceback.split('\n') if not settings.is_production() else None
        }
    )
    

# Include routers with v1 prefix
app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(users.router, prefix="/api/v1/users", tags=["Users"])
app.include_router(books.router, prefix="/api/v1/books", tags=["Books"])
app.include_router(loans.router, prefix="/api/v1/loans", tags=["Loans"])
app.include_router(announcements.router, prefix="/api/v1/announcements", tags=["Announcements"])
app.include_router(contact.router, prefix="/api/v1/contact", tags=["Contact"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["Admin"])
app.include_router(extras.router, prefix="/api/v1", tags=["Extras"])
app.include_router(support.router, prefix="/api/v1/support", tags=["Support"])
app.include_router(recommendations.router, prefix="/api/v1/recommendations", tags=["Recommendations"])
app.include_router(events.router, prefix="/api/v1/events", tags=["Events"])
app.include_router(realtime.router, prefix="/api/v1/realtime", tags=["Realtime"])
app.include_router(rfid.router, prefix="/api/v1/rfid", tags=["RFID"])
app.include_router(rfid.assign_router, prefix="/api/v1/books", tags=["RFID"])
app.include_router(gate.router, prefix="/api/v1/gate", tags=["Gate Security"])




@app.get("/")
async def root():
    return {
        "message": "Üniversite Kütüphane Yönetim Sistemi API",
        "developer": "Yusufcan Esener",
        "version": "2.0.0",
        "database": "MongoDB",
        "environment": settings.environment,
        "docs": "/docs" if not settings.is_production() else "Disabled in production",
        "Powered by": "Samet KOLEOGLU",
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "database": "MongoDB",
        "environment": settings.environment
    }

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(
        content=get_prometheus_metrics(),
        media_type="text/plain; version=0.0.4; charset=utf-8"
    )

@app.get("/api/v1/admin/system-metrics")
async def system_metrics():
    """Detailed system metrics for monitoring"""
    return get_system_stats()