"""
Soyut RFID okuyucu arayüzü.

İleride farklı okuyucu türlerine (RDM6300 125kHz, RGM6001 UHF, vb.)
geçiş yapılabilmesi için soyut temel sınıf olarak tasarlandı.
"""
from abc import ABC, abstractmethod
from typing import Optional


class BaseRFIDReader(ABC):
    """
    Tüm RFID okuyucu implementasyonlarının uygulaması gereken arayüz.

    Yeni bir okuyucu eklemek için bu sınıfı miras alın ve
    tüm abstract metodları implement edin.
    """

    @abstractmethod
    async def connect(self) -> bool:
        """
        Okuyucuya bağlan.
        Returns:
            True — bağlantı başarılı
        Raises:
            ConnectionError — bağlantı başarısız
        """
        ...

    @abstractmethod
    async def disconnect(self) -> None:
        """Okuyucu bağlantısını temiz bir şekilde kapat."""
        ...

    @abstractmethod
    async def read_uid(self) -> Optional[str]:
        """
        Anlık tek okuma yap.
        Returns:
            UID string veya None (kart yoksa)
        """
        ...

    @abstractmethod
    async def wait_for_card(self, timeout: int = 30) -> Optional[str]:
        """
        Belirtilen süre boyunca kart bekle ve ilk okunan UID'yi döndür.
        Args:
            timeout: Maksimum bekleme süresi (saniye)
        Returns:
            UID string veya None (zaman aşımı)
        """
        ...

    @abstractmethod
    def is_connected(self) -> bool:
        """Okuyucunun bağlı olup olmadığını döndür."""
        ...
