"""
RDM6300 125kHz RFID okuyucu implementasyonu.

Donanım: RDM6300 + PL2303 USB-TTL dönüştürücü
Protokol: UART 9600 baud
Veri Formatı: [STX(0x02)] [10 hex chars data] [2 hex chars checksum] [ETX(0x03)]

Data kısmı (10 hex char):
  - İlk 2 char: Version/type byte
  - Son 8 char: UID (kartın benzersiz kimliği)
"""
import asyncio
import logging
from typing import Optional

import serial

from app.services.rfid.base_reader import BaseRFIDReader

logger = logging.getLogger(__name__)


class RDM6300Reader(BaseRFIDReader):
    """
    RDM6300 125kHz RFID okuyucu.
    Serial port üzerinden UART protokolü ile iletişim kurar.
    """

    # RDM6300 protokol sabitleri
    STX = 0x02  # Start of text
    ETX = 0x03  # End of text
    PACKET_SIZE = 14  # STX(1) + DATA(10) + CHECKSUM(2) + ETX(1)

    def __init__(self, port: str = "COM8", baud_rate: int = 9600, timeout: float = 0.1):
        self._port = port
        self._baud_rate = baud_rate
        self._timeout = timeout
        self._serial: Optional[serial.Serial] = None
        self._connected = False

    async def connect(self) -> bool:
        """Serial port üzerinden RDM6300'e bağlan."""
        try:
            # Serial açma blocking bir işlem — thread'e delege et
            self._serial = await asyncio.to_thread(
                serial.serial_for_url,
                self._port,
                baudrate=self._baud_rate,
                timeout=self._timeout,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
            )
            self._connected = True
            logger.info(f"RDM6300 bağlantısı kuruldu: {self._port} @ {self._baud_rate} baud")
            return True
        except serial.SerialException as e:
            self._connected = False
            logger.error(f"RDM6300 bağlantı hatası ({self._port}): {e}")
            raise ConnectionError(f"RFID okuyucuya bağlanılamadı: {self._port} — {e}") from e

    async def disconnect(self) -> None:
        """Serial port bağlantısını kapat."""
        if self._serial and self._serial.is_open:
            try:
                await asyncio.to_thread(self._serial.close)
                logger.info("RDM6300 bağlantısı kapatıldı")
            except Exception as e:
                logger.warning(f"RDM6300 kapatma hatası: {e}")
            finally:
                self._connected = False
                self._serial = None

    async def read_uid(self) -> Optional[str]:
        """
        Anlık tek okuma yap.
        Buffer'da veri varsa parse et, yoksa None döndür.
        """
        if not self._serial or not self._serial.is_open:
            return None

        try:
            raw = await asyncio.to_thread(self._read_raw_packet)
            if raw:
                uid = self._parse_packet(raw)
                if uid:
                    logger.debug(f"RFID UID okundu: {uid}")
                return uid
        except serial.SerialException as e:
            logger.error(f"RFID okuma hatası: {e}")
            return None

        return None

    async def wait_for_card(self, timeout: int = 30) -> Optional[str]:
        """
        Belirtilen süre boyunca kart bekle.
        İlk geçerli UID okunduğunda döndür.
        """
        if not self._serial or not self._serial.is_open:
            raise ConnectionError("RFID okuyucu bağlı değil")

        logger.info(f"Kart bekleniyor (timeout: {timeout}s)...")

        # Buffer'ı temizle
        await asyncio.to_thread(self._flush_buffer)

        try:
            uid = await asyncio.wait_for(
                self._poll_for_card(),
                timeout=timeout,
            )
            if uid:
                logger.info(f"Kart okundu: {uid}")
            return uid
        except asyncio.TimeoutError:
            logger.info("Kart bekleme zaman aşımına uğradı")
            return None

    def is_connected(self) -> bool:
        """Bağlantı durumunu döndür."""
        return self._connected and self._serial is not None and self._serial.is_open

    # ──────────────────────────────────────────────
    # Private helpers
    # ──────────────────────────────────────────────

    async def _poll_for_card(self) -> Optional[str]:
        """Kart okunana kadar döngüde bekle (async)."""
        while True:
            uid = await self.read_uid()
            if uid:
                return uid
            await asyncio.sleep(0.05)  # CPU'yu yormamak için kısa bekle

    def _flush_buffer(self) -> None:
        """Serial buffer'ı temizle."""
        if self._serial and self._serial.is_open:
            self._serial.reset_input_buffer()

    def _read_raw_packet(self) -> Optional[bytes]:
        """
        Serial port'tan ham RDM6300 paketi oku.
        Blocking çağrı — asyncio.to_thread ile sarmalanmalı.
        """
        if not self._serial or not self._serial.is_open:
            return None

        # STX byte'ını ara
        while self._serial.in_waiting > 0:
            byte = self._serial.read(1)
            if not byte:
                return None

            if byte[0] == self.STX:
                # STX bulundu, geri kalan 13 byte'ı oku
                remaining = self._serial.read(self.PACKET_SIZE - 1)
                if len(remaining) == self.PACKET_SIZE - 1:
                    return byte + remaining

        return None

    @staticmethod
    def _parse_packet(packet: bytes) -> Optional[str]:
        """
        RDM6300 paketini parse et ve UID döndür.
        
        Paket formatı (14 byte):
            [0x02] [V1 V2 D1 D2 D3 D4 D5 D6 D7 D8] [C1 C2] [0x03]
            
        V1V2: Version byte (hex)
        D1..D8: UID (hex) — 4 byte = 8 hex char
        C1C2: XOR checksum (hex)
        """
        if len(packet) != 14:
            return None

        if packet[0] != RDM6300Reader.STX or packet[-1] != RDM6300Reader.ETX:
            return None

        # Data bölümünü al (index 1..10 → 10 hex char)
        data_hex = packet[1:11].decode("ascii", errors="ignore")

        # Checksum bölümünü al (index 11..12 → 2 hex char)
        checksum_hex = packet[11:13].decode("ascii", errors="ignore")

        # Checksum doğrulama: 5 adet 2-char hex byte'ın XOR'u
        try:
            calc_checksum = 0
            for i in range(0, 10, 2):
                calc_checksum ^= int(data_hex[i : i + 2], 16)

            expected_checksum = int(checksum_hex, 16)

            if calc_checksum != expected_checksum:
                logger.warning(
                    f"RFID checksum hatası: beklenen={expected_checksum:02X}, "
                    f"hesaplanan={calc_checksum:02X}"
                )
                return None
        except (ValueError, IndexError):
            logger.warning("RFID paket parse hatası")
            return None

        # UID: son 8 hex char (version byte'ı hariç)
        uid = data_hex[2:10].upper()
        return uid
