"""
Üst seviye RFID Servis katmanı.

Reader'ı sarmalayarak iş mantığı ekler:
- Son okunan UID'yi saklar
- Bağlantı yönetimi
- API katmanına temiz arayüz sunar
"""
import logging
from datetime import datetime, UTC
from typing import Optional

from app.services.rfid.base_reader import BaseRFIDReader

logger = logging.getLogger(__name__)


class RFIDService:
    """
    RFID iş mantığı servisi.
    
    Herhangi bir BaseRFIDReader implementasyonu ile çalışır.
    Route'lar bu servisi app.state.rfid_service üzerinden kullanır.
    """

    def __init__(self, reader: BaseRFIDReader):
        self._reader = reader
        self._last_uid: Optional[str] = None
        self._last_read_time: Optional[datetime] = None

    async def start(self) -> None:
        """Servisi başlat — reader'a bağlan."""
        await self._reader.connect()
        logger.info("RFID servisi başlatıldı")

    async def stop(self) -> None:
        """Servisi durdur — reader bağlantısını kapat."""
        await self._reader.disconnect()
        logger.info("RFID servisi durduruldu")

    @property
    def is_active(self) -> bool:
        """Servisin aktif olup olmadığını döndür."""
        return self._reader.is_connected()

    async def read_card(self) -> Optional[str]:
        """
        Anlık kart okuma yap.
        Başarılı okumayı son UID olarak saklar.
        """
        uid = await self._reader.read_uid()
        if uid:
            self._last_uid = uid
            self._last_read_time = datetime.now(UTC)
        return uid

    async def wait_for_card(self, timeout: int = 30) -> Optional[str]:
        """
        Belirtilen süre boyunca kart bekle.
        Başarılı okumayı son UID olarak saklar.
        """
        uid = await self._reader.wait_for_card(timeout=timeout)
        if uid:
            self._last_uid = uid
            self._last_read_time = datetime.now(UTC)
        return uid

    def get_last_uid(self) -> dict:
        """
        Son okunan UID bilgisini döndür.
        Returns:
            {"uid": "...", "read_at": "..."} veya {"uid": None, "read_at": None}
        """
        return {
            "uid": self._last_uid,
            "read_at": self._last_read_time.isoformat() if self._last_read_time else None,
        }

    def get_status(self) -> dict:
        """Servis durum bilgisini döndür."""
        return {
            "connected": self.is_active,
            "last_uid": self._last_uid,
            "last_read_at": self._last_read_time.isoformat() if self._last_read_time else None,
        }
