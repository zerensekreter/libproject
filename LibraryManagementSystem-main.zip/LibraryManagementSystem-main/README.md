# 📚 Gelişmiş Kütüphane Yönetim Sistemi

Modern ve kullanıcı dostu bir kütüphane yönetim sistemi. React + FastAPI + MongoDB teknolojileri ile geliştirilmiştir.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.11+-green.svg)
![React](https://img.shields.io/badge/react-18+-blue.svg)

## 🚀 Özellikler

### 👤 Kullanıcı Özellikleri
- ✅ Kayıt ve giriş sistemi (JWT authentication)
- ✅ Kitap arama ve filtreleme
- ✅ Kitap ödünç alma talebi
- ✅ Favori kitaplar listesi
- ✅ Profil yönetimi
- ✅ Gerçek zamanlı bildirim sistemi (5 saniyede bir güncelleme)
- ✅ Ödünç talebi bildirimleri
- ✅ Kapatılabilir toast bildirimleri

### 👨‍💼 Admin Özellikleri
- ✅ Kitap yönetimi (CRUD + ISBN ile otomatik bilgi çekme)
- ✅ Kullanıcı yönetimi
- ✅ Ödünç işlemleri (checkout/return)
- ✅ **Kitap uygunluk kontrolü** (Yeşil: Kiralanabilir / Kırmızı: Kopya yok)
- ✅ Ödünç talepleri onaylama
- ✅ Duyuru yönetimi
- ✅ Geciken kitaplar takibi
- ✅ Gerçek zamanlı sistem izleme (CPU, RAM, Disk, Uptime)
- ✅ İstek istatistikleri (toplam istek, hata oranı, yanıt süresi)

### 🆕 Son Güncelleme (v1.1)
- ✅ Toast bildirimlerinde X butonu ile hızlı kapatma
- ✅ Bildirim dropdown'ında her bildirime X butonu
- ✅ Real-time bildirim güncellemesi (polling)
- ✅ Ödünç verme öncesi kitap müsaitlik durumu gösterimi
- ✅ Skeleton loading animasyonu

## 🛠️ Teknolojiler

### Backend
- **FastAPI** - Modern Python web framework
- **MongoDB** - NoSQL veritabanı
- **Beanie** - MongoDB ODM
- **JWT** - Kimlik doğrulama
- **Prometheus** - Metrik toplama
- **psutil** - Sistem izleme

### Frontend
- **React 18** - UI kütüphanesi
- **TypeScript** - Tip güvenliği
- **Tailwind CSS** - Stil
- **shadcn/ui** - UI bileşenleri
- **Framer Motion** - Animasyonlar
- **Sonner** - Toast bildirimleri
- **React Router** - Routing
- **Axios** - HTTP istekleri

## 📦 Kurulum

### Gereksinimler
- Python 3.11+
- Node.js 18+
- MongoDB

### Backend Kurulumu

```bash
cd backend

# Virtual environment oluştur
python -m venv venv

# Aktifleştir (Windows)
venv\Scripts\activate

# Aktifleştir (Linux/Mac)
source venv/bin/activate

# Bağımlılıkları yükle
pip install -r requirements.txt

# Çalıştır
uvicorn app.main:app --reload --port 8000
```

### Frontend Kurulumu

```bash
cd front-end

# Bağımlılıkları yükle
npm install

# Çalıştır
npm run dev
```

### Ortam Değişkenleri

Backend için `.env` dosyası oluşturun (örnek: `backend/env.example`):
```env
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=library_db
JWT_SECRET_KEY=your-secret-key-here
# 3 gün
ACCESS_TOKEN_EXPIRE_MINUTES=4320
```

Frontend için env (örnek: `front-end/env.example`):
```env
VITE_API_BASE_URL=http://localhost:8000
```

## 🚢 Deployment (Kurumsal / Production)

### Docker Compose (Production)

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

- Frontend: `http://localhost` (port 80)
- Backend: `http://localhost:8000`
- API Docs: Production modda kapalı olabilir (güvenlik için)

### Docker Compose (Development / Hot Reload)

```bash
docker compose up -d --build
```

- Frontend (Vite): `http://localhost:8080`
- Backend: `http://localhost:8000`

## 🌐 API Endpoints

API dokümantasyonu: `http://localhost:8000/docs`

| Endpoint | Açıklama |
|----------|----------|
| `/api/v1/auth/` | Kimlik doğrulama |
| `/api/v1/books/` | Kitap işlemleri |
| `/api/v1/users/` | Kullanıcı işlemleri |
| `/api/v1/loans/` | Ödünç işlemleri |
| `/api/v1/announcements/` | Duyurular |
| `/api/v1/favorites/` | Favoriler |
| `/api/v1/notifications/` | Bildirimler |
| `/api/v1/borrow-requests/` | Ödünç talepleri |
| `/api/v1/admin/` | Admin işlemleri |
| `/api/v1/admin/system-metrics` | Sistem metrikleri |

## 📸 Ekran Görüntüleri

### Ana Sayfa
Modern ve kullanıcı dostu arayüz

### Admin Panel
Gerçek zamanlı sistem izleme ve yönetim araçları

### Kitap Detay
Zengin kitap bilgileri ve ödünç alma seçenekleri

## 🔐 Varsayılan Kullanıcılar

| Rol | E-posta | Şifre |
|-----|---------|-------|
| Admin | admin@library.edu.tr | admin123 |

## 📁 Proje Yapısı

```
Gelişmiş Kütüphane Sistemi/
├── backend/
│   ├── app/
│   │   ├── models/      # Veritabanı modelleri
│   │   ├── routes/      # API endpoint'leri
│   │   ├── monitoring.py # Sistem izleme
│   │   └── main.py      # Ana uygulama
│   └── requirements.txt
├── front-end/
│   ├── src/
│   │   ├── components/  # React bileşenleri
│   │   ├── pages/       # Sayfalar
│   │   ├── lib/         # Yardımcı fonksiyonlar
│   │   └── App.tsx
│   └── package.json
└── README.md
```

## 🤝 Katkıda Bulunma

1. Fork edin
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Commit edin (`git commit -m 'Add amazing feature'`)
4. Push edin (`git push origin feature/amazing-feature`)
5. Pull Request açın

## 📄 Lisans

MIT License - Detaylar için [LICENSE](LICENSE) dosyasına bakın.

## 👨‍💻 Geliştirici

Bu proje eğitim amaçlı geliştirilmiştir.

---

⭐ Projeyi beğendiyseniz yıldız vermeyi unutmayın!