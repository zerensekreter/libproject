export type UserRole = "student" | "faculty" | "admin";

export type Book = {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: string;
  language: string;
  publishYear: number;
  pages: number;
  totalCopies: number;
  availableCopies: number;
  coverImage: string;
  deweyCode?: string;
  rating: number;
  reviewCount: number;
  location: string;
  description: string;
};

export type User = {
  id: string;
  name: string;
  email: string;
  studentId: string;
  department: string;
  avatar: string;
  role: UserRole;
  joinDate: string; // yyyy-mm-dd
  borrowedBooks: number;
  maxBooks: number;
};

export type LoanStatus = "active" | "returned" | "overdue";

export type Loan = {
  id: string;
  bookTitle: string;
  userName: string;
  borrowDate: string; // yyyy-mm-dd
  dueDate: string; // yyyy-mm-dd
  returnDate?: string; // yyyy-mm-dd
  status: LoanStatus;
  fine: number;
};

// --- Minimal mock datasets used by admin UI and some shared components ---
export const mockBooks: Book[] = [
  {
    id: "demo-book-1",
    title: "Yapay Zekâ",
    author: "Cem Say",
    isbn: "9789750738601",
    category: "Bilgisayar",
    language: "Türkçe",
    publishYear: 2018,
    pages: 248,
    totalCopies: 3,
    availableCopies: 1,
    coverImage: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400&h=600&fit=crop",
    rating: 4.6,
    reviewCount: 412,
    location: "A-101",
    description: "Yapay zekâ alanına giriş için temel kavramlar, örnekler ve güncel yaklaşımlar.",
  },
  {
    id: "demo-book-2",
    title: "İnsanlık için Yapay Zekâ",
    author: "Stuart Russell",
    isbn: "9786050624830",
    category: "Bilim",
    language: "Türkçe",
    publishYear: 2020,
    pages: 328,
    totalCopies: 2,
    availableCopies: 0,
    coverImage: "https://images.unsplash.com/photo-1455885666463-0b2c3f37f6d3?w=400&h=600&fit=crop",
    rating: 4.7,
    reviewCount: 287,
    location: "B-204",
    description: "Yapay zekânın insanlık için risk ve fırsatlarını ele alan kapsamlı bir çalışma.",
  },
  {
    id: "demo-book-3",
    title: "Veri Yapıları ve Algoritmalar",
    author: "Robert Sedgewick",
    isbn: "9780134685991",
    category: "Bilgisayar",
    language: "İngilizce",
    publishYear: 2016,
    pages: 992,
    totalCopies: 4,
    availableCopies: 4,
    coverImage: "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=400&h=600&fit=crop",
    rating: 4.5,
    reviewCount: 1091,
    location: "C-011",
    description: "Klasik veri yapıları ve algoritmalar üzerine kapsamlı, pratik odaklı kaynak.",
  },
];

export const mockUsers: User[] = [
  {
    id: "demo-user-1",
    name: "Ahmet Yılmaz",
    email: "2021010001@university.edu.tr",
    studentId: "2021010001",
    department: "Bilgisayar Mühendisliği",
    avatar: "https://api.dicebear.com/7.x/initials/svg?seed=Ahmet%20Yilmaz",
    role: "student",
    joinDate: "2024-09-14",
    borrowedBooks: 1,
    maxBooks: 5,
  },
  {
    id: "demo-user-2",
    name: "Elif Kaya",
    email: "2020010022@university.edu.tr",
    studentId: "2020010022",
    department: "İşletme",
    avatar: "https://api.dicebear.com/7.x/initials/svg?seed=Elif%20Kaya",
    role: "student",
    joinDate: "2023-10-02",
    borrowedBooks: 0,
    maxBooks: 5,
  },
  {
    id: "demo-user-3",
    name: "Admin Kullanıcı",
    email: "admin@university.edu.tr",
    studentId: "A-0001",
    department: "Kütüphane",
    avatar: "https://api.dicebear.com/7.x/initials/svg?seed=Admin",
    role: "admin",
    joinDate: "2023-01-01",
    borrowedBooks: 0,
    maxBooks: 10,
  },
];

export const mockLoans: Loan[] = [
  {
    id: "LN-10001",
    bookTitle: "Yapay Zekâ",
    userName: "Ahmet Yılmaz",
    borrowDate: "2025-12-01",
    dueDate: "2025-12-15",
    status: "active",
    fine: 0,
  },
  {
    id: "LN-10002",
    bookTitle: "İnsanlık için Yapay Zekâ",
    userName: "Elif Kaya",
    borrowDate: "2025-11-01",
    dueDate: "2025-11-15",
    status: "overdue",
    fine: 25,
  },
];

export const mockMonthlyStats = [
  { month: "Oca", loans: 120, returns: 98, newBooks: 12 },
  { month: "Şub", loans: 140, returns: 110, newBooks: 9 },
  { month: "Mar", loans: 160, returns: 150, newBooks: 15 },
  { month: "Nis", loans: 180, returns: 165, newBooks: 14 },
  { month: "May", loans: 210, returns: 190, newBooks: 18 },
  { month: "Haz", loans: 195, returns: 205, newBooks: 11 },
];

export const mockCategoryDistribution = [
  { name: "Bilgisayar", value: 38 },
  { name: "Roman", value: 22 },
  { name: "Bilim", value: 18 },
  { name: "Tarih", value: 12 },
  { name: "Diğer", value: 10 },
];



