import { useParams, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Star,
  MapPin,
  Calendar,
  BookOpen,
  Building,
  Globe,
  FileText,
  Heart,
  Share2,
  CheckCircle2,
  XCircle,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { MainLayout } from "@/components/layout/MainLayout";
import { toast } from "sonner";
import { useState, useEffect, useMemo } from "react";
import { booksAPI, favoritesAPI, borrowRequestsAPI, eventsAPI, loansAPI, getToken, getUser } from "@/lib/api";
import { BookDetailSkeleton } from "@/components/shared/SkeletonCard";
import { invalidateForYouRecommendations } from "@/lib/recommendationsBus";

interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publisher?: string;
  publish_year?: number;
  language: string;
  category?: string;
  pages?: number;
  total_copies: number;
  available_copies: number;
  location?: string;
  description?: string;
  cover_image?: string;
  dewey_code?: string;
}

export default function BookDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteLoading, setFavoriteLoading] = useState(false);
  const [borrowLoading, setBorrowLoading] = useState(false);
  const [borrowStateLoading, setBorrowStateLoading] = useState(false);
  const [pendingRequestId, setPendingRequestId] = useState<string | null>(null);
  const [hasActiveLoanForBook, setHasActiveLoanForBook] = useState(false);
  const [limitReached, setLimitReached] = useState(false);
  const [limitInfo, setLimitInfo] = useState<{ used: number; max: number }>({ used: 0, max: 5 });
  const isLoggedIn = !!getToken();

  const maxBooks = useMemo(() => {
    const u = getUser();
    const v = Number(u?.max_books);
    return Number.isFinite(v) && v > 0 ? v : 5;
  }, []);

  useEffect(() => {
    const fetchBook = async () => {
      if (!id) return;
      try {
        const data = await booksAPI.getById(id);
        setBook(data);

        // Check if book is in favorites
        if (isLoggedIn) {
          try {
            const favCheck = await favoritesAPI.check(id);
            setIsFavorite(favCheck.is_favorite);
          } catch (error) {
            console.error("Error checking favorite:", error);
          }

          // Track book view (AI personalization signal)
          try {
            await eventsAPI.trackBookView(id);
          } catch {
            // ignore tracking failures
          }
        }
      } catch (error) {
        console.error("Error fetching book:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchBook();
  }, [id, isLoggedIn]);

  const refreshBorrowState = async (bookId: string) => {
    if (!isLoggedIn) return;
    setBorrowStateLoading(true);
    try {
      const [loans, pending] = await Promise.all([
        loansAPI.getMyLoans(),
        borrowRequestsAPI.getMine({ status: "pending" }),
      ]);

      const activeLoanForThisBook = Array.isArray(loans) && loans.some((l: any) => String(l.book_id) === String(bookId));
      const pendingForThisBook = Array.isArray(pending)
        ? pending.find((r: any) => String(r.book_id) === String(bookId) && String(r.status) === "pending")
        : null;

      const pendingCount = Array.isArray(pending) ? pending.length : 0;
      const activeCount = Array.isArray(loans) ? loans.length : 0;
      const used = activeCount + pendingCount;

      setHasActiveLoanForBook(activeLoanForThisBook);
      setPendingRequestId(pendingForThisBook ? String(pendingForThisBook.id) : null);
      setLimitInfo({ used, max: maxBooks });
      setLimitReached(used >= maxBooks);
    } catch {
      // fail-soft: don't block UI
      setHasActiveLoanForBook(false);
      setPendingRequestId(null);
      setLimitInfo({ used: 0, max: maxBooks });
      setLimitReached(false);
    } finally {
      setBorrowStateLoading(false);
    }
  };

  useEffect(() => {
    if (!id || !book || !isLoggedIn) return;
    refreshBorrowState(book.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isLoggedIn, book?.id]);

  if (loading) {
    return (
      <MainLayout>
        <BookDetailSkeleton />
      </MainLayout>
    );
  }

  if (!book) {
    return (
      <MainLayout>
        <div className="container mx-auto py-20 text-center">
          <h1 className="text-2xl font-bold mb-4">Kitap Bulunamadı</h1>
          <p className="text-muted-foreground mb-6">
            Aradığınız kitap mevcut değil veya kaldırılmış olabilir.
          </p>
          <Link to="/books">
            <Button>Kitaplara Dön</Button>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const isAvailable = book.available_copies > 0;
  const coverImage = book.cover_image || `https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=600&fit=crop`;

  const borrowDisabledReason = (() => {
    if (!isLoggedIn) return null;
    if (pendingRequestId) return "Bu kitap için ödünç talebiniz beklemede.";
    if (hasActiveLoanForBook) return "Bu kitap zaten aktif ödünçlerinizde.";
    if (limitReached) return `Aktif ödünç/istek limitine ulaştınız (${limitInfo.used}/${limitInfo.max}).`;
    if (!isAvailable) return "Bu kitap şu an ödünç verilmiş durumda.";
    return null;
  })();

  const borrowDisabled = !!borrowDisabledReason || borrowLoading || borrowStateLoading;

  const handleBorrow = async () => {
    if (!isLoggedIn) {
      toast.error("Giriş yapmalısınız", { description: "Kitap ödünç almak için giriş yapın." });
      navigate("/auth");
      return;
    }

    if (borrowDisabledReason) {
      toast.info("Ödünç alma talebi gönderilemedi", { description: borrowDisabledReason });
      return;
    }

    setBorrowLoading(true);
    try {
      await borrowRequestsAPI.create(book.id);
      toast.success("Ödünç Talebi Gönderildi", {
        description: `"${book.title}" için talebiniz yöneticiye iletildi.`,
      });
      invalidateForYouRecommendations();
      await refreshBorrowState(book.id);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Talep gönderilemedi");
    } finally {
      setBorrowLoading(false);
    }
  };

  const handleCancelBorrowRequest = async () => {
    if (!pendingRequestId) return;
    setBorrowLoading(true);
    try {
      await borrowRequestsAPI.cancel(pendingRequestId);
      toast.success("Talep Geri Alındı", { description: "Ödünç alma talebiniz iptal edildi." });
      await refreshBorrowState(book.id);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Talep geri alınamadı");
    } finally {
      setBorrowLoading(false);
    }
  };

  const handleFavorite = async () => {
    if (!isLoggedIn) {
      toast.error("Giriş yapmalısınız", { description: "Favorilere eklemek için giriş yapın." });
      navigate("/auth");
      return;
    }

    setFavoriteLoading(true);
    try {
      if (isFavorite) {
        await favoritesAPI.remove(book.id);
        setIsFavorite(false);
        toast.success("Favorilerden Çıkarıldı");
        invalidateForYouRecommendations();
      } else {
        await favoritesAPI.add(book.id);
        setIsFavorite(true);
        toast.success("Favorilere Eklendi", {
          description: `"${book.title}" favorilerinize eklendi.`,
        });
        invalidateForYouRecommendations();
      }
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "İşlem başarısız");
    } finally {
      setFavoriteLoading(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Bağlantı Kopyalandı", {
      description: "Kitap bağlantısı panoya kopyalandı.",
    });
  };

  return (
    <MainLayout>
      <div className="container mx-auto py-8 lg:py-12">
        {/* Back Button */}
        <Link
          to="/books"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Kitaplara Dön
        </Link>

        {/* Book Detail Grid */}
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Cover Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="lg:col-span-1"
          >
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-muted shadow-xl">
              {!imageLoaded && (
                <div className="absolute inset-0 animate-pulse bg-muted" />
              )}
              <img
                src={coverImage}
                alt={book.title}
                onLoad={() => setImageLoaded(true)}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4">
                <Badge
                  variant={isAvailable ? "default" : "destructive"}
                  className={isAvailable ? "bg-success" : ""}
                >
                  {isAvailable ? (
                    <>
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      {book.available_copies} Mevcut
                    </>
                  ) : (
                    <>
                      <XCircle className="h-3 w-3 mr-1" />
                      Ödünç Verildi
                    </>
                  )}
                </Badge>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mt-6">
              <Button
              variant={borrowDisabled ? "secondary" : "hero"}
                className="flex-1"
                onClick={handleBorrow}
              disabled={borrowDisabled}
              title={borrowDisabledReason || undefined}
              >
                {borrowLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <BookOpen className="h-4 w-4" />
                )}
              {pendingRequestId ? "Talep Beklemede" : hasActiveLoanForBook ? "Aktif Ödünç" : "Ödünç Al"}
              </Button>
            {pendingRequestId && (
              <Button
                variant="outline"
                onClick={handleCancelBorrowRequest}
                disabled={borrowLoading}
                title="Bekleyen ödünç talebinizi geri alın"
              >
                Geri Al
              </Button>
            )}
              <Button
                variant="outline"
                size="icon"
                onClick={handleFavorite}
                disabled={favoriteLoading}
                className={isFavorite ? "text-destructive border-destructive/50" : ""}
              >
                <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
              </Button>
              <Button variant="outline" size="icon" onClick={handleShare}>
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          {isLoggedIn && borrowDisabledReason && (
            <p className="mt-2 text-xs text-muted-foreground">
              {borrowDisabledReason}
            </p>
          )}
          </motion.div>

          {/* Book Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-6"
          >
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="secondary">
                  {book.category || "Genel"}
                </Badge>
                {book.dewey_code && (
                  <Badge variant="outline" className="bg-blue-50/50 text-blue-600 border-blue-200">
                    DDC: {book.dewey_code}
                  </Badge>
                )}
              </div>
              <h1 className="font-display text-3xl lg:text-4xl font-bold mb-2">
                {book.title}
              </h1>
              <p className="text-xl text-muted-foreground">{book.author}</p>
            </div>

            <Separator />

            {/* Metadata */}
            <div className="grid sm:grid-cols-2 gap-4">
              {book.publisher && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Building className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Yayınevi</p>
                    <p className="font-medium">{book.publisher}</p>
                  </div>
                </div>
              )}
              {book.publish_year && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Calendar className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Yayın Yılı</p>
                    <p className="font-medium">{book.publish_year}</p>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Globe className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Dil</p>
                  <p className="font-medium">{book.language}</p>
                </div>
              </div>
              {book.pages && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <FileText className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Sayfa Sayısı</p>
                    <p className="font-medium">{book.pages}</p>
                  </div>
                </div>
              )}
              {book.location && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Konum</p>
                    <p className="font-medium">{book.location}</p>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <BookOpen className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">ISBN</p>
                  <p className="font-medium font-mono text-sm">{book.isbn}</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Description */}
            {book.description && (
              <div>
                <h2 className="font-display text-xl font-semibold mb-3">Açıklama</h2>
                <p className="text-muted-foreground leading-relaxed">
                  {book.description}
                </p>
              </div>
            )}

            {/* Stock Info */}
            <div className="bg-muted/50 rounded-xl p-4">
              <p className="text-sm text-muted-foreground">
                Toplam Kopya: <span className="font-medium text-foreground">{book.total_copies}</span> |
                Mevcut: <span className="font-medium text-foreground">{book.available_copies}</span>
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
}
