import { Link, useNavigate } from "react-router-dom";
import { BookOpen } from "lucide-react";
import { AuthForm } from "@/components/auth/AuthForm";
import { useEffect } from "react";
import { authAPI, getToken, removeToken, setUser } from "@/lib/api";

export default function Auth() {
  const navigate = useNavigate();

  // Auth route guard:
  // If user already has a valid token, do NOT allow staying on /auth.
  useEffect(() => {
    const token = getToken();
    if (!token) return;

    (async () => {
      try {
        const me = await authAPI.getMe();
        setUser(me);
        navigate(me.role === "admin" ? "/admin" : "/", { replace: true });
      } catch {
        // Token expired/invalid → clear and stay on /auth
        removeToken();
      }
    })();
  }, [navigate]);

  return (
    <div className="min-h-screen gradient-hero flex flex-col">
      {/* Header */}
      <header className="p-6">
        <Link to="/" className="inline-flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary shadow-md">
            <BookOpen className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-display font-bold">Üniversite Kütüphanesi</span>
        </Link>
      </header>

      {/* Auth Form */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="font-display text-2xl font-bold mb-2">Hoş Geldiniz</h1>
            <p className="text-muted-foreground">
              Kütüphane hesabınıza giriş yapın veya yeni hesap oluşturun
            </p>
          </div>
          <div className="bg-card rounded-2xl border border-border p-8 shadow-xl">
            <AuthForm />
          </div>
        </div>
      </main>
    </div>
  );
}
