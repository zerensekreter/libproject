import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  User, Mail, Building, CreditCard, Calendar, BookOpen, Clock, Settings, LogOut, Loader2,
  Heart, Trash2, Lock, Eye, EyeOff, Save
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { MainLayout } from "@/components/layout/MainLayout";
import { authAPI, loansAPI, favoritesAPI, borrowRequestsAPI, passwordAPI, removeToken } from "@/lib/api";
import { toast } from "sonner";

interface UserProfile {
  id: string;
  email: string;
  student_id: string;
  full_name: string;
  department: string | null;
  role: string;
  is_active: boolean;
  max_books: number;
}

interface Loan {
  id: string;
  book_title: string;
  due_date: string;
  status: string;
}

interface Favorite {
  id: string;
  book_id: string;
  book_title: string;
  book_author: string;
  book_isbn: string;
  created_at: string;
}

interface BorrowRequest {
  id: string;
  book_id: string;
  book_title: string;
  status: string;
  created_at: string;
}

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [pendingRequests, setPendingRequests] = useState<BorrowRequest[]>([]);
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [loading, setLoading] = useState(true);
  const [usedSlots, setUsedSlots] = useState(0);

  // Password change modal
  const [passwordDialog, setPasswordDialog] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ current: "", new: "", confirm: "" });
  const [showPasswords, setShowPasswords] = useState({ current: false, new: false, confirm: false });
  const [passwordLoading, setPasswordLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const userData = await authAPI.getMe();
        setUser(userData);

        const [loansData, favoritesData, pendingData] = await Promise.all([
          loansAPI.getMyLoans(),
          favoritesAPI.getAll(),
          borrowRequestsAPI.getMine({ status: "pending" }),
        ]);
        setLoans(loansData);
        setPendingRequests(pendingData);
        setUsedSlots((loansData?.length || 0) + (pendingData?.length || 0));
        setFavorites(favoritesData);
      } catch (error: any) {
        if (error.response?.status === 401) {
          navigate("/auth");
        }
        console.error("Error fetching profile:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [navigate]);

  const refreshBorrowPanel = async () => {
    try {
      const [loansData, pendingData] = await Promise.all([
        loansAPI.getMyLoans(),
        borrowRequestsAPI.getMine({ status: "pending" }),
      ]);
      setLoans(loansData);
      setPendingRequests(pendingData);
      setUsedSlots((loansData?.length || 0) + (pendingData?.length || 0));
    } catch {
      // ignore
    }
  };

  const handleCancelBorrowRequest = async (requestId: string) => {
    try {
      await borrowRequestsAPI.cancel(requestId);
      toast.success("Talep geri alındı");
      await refreshBorrowPanel();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Talep geri alınamadı");
    }
  };

  const handleLogout = () => {
    removeToken();
    toast.success("Çıkış yapıldı");
    navigate("/auth");
  };

  const handleRemoveFavorite = async (bookId: string) => {
    try {
      await favoritesAPI.remove(bookId);
      setFavorites(prev => prev.filter(f => f.book_id !== bookId));
      toast.success("Favorilerden çıkarıldı");
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  const handlePasswordChange = async () => {
    if (passwordForm.new !== passwordForm.confirm) {
      toast.error("Yeni şifreler eşleşmiyor");
      return;
    }
    if (passwordForm.new.length < 6) {
      toast.error("Yeni şifre en az 6 karakter olmalı");
      return;
    }

    setPasswordLoading(true);
    try {
      await passwordAPI.change(passwordForm.current, passwordForm.new);
      toast.success("Şifreniz başarıyla değiştirildi");
      setPasswordDialog(false);
      setPasswordForm({ current: "", new: "", confirm: "" });
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Şifre değiştirilemedi");
    } finally {
      setPasswordLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("tr-TR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto py-8 lg:py-12 flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) {
    return (
      <MainLayout>
        <div className="container mx-auto py-8 lg:py-12 text-center">
          <p>Kullanıcı bilgisi bulunamadı.</p>
          <Button onClick={() => navigate("/auth")} className="mt-4">Giriş Yap</Button>
        </div>
      </MainLayout>
    );
  }

  const safeMax = Math.max(Number(user.max_books || 5), 1);
  const safeUsed = Math.max(Number(usedSlots || 0), 0);
  const remaining = Math.max(safeMax - safeUsed, 0);
  const borrowPercentage = (safeUsed / safeMax) * 100;

  return (
    <MainLayout>
      <div className="container mx-auto py-8 lg:py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="lg:col-span-1">
            <div className="bg-card rounded-2xl border border-border p-6 shadow-card text-center">
              <div className="relative inline-block mb-4">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-12 w-12 text-primary" />
                </div>
                <Badge className="absolute -bottom-1 right-0 bg-success">
                  {user.role === "student" ? "Öğrenci" : user.role === "faculty" ? "Akademisyen" : "Admin"}
                </Badge>
              </div>
              <h1 className="font-display text-xl font-bold">{user.full_name}</h1>
              <p className="text-muted-foreground text-sm">{user.department || "Bölüm belirtilmemiş"}</p>

              <div className="mt-6 space-y-3 text-sm">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="truncate">{user.email}</span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                  <span>{user.student_id}</span>
                </div>
              </div>

              <div className="mt-6 space-y-2">
                <Button variant="outline" className="w-full gap-2" onClick={() => setPasswordDialog(true)}>
                  <Lock className="h-4 w-4" /> Şifre Değiştir
                </Button>
                <Button variant="ghost" className="w-full gap-2 text-destructive hover:text-destructive" onClick={handleLogout}>
                  <LogOut className="h-4 w-4" /> Çıkış Yap
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Borrow Status */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card rounded-xl border border-border p-6">
              <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-primary" /> Ödünç Durumu
              </h2>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Kullanılan hak (aktif ödünç + bekleyen talep)</span>
                <span className="font-semibold">{safeUsed} / {safeMax}</span>
              </div>
              <Progress value={borrowPercentage} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">{remaining} hak kaldı</p>
              {pendingRequests.length > 0 && (
                <p className="text-xs text-muted-foreground mt-1">
                  Bekleyen talep: <span className="font-medium">{pendingRequests.length}</span>
                </p>
              )}
            </motion.div>

            {/* Active Loans */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card rounded-xl border border-border p-6">
              <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" /> Aktif Ödünçler
              </h2>
              {loans.length > 0 ? (
                <div className="space-y-3">
                  {loans.map((loan) => (
                    <div key={loan.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <div>
                        <p className="font-medium">{loan.book_title}</p>
                        <p className="text-sm text-muted-foreground">İade: {formatDate(loan.due_date)}</p>
                      </div>
                      <Badge variant={loan.status === "overdue" ? "destructive" : "secondary"}>
                        {loan.status === "active" ? "Aktif" : loan.status === "overdue" ? "Gecikmiş" : loan.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">Aktif ödünç kaydınız bulunmuyor.</p>
              )}
            </motion.div>

            {/* Pending Borrow Requests */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="bg-card rounded-xl border border-border p-6">
              <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" /> Bekleyen Ödünç Talepleri
              </h2>
              {pendingRequests.length > 0 ? (
                <div className="space-y-3">
                  {pendingRequests.map((r) => (
                    <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <div className="min-w-0">
                        <p className="font-medium truncate">{r.book_title}</p>
                        <p className="text-sm text-muted-foreground">Tarih: {formatDate(r.created_at)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">Beklemede</Badge>
                        <Button variant="outline" size="sm" onClick={() => handleCancelBorrowRequest(r.id)}>
                          Geri Al
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">Bekleyen ödünç talebiniz bulunmuyor.</p>
              )}
            </motion.div>

            {/* Favorites */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-card rounded-xl border border-border p-6">
              <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
                <Heart className="h-5 w-5 text-destructive" /> Favorilerim
              </h2>
              {favorites.length > 0 ? (
                <div className="space-y-3">
                  {favorites.map((fav) => (
                    <div key={fav.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <Link to={`/books/${fav.book_id}`} className="flex-1 hover:text-primary transition-colors">
                        <p className="font-medium">{fav.book_title}</p>
                        <p className="text-sm text-muted-foreground">{fav.book_author}</p>
                      </Link>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleRemoveFavorite(fav.book_id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">Henüz favoriniz yok.</p>
                  <Link to="/books">
                    <Button variant="outline" className="mt-4">Kitapları Keşfet</Button>
                  </Link>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      {/* Password Change Dialog */}
      <Dialog open={passwordDialog} onOpenChange={setPasswordDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Lock className="h-5 w-5" /> Şifre Değiştir</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Mevcut Şifre</Label>
              <div className="relative">
                <Input
                  type={showPasswords.current ? "text" : "password"}
                  value={passwordForm.current}
                  onChange={(e) => setPasswordForm({ ...passwordForm, current: e.target.value })}
                  placeholder="••••••••"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={() => setShowPasswords({ ...showPasswords, current: !showPasswords.current })}
                >
                  {showPasswords.current ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Yeni Şifre</Label>
              <div className="relative">
                <Input
                  type={showPasswords.new ? "text" : "password"}
                  value={passwordForm.new}
                  onChange={(e) => setPasswordForm({ ...passwordForm, new: e.target.value })}
                  placeholder="••••••••"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={() => setShowPasswords({ ...showPasswords, new: !showPasswords.new })}
                >
                  {showPasswords.new ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Yeni Şifre (Tekrar)</Label>
              <div className="relative">
                <Input
                  type={showPasswords.confirm ? "text" : "password"}
                  value={passwordForm.confirm}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirm: e.target.value })}
                  placeholder="••••••••"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={() => setShowPasswords({ ...showPasswords, confirm: !showPasswords.confirm })}
                >
                  {showPasswords.confirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPasswordDialog(false)}>İptal</Button>
            <Button onClick={handlePasswordChange} disabled={passwordLoading} variant="hero" className="gap-2">
              {passwordLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
