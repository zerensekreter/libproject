import { MainLayout } from "@/components/layout/MainLayout";
import { BooksList } from "@/components/books/BooksList";

export default function Books() {
  return (
    <MainLayout>
      <div className="container mx-auto py-8 lg:py-12">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="font-display text-3xl lg:text-4xl font-bold mb-2">
            Kitap Kataloğu
          </h1>
          <p className="text-muted-foreground">
            15.000'den fazla kitap arasından arama yapın ve hemen ödünç alın.
          </p>
        </div>

        {/* Books List */}
        <BooksList />
      </div>
    </MainLayout>
  );
}
