import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen, Users, BookCopy, Home, Plus,
  LogOut, AlertTriangle, Loader2, Search,
  Megaphone, Trash2, ChevronLeft, ChevronRight,
  LayoutDashboard, Eye, Edit, Moon, Sun, Save,
  Clock, History, UserCheck, BookPlus,
  Cpu, MemoryStick, HardDrive, Network, Activity, Server, Zap,
  MessageCircle, Bell, Nfc
} from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  adminAPI, booksAPI, usersAPI, loansAPI, announcementsAPI,
  getUser, removeToken, borrowRequestsAPI
} from "@/lib/api";
import api from "@/lib/api";
import { AdminSupportPanel } from "@/components/admin/AdminSupportPanel";
import { AiIndexStatusWidget } from "@/components/admin/AiIndexStatusWidget";
import { AdminSupportNotifier } from "@/components/admin/AdminSupportNotifier";
import { playNotificationSound, supportAPI } from "@/lib/supportApi";
import { getDeweyCategory } from "@/lib/dewey";
import { RFIDManagerPanel } from "@/components/admin/RFIDManagerPanel";

// Types
interface Metrics {
  books: { total: number; available: number };
  users: { total: number; active: number };
  loans: { total: number; active: number; overdue: number };
}

interface SystemMetrics {
  cpu: { percent: number; count: number; count_logical: number };
  memory: { total_gb: number; used_gb: number; available_gb: number; percent: number };
  disk: { total_gb: number; used_gb: number; free_gb: number; percent: number };
  network: { bytes_sent_mb: number; bytes_recv_mb: number };
  process: { memory_mb: number; cpu_percent: number; threads: number; open_files: number };
  server: { uptime_seconds: number; uptime_str: string; python_version: string; fastapi_version: string; platform: string; hostname: string };
  requests: { total: number; errors: number; avg_response_ms: number };
  timestamp: string;
}

interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publisher?: string;
  publish_year?: number;
  language: string;
  category?: string;
  pages?: number;
  total_copies: number;
  available_copies: number;
  location?: string;
  description?: string;
  cover_image?: string;
  dewey_code?: string;
}

interface User {
  id: string;
  email: string;
  full_name: string;
  student_id: string;
  department?: string;
  role: string;
  is_active: boolean;
  is_verified: boolean;
  max_books: number;
}

interface UserDetail extends User {
  loans: {
    id: string;
    book_title: string;
    checkout_at: string;
    due_date: string;
    returned_at?: string;
    status: string;
    fine_amount: number;
  }[];
}

interface Loan {
  id: string;
  user_id: string;
  book_id: string;
  user_name: string;
  book_title: string;
  checkout_at: string;
  due_date: string;
  returned_at?: string;
  status: string;
  fine_amount: number;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: string;
  is_pinned: boolean;
  created_at: string;
}

interface BorrowRequest {
  id: string;
  user_id: string;
  book_id: string;
  user_name: string;
  book_title: string;
  book_isbn: string;
  status: string;
  created_at: string;
  processed_at?: string;
}

// Sidebar menu items
const menuItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "books", label: "Kitaplar", icon: BookOpen },
  { id: "users", label: "Kullanıcılar", icon: Users },
  { id: "loans", label: "Ödünçler", icon: BookCopy },
  { id: "requests", label: "Ödünç Talepleri", icon: UserCheck },
  { id: "overdue", label: "Geciken Kitaplar", icon: AlertTriangle },
  { id: "history", label: "Kitap Geçmişi", icon: History },
  { id: "announcements", label: "Duyurular", icon: Megaphone },
  { id: "support", label: "Canlı Destek", icon: MessageCircle },
  { id: "rfid", label: "RFID Manager", icon: Nfc },
];

export default function Admin() {
  const navigate = useNavigate();
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const [user, setUser] = useState<any>(null);
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics | null>(null);
  const [books, setBooks] = useState<Book[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [overdueLoans, setOverdueLoans] = useState<Loan[]>([]);
  const [loanHistory, setLoanHistory] = useState<Loan[]>([]);
  const [borrowRequests, setBorrowRequests] = useState<BorrowRequest[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSection, setActiveSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [supportUnread, setSupportUnread] = useState(0);
  const supportUnreadPrevRef = useRef(0);
  const [showSupportDropdown, setShowSupportDropdown] = useState(false);
  const [supportDropdownSessions, setSupportDropdownSessions] = useState<any[]>([]);
  const [focusSupportSessionId, setFocusSupportSessionId] = useState<string | null>(null);

  // Dialogs
  const [userDetailDialog, setUserDetailDialog] = useState<{ open: boolean; user: UserDetail | null; loading: boolean }>({
    open: false, user: null, loading: false
  });
  const [userEditForm, setUserEditForm] = useState({ role: "", password: "", is_active: true, max_books: 5 });
  const [bookDialog, setBookDialog] = useState<{ open: boolean; book: Book | null; mode: "add" | "edit" }>({ open: false, book: null, mode: "add" });
  const [announcementDialog, setAnnouncementDialog] = useState(false);
  const [editAnnouncementDialog, setEditAnnouncementDialog] = useState<{ open: boolean; announcement: Announcement | null }>({
    open: false, announcement: null
  });
  const [checkoutDialog, setCheckoutDialog] = useState(false);

  // Form states
  const [bookForm, setBookForm] = useState({
    isbn: "", title: "", author: "", publisher: "", publish_year: 2024,
    language: "Türkçe", category: "", dewey_code: "", pages: 0, total_copies: 1, location: "", description: "", cover_image: ""
  });
  const [newAnnouncement, setNewAnnouncement] = useState({
    title: "", content: "", priority: "medium", is_pinned: false
  });
  const [editAnnouncement, setEditAnnouncement] = useState({
    title: "", content: "", priority: "medium", is_pinned: false
  });
  const [checkoutForm, setCheckoutForm] = useState({
    student_id: "", user_name: "", user_id: "", isbn: "", book_title: "", book_id: "", due_days: 14,
    available_copies: 0, total_copies: 0
  });
  const [lookupLoading, setLookupLoading] = useState({ user: false, book: false });
  const [isbnLookupLoading, setIsbnLookupLoading] = useState(false);

  useEffect(() => {
    const currentUser = getUser();
    if (!currentUser || currentUser.role !== "admin") {
      toast.error("Bu sayfaya erişim yetkiniz yok");
      navigate("/");
      return;
    }
    setUser(currentUser);
    fetchAllData();
    // initial unread count for support
    supportAPI.getAdminUnreadCount()
      .then((d) => setSupportUnread(d.unread_count || 0))
      .catch(() => {});
  }, [navigate]);

  useEffect(() => {
    supportUnreadPrevRef.current = supportUnread;
  }, [supportUnread]);

  const fetchSupportDropdown = async () => {
    try {
      const sessions = await supportAPI.getSessions("active");
      const unreadOnly = (sessions || []).filter((s: any) => (s.unread_count || 0) > 0);
      // sort by last_message_at desc
      unreadOnly.sort((a: any, b: any) => new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime());
      setSupportDropdownSessions(unreadOnly.slice(0, 10));
    } catch {
      setSupportDropdownSessions([]);
    }
  };

  // keep unread count fresh + ensure sound/toast even if websocket is interrupted
  useEffect(() => {
    const interval = setInterval(() => {
      supportAPI.getAdminUnreadCount()
        .then((d) => {
          const next = d.unread_count || 0;
          // If unread increased and admin is not in support tab, surface it.
          if (next > supportUnreadPrevRef.current && activeSection !== "support") {
            playNotificationSound();
            toast.info("Yeni destek mesajı", { description: "Canlı Destek sekmesine gidebilirsiniz." });
          }
          supportUnreadPrevRef.current = next;
          setSupportUnread(next);
        })
        .catch(() => {});
    }, 5000);
    return () => clearInterval(interval);
  }, [activeSection]);

  // Tema yönetimi global ThemeProvider üzerinden yapılır (system default + persist).

  // Fetch system metrics with auto-refresh
  const fetchSystemMetrics = async () => {
    try {
      const response = await api.get('/api/v1/admin/system-metrics');
      setSystemMetrics(response.data);
    } catch (error) {
      console.error("System metrics error:", error);
    }
  };

  useEffect(() => {
    fetchSystemMetrics();
    const interval = setInterval(fetchSystemMetrics, 5000); // Her 5 saniyede güncelle
    return () => clearInterval(interval);
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [metricsData, booksData, usersData, loansData, overdueData, historyData, requestsData, announcementsData] = await Promise.all([
        adminAPI.getMetrics(),
        booksAPI.getAll({ limit: 100 }),
        usersAPI.getAll({ limit: 100 }),
        loansAPI.getAll({ limit: 100 }),
        loansAPI.getOverdue(),
        loansAPI.getHistory({ limit: 200 }),
        borrowRequestsAPI.getAll(),
        announcementsAPI.getAll({ active_only: false }),
      ]);
      setMetrics(metricsData);
      setBooks(booksData);
      setUsers(usersData);
      setLoans(loansData);
      setOverdueLoans(overdueData);
      setLoanHistory(historyData);
      setBorrowRequests(requestsData);
      setAnnouncements(announcementsData);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Veriler yüklenirken hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    removeToken();
    navigate("/auth");
  };

  // User lookup for checkout
  const lookupUser = async () => {
    if (!checkoutForm.student_id) return;
    setLookupLoading({ ...lookupLoading, user: true });
    try {
      const user = await usersAPI.lookupByStudentId(checkoutForm.student_id);
      setCheckoutForm({ ...checkoutForm, user_name: user.full_name, user_id: user.id });
      toast.success("Kullanıcı bulundu");
    } catch (error) {
      toast.error("Kullanıcı bulunamadı");
      setCheckoutForm({ ...checkoutForm, user_name: "", user_id: "" });
    } finally {
      setLookupLoading({ ...lookupLoading, user: false });
    }
  };

  // Book lookup for checkout
  const lookupBook = async () => {
    if (!checkoutForm.isbn) return;
    setLookupLoading({ ...lookupLoading, book: true });
    try {
      const book = await booksAPI.getByIsbn(checkoutForm.isbn);
      setCheckoutForm({
        ...checkoutForm,
        book_title: book.title,
        book_id: book.id,
        available_copies: book.available_copies,
        total_copies: book.total_copies
      });
      if (book.available_copies > 0) {
        toast.success("Kitap bulundu - Kiralanmaya uygun");
      } else {
        toast.warning("Kitap bulundu - Mevcut kopya yok!");
      }
    } catch (error) {
      toast.error("Kitap bulunamadı");
      setCheckoutForm({ ...checkoutForm, book_title: "", book_id: "", available_copies: 0, total_copies: 0 });
    } finally {
      setLookupLoading({ ...lookupLoading, book: false });
    }
  };

  // ISBN ile kitap bilgisi çekme (Google Books + Open Library tamamlama)
  const lookupBookByIsbn = async (isbn: string) => {
    if (!isbn || isbn.length < 10) {
      toast.error("Geçerli bir ISBN giriniz (en az 10 karakter)");
      return;
    }

    // ISBN'den tire ve boşlukları temizle
    const cleanIsbn = isbn.replace(/[-\s]/g, "");
    setIsbnLookupLoading(true);

    // Çekilen verileri geçici olarak tutacak obje
    let fetchedData: {
      title?: string;
      author?: string;
      publisher?: string;
      publish_year?: number;
      pages?: number;
      category?: string;
      description?: string;
      language?: string;
      cover_image?: string;
      dewey_code?: string;
    } = {};

    let foundInGoogle = false;
    let foundInOpenLib = false;

    try {
      // 1. Google Books API'den çek
      const googleResponse = await fetch(
        `https://www.googleapis.com/books/v1/volumes?q=isbn:${cleanIsbn}`
      );
      const googleData = await googleResponse.json();

      if (googleData.items?.[0]?.volumeInfo) {
        const info = googleData.items[0].volumeInfo;
        foundInGoogle = true;

        fetchedData = {
          title: info.title || undefined,
          author: info.authors?.join(", ") || undefined,
          publisher: info.publisher || undefined,
          publish_year: info.publishedDate ? parseInt(info.publishedDate.substring(0, 4)) : undefined,
          pages: info.pageCount || undefined,
          category: info.categories?.[0] || undefined,
          description: info.description?.substring(0, 500) || undefined,
          language: info.language === "tr" ? "Türkçe"
            : info.language === "en" ? "İngilizce"
              : info.language === "de" ? "Almanca"
                : undefined,
          cover_image: info.imageLinks?.thumbnail || info.imageLinks?.smallThumbnail || undefined
        };
      }

      // 2. Open Library API'den eksik alanları tamamla
      const openLibResponse = await fetch(
        `https://openlibrary.org/api/books?bibkeys=ISBN:${cleanIsbn}&format=json&jscmd=data`
      );
      const openLibData = await openLibResponse.json();
      const bookData = openLibData[`ISBN:${cleanIsbn}`];

      if (bookData) {
        foundInOpenLib = true;

        // Sadece boş alanları Open Library'den doldur
        if (!fetchedData.title && bookData.title) {
          fetchedData.title = bookData.title;
        }
        if (!fetchedData.author && bookData.authors?.length) {
          fetchedData.author = bookData.authors.map((a: any) => a.name).join(", ");
        }
        if (!fetchedData.publisher && bookData.publishers?.length) {
          fetchedData.publisher = bookData.publishers[0].name;
        }
        if (!fetchedData.publish_year && bookData.publish_date) {
          const yearMatch = bookData.publish_date.match(/\d{4}/);
          if (yearMatch) fetchedData.publish_year = parseInt(yearMatch[0]);
        }
        if (!fetchedData.pages && bookData.number_of_pages) {
          fetchedData.pages = bookData.number_of_pages;
        }
        if (!fetchedData.cover_image && bookData.cover?.medium) {
          fetchedData.cover_image = bookData.cover.medium;
        }
        
        // DEWEY DECIMAL CLASS extraction!
        if (bookData.classifications?.dewey_decimal_class?.length > 0) {
          const rawCode = bookData.classifications.dewey_decimal_class[0];
          // Slash (/) işaretinden sonrasını at (Örn: 005.13/3 -> 005.13)
          fetchedData.dewey_code = rawCode.split('/')[0].trim();
          
          // Otomatik kategori belirle
          const derivedCategory = getDeweyCategory(fetchedData.dewey_code);
          if (derivedCategory) {
            fetchedData.category = derivedCategory;
          }
        }
      }

      // Form'u güncelle
      if (foundInGoogle || foundInOpenLib) {
        setBookForm(prev => ({
          ...prev,
          title: fetchedData.title || prev.title,
          author: fetchedData.author || prev.author,
          publisher: fetchedData.publisher || prev.publisher,
          publish_year: fetchedData.publish_year || prev.publish_year,
          pages: fetchedData.pages || prev.pages,
          category: fetchedData.category || prev.category,
          dewey_code: fetchedData.dewey_code || prev.dewey_code,
          description: fetchedData.description || prev.description,
          language: fetchedData.language || prev.language,
          cover_image: fetchedData.cover_image || prev.cover_image
        }));

        if (foundInGoogle && foundInOpenLib) {
          toast.success("Kitap bilgileri her iki API'den birleştirildi");
        } else if (foundInGoogle) {
          toast.success("Kitap bilgileri Google Books'tan çekildi");
        } else {
          toast.success("Kitap bilgileri Open Library'den çekildi");
        }
      } else {
        toast.info("Kitap bilgisi bulunamadı, manuel giriş yapabilirsiniz");
      }
    } catch (error) {
      console.error("ISBN lookup error:", error);
      toast.error("Kitap bilgisi çekilemedi, API bağlantı hatası");
    } finally {
      setIsbnLookupLoading(false);
    }
  };

  // Checkout book
  const handleCheckout = async () => {
    if (!checkoutForm.user_id || !checkoutForm.book_id) {
      toast.error("Kullanıcı ve kitap bilgilerini doldurun");
      return;
    }
    try {
      await loansAPI.checkout({
        user_id: checkoutForm.user_id,
        book_id: checkoutForm.book_id,
        due_days: checkoutForm.due_days
      });
      toast.success("Kitap ödünç verildi");
      setCheckoutDialog(false);
      setCheckoutForm({ student_id: "", user_name: "", user_id: "", isbn: "", book_title: "", book_id: "", due_days: 14, available_copies: 0, total_copies: 0 });
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Ödünç verilemedi");
    }
  };

  const handleApproveUser = async (userId: string) => {
    try {
      await usersAPI.update(userId, { is_verified: true });
      toast.success("Kullanıcı hesabı başarıyla onaylandı.");
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Onaylama başarısız");
    }
  };

  // User operations
  const openUserDetail = async (userId: string) => {
    setUserDetailDialog({ open: true, user: null, loading: true });
    try {
      const detail = await usersAPI.getDetail(userId);
      setUserDetailDialog({ open: true, user: detail, loading: false });
      setUserEditForm({
        role: detail.role,
        password: "",
        is_active: detail.is_active,
        max_books: detail.max_books
      });
    } catch (error) {
      toast.error("Kullanıcı bilgileri yüklenemedi");
      setUserDetailDialog({ open: false, user: null, loading: false });
    }
  };

  const handleUpdateUser = async () => {
    if (!userDetailDialog.user) return;
    try {
      const updateData: any = {};
      if (userEditForm.role !== userDetailDialog.user.role) updateData.role = userEditForm.role;
      if (userEditForm.password) updateData.password = userEditForm.password;
      if (userEditForm.is_active !== userDetailDialog.user.is_active) updateData.is_active = userEditForm.is_active;
      if (userEditForm.max_books !== userDetailDialog.user.max_books) updateData.max_books = userEditForm.max_books;

      if (Object.keys(updateData).length === 0) {
        toast.info("Değişiklik yapılmadı");
        return;
      }

      await usersAPI.update(userDetailDialog.user.id, updateData);
      toast.success("Kullanıcı güncellendi");
      setUserDetailDialog({ open: false, user: null, loading: false });
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Güncelleme başarısız");
    }
  };

  const openAddBook = () => {
    setBookForm({ isbn: "", title: "", author: "", publisher: "", publish_year: 2024, language: "Türkçe", category: "", dewey_code: "", pages: 0, total_copies: 1, location: "", description: "", cover_image: "" });
    setBookDialog({ open: true, book: null, mode: "add" });
  };

  const openEditBook = (book: Book) => {
    setBookForm({
      isbn: book.isbn,
      title: book.title,
      author: book.author,
      publisher: book.publisher || "",
      publish_year: book.publish_year || 2024,
      language: book.language,
      category: book.category || "",
      dewey_code: book.dewey_code || "",
      pages: book.pages || 0,
      total_copies: book.total_copies,
      location: book.location || "",
      description: book.description || "",
      cover_image: book.cover_image || ""
    });
    setBookDialog({ open: true, book, mode: "edit" });
  };

  const handleSaveBook = async () => {
    try {
      if (bookDialog.mode === "add") {
        await booksAPI.create(bookForm);
        toast.success("Kitap eklendi");
      } else if (bookDialog.book) {
        await booksAPI.update(bookDialog.book.id, bookForm);
        toast.success("Kitap güncellendi");
      }
      setBookDialog({ open: false, book: null, mode: "add" });
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "İşlem başarısız");
    }
  };

  const handleDeleteBook = async (id: string) => {
    if (!confirm("Bu kitabı silmek istediğinize emin misiniz?")) return;
    try {
      await booksAPI.delete(id);
      toast.success("Kitap silindi");
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Kitap silinemedi");
    }
  };

  // Announcement operations
  const handleAddAnnouncement = async () => {
    try {
      await announcementsAPI.create(newAnnouncement);
      toast.success("Duyuru eklendi");
      setAnnouncementDialog(false);
      setNewAnnouncement({ title: "", content: "", priority: "medium", is_pinned: false });
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Duyuru eklenemedi");
    }
  };

  const openEditAnnouncement = (a: Announcement) => {
    setEditAnnouncement({ title: a.title, content: a.content, priority: a.priority, is_pinned: a.is_pinned });
    setEditAnnouncementDialog({ open: true, announcement: a });
  };

  const handleUpdateAnnouncement = async () => {
    if (!editAnnouncementDialog.announcement) return;
    try {
      await announcementsAPI.update(editAnnouncementDialog.announcement.id, editAnnouncement);
      toast.success("Duyuru güncellendi");
      setEditAnnouncementDialog({ open: false, announcement: null });
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Güncelleme başarısız");
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    if (!confirm("Bu duyuruyu silmek istediğinize emin misiniz?")) return;
    try {
      await announcementsAPI.delete(id);
      toast.success("Duyuru silindi");
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Duyuru silinemedi");
    }
  };

  // Borrow request operations
  const handleProcessRequest = async (requestId: string, action: 'approve' | 'reject') => {
    try {
      await borrowRequestsAPI.process(requestId, action);
      toast.success(action === 'approve' ? "Talep onaylandı" : "Talep reddedildi");
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "İşlem başarısız");
    }
  };

  const handleReturnBook = async (loanId: string) => {
    try {
      await loansAPI.return({ loan_id: loanId });
      toast.success("Kitap iade edildi");
      fetchAllData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "İade işlemi başarısız");
    }
  };

  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString("tr-TR");
  const formatDateTime = (dateString: string) => new Date(dateString).toLocaleString("tr-TR");

  const filteredBooks = books.filter(b =>
    b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.isbn.includes(searchQuery)
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Global notifier: listens while admin is NOT in support tab */}
      <AdminSupportNotifier activeSection={activeSection} setUnreadCount={setSupportUnread} />
      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: sidebarOpen ? 260 : 80 }}
        className="sticky top-0 h-screen bg-card border-r border-border flex flex-col z-40"
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-border">
          <AnimatePresence mode="wait">
            {sidebarOpen && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary shadow-md">
                  <BookOpen className="h-5 w-5 text-primary-foreground" />
                </div>
                <div className="flex items-center gap-2">
                  <div>
                    <h1 className="font-display font-bold text-foreground text-sm">Admin Panel</h1>
                    <p className="text-xs text-muted-foreground">{user?.full_name}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setTheme(isDark ? "light" : "dark")}
                    aria-label="Tema değiştir"
                    title={isDark ? "Açık tema" : "Koyu tema"}
                  >
                    {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {!sidebarOpen && (
            <div className="flex flex-col items-center gap-2 mx-auto">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary shadow-md">
                <BookOpen className="h-5 w-5 text-primary-foreground" />
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => setTheme(isDark ? "light" : "dark")}
                aria-label="Tema değiştir"
                title={isDark ? "Açık tema" : "Koyu tema"}
              >
                {isDark ? <Sun className="h-3 w-3" /> : <Moon className="h-3 w-3" />}
              </Button>
            </div>
          )}
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setShowSupportDropdown(false);
                setActiveSection(item.id);
              }}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all",
                activeSection === item.id
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              <item.icon className={cn("h-5 w-5 flex-shrink-0", item.id === "overdue" && overdueLoans.length > 0 && "text-destructive")} />
              {sidebarOpen && (
                <span className="flex-1 text-left">{item.label}</span>
              )}
              {sidebarOpen && item.id === "overdue" && overdueLoans.length > 0 && (
                <Badge variant="destructive" className="text-xs">{overdueLoans.length}</Badge>
              )}
              {sidebarOpen && item.id === "support" && supportUnread > 0 && (
                <Badge variant="destructive" className="text-xs">{supportUnread}</Badge>
              )}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-border space-y-1">
          <Link to="/">
            <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-all">
              <Home className="h-5 w-5 flex-shrink-0" />
              {sidebarOpen && <span>Ana Sayfa</span>}
            </button>
          </Link>
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-destructive hover:bg-destructive/10 transition-all">
            <LogOut className="h-5 w-5 flex-shrink-0" />
            {sidebarOpen && <span>Çıkış Yap</span>}
          </button>
        </div>

        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-20 h-6 w-6 rounded-full bg-card border border-border shadow-sm flex items-center justify-center hover:bg-muted transition-colors"
        >
          {sidebarOpen ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </button>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <header className="sticky top-0 z-30 h-14 bg-background/80 backdrop-blur-sm border-b border-border flex items-center justify-between px-6">
          <h2 className="font-display text-lg font-bold">
            {menuItems.find(m => m.id === activeSection)?.label || "Dashboard"}
          </h2>
          <div className="flex items-center gap-2">
            {/* Notifications (support) */}
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={async () => {
                  const next = !showSupportDropdown;
                  setShowSupportDropdown(next);
                  if (next) await fetchSupportDropdown();
                }}
                aria-label="Canlı destek bildirimleri"
              >
                <Bell className="h-4 w-4" />
                {supportUnread > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] leading-[18px] text-center">
                    {supportUnread > 99 ? "99+" : supportUnread}
                  </span>
                )}
              </Button>

              {showSupportDropdown && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowSupportDropdown(false)} />
                  <div className="absolute right-0 mt-2 w-80 bg-card rounded-lg shadow-xl border border-border z-50 overflow-hidden">
                    <div className="flex items-center justify-between p-3 border-b border-border">
                      <h3 className="font-semibold">Canlı Destek</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs h-7"
                        onClick={async () => {
                          await fetchSupportDropdown();
                          const c = await supportAPI.getAdminUnreadCount().catch(() => ({ unread_count: supportUnread }));
                          setSupportUnread((c as any).unread_count || 0);
                        }}
                      >
                        Yenile
                      </Button>
                    </div>
                    <div className="max-h-72 overflow-y-auto">
                      {supportDropdownSessions.length === 0 ? (
                        <div className="p-4 text-center text-muted-foreground text-sm">
                          Yeni mesaj yok
                        </div>
                      ) : (
                        supportDropdownSessions.map((s: any) => (
                          <button
                            key={s.id}
                            className="w-full text-left p-3 border-b border-border last:border-0 hover:bg-muted/50 transition-colors"
                            onClick={() => {
                              setShowSupportDropdown(false);
                              setActiveSection("support");
                              setFocusSupportSessionId(s.id);
                            }}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <p className="text-sm font-medium truncate">{s.user_name}</p>
                                <p className="text-xs text-muted-foreground truncate">{s.last_message_preview || ""}</p>
                              </div>
                              {s.unread_count > 0 && (
                                <Badge variant="destructive" className="text-xs">{s.unread_count}</Badge>
                              )}
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                    <div className="p-2 border-t border-border">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => {
                          setShowSupportDropdown(false);
                          setActiveSection("support");
                        }}
                      >
                        Tümünü Gör
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </div>
            {activeSection === "books" && (
              <Button onClick={openAddBook} variant="hero" size="sm" className="gap-2">
                <Plus className="h-4 w-4" /> Yeni Kitap
              </Button>
            )}
            {activeSection === "loans" && (
              <Button onClick={() => setCheckoutDialog(true)} variant="hero" size="sm" className="gap-2">
                <BookPlus className="h-4 w-4" /> Ödünç Ver
              </Button>
            )}
            {activeSection === "announcements" && (
              <Button onClick={() => setAnnouncementDialog(true)} variant="hero" size="sm" className="gap-2">
                <Plus className="h-4 w-4" /> Yeni Duyuru
              </Button>
            )}
          </div>
        </header>

        <div className="p-6">
          {/* Dashboard */}
          {activeSection === "dashboard" && metrics && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "Toplam Kitap", value: metrics.books.total, icon: BookOpen, color: "primary" },
                  { label: "Aktif Kullanıcı", value: metrics.users.active, icon: Users, color: "success" },
                  { label: "Aktif Ödünç", value: metrics.loans.active, icon: BookCopy, color: "secondary" },
                  { label: "Geciken", value: metrics.loans.overdue, icon: AlertTriangle, color: "destructive" },
                ].map((stat, i) => (
                  <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="bg-card rounded-xl border border-border p-5">
                    <div className="flex items-center gap-4">
                      <div className={cn("p-3 rounded-lg", `bg-${stat.color}/10`)}>
                        <stat.icon className={cn("h-5 w-5", `text-${stat.color}`)} />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{stat.value}</p>
                        <p className="text-xs text-muted-foreground">{stat.label}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* System Metrics Section */}
              {systemMetrics && (
                <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl border border-slate-700 p-6 text-white">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-semibold flex items-center gap-2 text-lg">
                      <Server className="h-5 w-5 text-blue-400" />
                      Sistem Durumu
                    </h3>
                    <Badge variant="outline" className="border-green-500 text-green-400 gap-1">
                      <Activity className="h-3 w-3 animate-pulse" />
                      Canlı
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* CPU */}
                    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Cpu className="h-4 w-4 text-blue-400" />
                          <span className="text-sm text-slate-300">CPU</span>
                        </div>
                        <span className={cn("text-lg font-bold", systemMetrics.cpu.percent > 80 ? "text-red-400" : systemMetrics.cpu.percent > 50 ? "text-yellow-400" : "text-green-400")}>
                          {systemMetrics.cpu.percent.toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={cn("h-full transition-all duration-500", systemMetrics.cpu.percent > 80 ? "bg-red-500" : systemMetrics.cpu.percent > 50 ? "bg-yellow-500" : "bg-green-500")}
                          style={{ width: `${systemMetrics.cpu.percent}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-2">{systemMetrics.cpu.count} Çekirdek</p>
                    </div>

                    {/* RAM */}
                    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <MemoryStick className="h-4 w-4 text-purple-400" />
                          <span className="text-sm text-slate-300">RAM</span>
                        </div>
                        <span className={cn("text-lg font-bold", systemMetrics.memory.percent > 80 ? "text-red-400" : systemMetrics.memory.percent > 50 ? "text-yellow-400" : "text-green-400")}>
                          {systemMetrics.memory.percent.toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={cn("h-full transition-all duration-500", systemMetrics.memory.percent > 80 ? "bg-red-500" : systemMetrics.memory.percent > 50 ? "bg-yellow-500" : "bg-purple-500")}
                          style={{ width: `${systemMetrics.memory.percent}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-2">{systemMetrics.memory.used_gb} / {systemMetrics.memory.total_gb} GB</p>
                    </div>

                    {/* Disk */}
                    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <HardDrive className="h-4 w-4 text-orange-400" />
                          <span className="text-sm text-slate-300">Disk</span>
                        </div>
                        <span className={cn("text-lg font-bold", systemMetrics.disk.percent > 80 ? "text-red-400" : systemMetrics.disk.percent > 50 ? "text-yellow-400" : "text-green-400")}>
                          {systemMetrics.disk.percent.toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={cn("h-full transition-all duration-500", systemMetrics.disk.percent > 80 ? "bg-red-500" : systemMetrics.disk.percent > 50 ? "bg-yellow-500" : "bg-orange-500")}
                          style={{ width: `${systemMetrics.disk.percent}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-2">{systemMetrics.disk.used_gb} / {systemMetrics.disk.total_gb} GB</p>
                    </div>

                    {/* Network */}
                    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                      <div className="flex items-center gap-2 mb-3">
                        <Network className="h-4 w-4 text-teal-400" />
                        <span className="text-sm text-slate-300">Ağ</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">↑ Gönderilen</span>
                          <span className="text-teal-400">{systemMetrics.network.bytes_sent_mb} MB</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">↓ Alınan</span>
                          <span className="text-teal-400">{systemMetrics.network.bytes_recv_mb} MB</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Server & Request Stats */}
                  <div className="mt-4 pt-4 border-t border-slate-700">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
                      {/* Uptime */}
                      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700 text-center">
                        <Clock className="h-4 w-4 text-emerald-400 mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{systemMetrics.server.uptime_str}</p>
                        <p className="text-xs text-slate-500">Çalışma Süresi</p>
                      </div>

                      {/* Total Requests */}
                      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700 text-center">
                        <Activity className="h-4 w-4 text-blue-400 mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{systemMetrics.requests.total}</p>
                        <p className="text-xs text-slate-500">Toplam İstek</p>
                      </div>

                      {/* Avg Response Time */}
                      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700 text-center">
                        <Zap className="h-4 w-4 text-yellow-400 mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{systemMetrics.requests.avg_response_ms} ms</p>
                        <p className="text-xs text-slate-500">Ort. Yanıt Süresi</p>
                      </div>

                      {/* Errors */}
                      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700 text-center">
                        <AlertTriangle className="h-4 w-4 text-red-400 mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{systemMetrics.requests.errors}</p>
                        <p className="text-xs text-slate-500">Hata Sayısı</p>
                      </div>
                    </div>

                    {/* Two Column Info */}
                    <div className="grid grid-cols-2 gap-4">
                      {/* Backend Process */}
                      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                          <span className="text-sm font-medium text-green-400">Backend (FastAPI)</span>
                        </div>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span className="text-slate-500">RAM:</span>
                            <span className="text-slate-300">{systemMetrics.process.memory_mb} MB</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">CPU:</span>
                            <span className="text-slate-300">{systemMetrics.process.cpu_percent.toFixed(1)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Threads:</span>
                            <span className="text-slate-300">{systemMetrics.process.threads}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Açık Dosya:</span>
                            <span className="text-slate-300">{systemMetrics.process.open_files}</span>
                          </div>
                        </div>
                      </div>

                      {/* Server Info */}
                      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                        <div className="flex items-center gap-2 mb-2">
                          <Server className="w-4 h-4 text-purple-400" />
                          <span className="text-sm font-medium text-purple-400">Sunucu Bilgisi</span>
                        </div>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Python:</span>
                            <span className="text-slate-300">{systemMetrics.server.python_version}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">FastAPI:</span>
                            <span className="text-slate-300">{systemMetrics.server.fastapi_version}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Platform:</span>
                            <span className="text-slate-300">{systemMetrics.server.platform}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Bağlantı:</span>
                            <span className="text-green-400">● Çevrimiçi</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <p className="text-slate-500 text-xs mt-3 text-center">
                      Son güncelleme: {new Date(systemMetrics.timestamp).toLocaleTimeString("tr-TR")}
                    </p>
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-card rounded-xl border border-border p-5">
                  <h3 className="font-semibold mb-4">Hızlı İşlemler</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start gap-2" onClick={() => setCheckoutDialog(true)}>
                      <BookPlus className="h-4 w-4" /> Kitap Ödünç Ver
                    </Button>
                    <Button variant="outline" className="w-full justify-start gap-2" onClick={() => setActiveSection("overdue")}>
                      <AlertTriangle className="h-4 w-4" /> Geciken Kitapları Gör
                    </Button>
                    <Button variant="outline" className="w-full justify-start gap-2" onClick={() => setActiveSection("history")}>
                      <History className="h-4 w-4" /> Kitap Geçmişi
                    </Button>
                  </div>
                </div>

                {overdueLoans.length > 0 && (
                  <div className="bg-destructive/5 rounded-xl border border-destructive/20 p-5">
                    <h3 className="font-semibold text-destructive mb-4 flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" /> Geciken Kitaplar ({overdueLoans.length})
                    </h3>
                    <div className="space-y-2">
                      {overdueLoans.slice(0, 3).map((loan) => (
                        <div key={loan.id} className="p-2 text-sm bg-background rounded-lg">
                          <p className="font-medium">{loan.book_title}</p>
                          <p className="text-xs text-muted-foreground">{loan.user_name} - {formatDate(loan.due_date)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Books */}
          {activeSection === "books" && (
            <div className="space-y-4">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Kitap, yazar veya ISBN ara..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10" />
              </div>
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Kitap</TableHead>
                      <TableHead>Yazar</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Konum</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBooks.map((book) => (
                      <TableRow key={book.id}>
                        <TableCell>
                          <p className="font-medium">{book.title}</p>
                          <p className="text-xs text-muted-foreground">{book.isbn}</p>
                        </TableCell>
                        <TableCell>{book.author}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{book.category || "Genel"}</Badge>
                          {book.dewey_code && (
                             <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-200">
                                DDC: {book.dewey_code}
                             </Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-xs">{book.location || "-"}</TableCell>
                        <TableCell>
                          <Badge className={book.available_copies > 0 ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}>
                            {book.available_copies}/{book.total_copies}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => openEditBook(book)}><Edit className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDeleteBook(book.id)}><Trash2 className="h-4 w-4" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}

          {/* Users */}
          {activeSection === "users" && (
            <div className="space-y-6">
              {/* Onay Bekleyenler Kısmı */}
              {users.filter(u => !u.is_verified).length > 0 && (
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg overflow-hidden">
                  <div className="p-4 border-b border-amber-500/20 bg-amber-500/5 cursor-default">
                    <h3 className="font-semibold text-amber-500 flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" /> Onay Bekleyen Hesaplar ({users.filter(u => !u.is_verified).length})
                    </h3>
                    <p className="text-xs text-amber-500/80 mt-1">Bu kullanıcılar henüz sisteme giriş yapamazlar.</p>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow className="border-amber-500/20 hover:bg-transparent">
                        <TableHead>Kullanıcı</TableHead>
                        <TableHead>Öğrenci No</TableHead>
                        <TableHead>Bölüm</TableHead>
                        <TableHead>Rol</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead className="text-right">İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.filter(u => !u.is_verified).map((u) => (
                        <TableRow key={u.id} className="border-amber-500/20 hover:bg-amber-500/5 transition-colors">
                          <TableCell>
                            <p className="font-medium text-foreground">{u.full_name}</p>
                            <p className="text-xs text-muted-foreground">{u.email}</p>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{u.student_id}</TableCell>
                          <TableCell>{u.department || "-"}</TableCell>
                          <TableCell><Badge variant={u.role === "admin" ? "default" : "secondary"}>{u.role === "admin" ? "Admin" : "Öğrenci"}</Badge></TableCell>
                          <TableCell><Badge className="bg-amber-500/10 text-amber-500" variant="outline">Bekliyor</Badge></TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="outline" className="text-emerald-500 border-emerald-500/30 hover:bg-emerald-500/10" onClick={() => handleApproveUser(u.id)}>
                                <UserCheck className="h-4 w-4 mr-1" /> Onayla
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => openUserDetail(u.id)}><Eye className="h-4 w-4" /></Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {/* Tüm Kullanıcılar */}
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="p-4 border-b border-border flex justify-between items-center bg-muted/20">
                   <h3 className="font-semibold flex items-center gap-2">Kayıtlı Kullanıcılar</h3>
                   <span className="text-xs text-muted-foreground">Toplam: {users.filter(u => u.is_verified).length} Kayıt</span>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Kullanıcı</TableHead>
                      <TableHead>Öğrenci No</TableHead>
                      <TableHead>Bölüm</TableHead>
                      <TableHead>Rol</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.filter(u => u.is_verified).map((u) => (
                      <TableRow key={u.id}>
                        <TableCell>
                          <p className="font-medium">{u.full_name}</p>
                          <p className="text-xs text-muted-foreground">{u.email}</p>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{u.student_id}</TableCell>
                        <TableCell>{u.department || "-"}</TableCell>
                        <TableCell><Badge variant={u.role === "admin" ? "default" : "secondary"}>{u.role === "admin" ? "Admin" : "Öğrenci"}</Badge></TableCell>
                        <TableCell><Badge className={u.is_active ? "bg-success/10 text-success border-0" : "bg-destructive/10 text-destructive border-0"} variant="outline">{u.is_active ? "Aktif" : "Pasif"}</Badge></TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => openUserDetail(u.id)}><Eye className="h-4 w-4" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}

          {/* Loans */}
          {activeSection === "loans" && (
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Kullanıcı</TableHead>
                    <TableHead>Kitap</TableHead>
                    <TableHead>Ödünç Tarihi</TableHead>
                    <TableHead>İade Tarihi</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loans.filter(l => l.status !== "returned").map((loan) => (
                    <TableRow key={loan.id}>
                      <TableCell>{loan.user_name}</TableCell>
                      <TableCell>{loan.book_title}</TableCell>
                      <TableCell>{formatDate(loan.checkout_at)}</TableCell>
                      <TableCell>{formatDate(loan.due_date)}</TableCell>
                      <TableCell>
                        <Badge className={loan.status === "active" ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"}>
                          {loan.status === "active" ? "Aktif" : "Gecikmiş"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="outline" onClick={() => handleReturnBook(loan.id)}>İade Al</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Borrow Requests */}
          {activeSection === "requests" && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Kullanıcıların ödünç talepleri ({borrowRequests.filter(r => r.status === 'pending').length} bekliyor)
              </p>
              {borrowRequests.length === 0 ? (
                <div className="text-center py-12 bg-card rounded-lg border border-border">
                  <UserCheck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Bekleyen Talep Yok</h3>
                  <p className="text-muted-foreground text-sm">Yeni talepler burada görünecek</p>
                </div>
              ) : (
                <div className="bg-card border border-border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Kullanıcı</TableHead>
                        <TableHead>Kitap</TableHead>
                        <TableHead>ISBN</TableHead>
                        <TableHead>Talep Tarihi</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead className="text-right">İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {borrowRequests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.user_name}</TableCell>
                          <TableCell>{request.book_title}</TableCell>
                          <TableCell className="font-mono text-xs">{request.book_isbn}</TableCell>
                          <TableCell>{formatDate(request.created_at)}</TableCell>
                          <TableCell>
                            <Badge className={
                              request.status === 'pending' ? "bg-warning/10 text-warning" :
                                request.status === 'approved' ? "bg-success/10 text-success" :
                                  "bg-destructive/10 text-destructive"
                            }>
                              {request.status === 'pending' ? "Bekliyor" : request.status === 'approved' ? "Onaylandı" : "Reddedildi"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {request.status === 'pending' && (
                              <div className="flex gap-2 justify-end">
                                <Button size="sm" variant="outline" className="text-success border-success/50 hover:bg-success/10" onClick={() => handleProcessRequest(request.id, 'approve')}>
                                  Onayla
                                </Button>
                                <Button size="sm" variant="outline" className="text-destructive" onClick={() => handleProcessRequest(request.id, 'reject')}>
                                  Reddet
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {/* AI Index Status */}
              <AiIndexStatusWidget />
            </div>
          )}

          {/* Overdue */}
          {activeSection === "overdue" && (
            <div className="space-y-4">
              {overdueLoans.length === 0 ? (
                <div className="text-center py-12 bg-card rounded-lg border border-border">
                  <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Geciken Kitap Yok</h3>
                  <p className="text-muted-foreground text-sm">Tüm kitaplar zamanında iade edilmiş</p>
                </div>
              ) : (
                <div className="bg-card border border-border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-destructive/5">
                        <TableHead>Kullanıcı</TableHead>
                        <TableHead>Kitap</TableHead>
                        <TableHead>Ödünç Tarihi</TableHead>
                        <TableHead>Son İade</TableHead>
                        <TableHead>Gecikme</TableHead>
                        <TableHead>Ceza</TableHead>
                        <TableHead className="text-right">İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {overdueLoans.map((loan) => {
                        const daysOverdue = Math.floor((Date.now() - new Date(loan.due_date).getTime()) / (1000 * 60 * 60 * 24));
                        const fine = daysOverdue * 5;
                        return (
                          <TableRow key={loan.id}>
                            <TableCell className="font-medium">{loan.user_name}</TableCell>
                            <TableCell>{loan.book_title}</TableCell>
                            <TableCell>{formatDate(loan.checkout_at)}</TableCell>
                            <TableCell className="text-destructive font-medium">{formatDate(loan.due_date)}</TableCell>
                            <TableCell><Badge variant="destructive">{daysOverdue} gün</Badge></TableCell>
                            <TableCell className="font-mono">{fine} ₺</TableCell>
                            <TableCell className="text-right">
                              <Button size="sm" variant="outline" onClick={() => handleReturnBook(loan.id)}>İade Al</Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          )}

          {/* History */}
          {activeSection === "history" && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Son {loanHistory.length} işlem (kronolojik sıra)</p>
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tarih</TableHead>
                      <TableHead>Kullanıcı</TableHead>
                      <TableHead>Kitap</TableHead>
                      <TableHead>İade Tarihi</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>Ceza</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loanHistory.map((loan) => (
                      <TableRow key={loan.id}>
                        <TableCell className="text-sm">{formatDateTime(loan.checkout_at)}</TableCell>
                        <TableCell className="font-medium">{loan.user_name}</TableCell>
                        <TableCell>{loan.book_title}</TableCell>
                        <TableCell>{loan.returned_at ? formatDate(loan.returned_at) : "-"}</TableCell>
                        <TableCell>
                          <Badge className={
                            loan.status === "active" ? "bg-primary/10 text-primary" :
                              loan.status === "overdue" ? "bg-destructive/10 text-destructive" :
                                "bg-success/10 text-success"
                          }>
                            {loan.status === "active" ? "Aktif" : loan.status === "overdue" ? "Gecikmiş" : "İade Edildi"}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono">{loan.fine_amount > 0 ? `${loan.fine_amount} ₺` : "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}

          {/* Announcements */}
          {activeSection === "announcements" && (
            <div className="space-y-4">
              {announcements.length === 0 ? (
                <div className="text-center py-12">
                  <Megaphone className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Henüz duyuru yok</h3>
                  <Button onClick={() => setAnnouncementDialog(true)} variant="hero"><Plus className="h-4 w-4 mr-2" /> Duyuru Oluştur</Button>
                </div>
              ) : (
                announcements.map((a) => (
                  <div key={a.id} className="bg-card border border-border rounded-lg p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={a.priority === "high" ? "destructive" : "secondary"}>{a.priority === "high" ? "Önemli" : "Normal"}</Badge>
                          {a.is_pinned && <Badge variant="outline">Sabitlenmiş</Badge>}
                        </div>
                        <h3 className="font-semibold">{a.title}</h3>
                        <p className="text-muted-foreground text-sm mt-1">{a.content}</p>
                        <p className="text-xs text-muted-foreground mt-2">{formatDate(a.created_at)}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEditAnnouncement(a)}><Edit className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDeleteAnnouncement(a.id)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Live Support */}
          {activeSection === "support" && (
            <AdminSupportPanel
              onUnreadChange={setSupportUnread}
              focusSessionId={focusSupportSessionId}
              onFocusApplied={() => setFocusSupportSessionId(null)}
            />
          )}

          {/* RFID Manager */}
          {activeSection === "rfid" && (
            <RFIDManagerPanel books={books} />
          )}
        </div>
      </main>

      {/* Checkout Dialog */}
      <Dialog open={checkoutDialog} onOpenChange={setCheckoutDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><BookPlus className="h-5 w-5" /> Kitap Ödünç Ver</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Öğrenci Numarası</Label>
              <div className="flex gap-2">
                <Input value={checkoutForm.student_id} onChange={(e) => setCheckoutForm({ ...checkoutForm, student_id: e.target.value })} placeholder="2021010001" />
                <Button variant="outline" onClick={lookupUser} disabled={lookupLoading.user}>
                  {lookupLoading.user ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserCheck className="h-4 w-4" />}
                </Button>
              </div>
              {checkoutForm.user_name && (
                <p className="text-sm text-success flex items-center gap-1">✓ {checkoutForm.user_name}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label>ISBN Numarası</Label>
              <div className="flex gap-2">
                <Input value={checkoutForm.isbn} onChange={(e) => setCheckoutForm({ ...checkoutForm, isbn: e.target.value })} placeholder="978-..." />
                <Button variant="outline" onClick={lookupBook} disabled={lookupLoading.book}>
                  {lookupLoading.book ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                </Button>
              </div>
              {checkoutForm.book_title && (
                <div className={`p-3 rounded-lg border ${checkoutForm.available_copies > 0 ? 'border-success/50 bg-success/10' : 'border-destructive/50 bg-destructive/10'}`}>
                  <p className={`text-sm font-medium flex items-center gap-1 ${checkoutForm.available_copies > 0 ? 'text-success' : 'text-destructive'}`}>
                    {checkoutForm.available_copies > 0 ? '✓' : '✗'} {checkoutForm.book_title}
                  </p>
                  {checkoutForm.available_copies > 0 ? (
                    <p className="text-xs text-success mt-1">✅ Kitap kiralanmaya uygun - Mevcut: {checkoutForm.available_copies}/{checkoutForm.total_copies} kopya</p>
                  ) : (
                    <p className="text-xs text-destructive mt-1">❌ Kitap ödünç vermeye yeterli değil - Mevcut kopya yok</p>
                  )}
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label>İade Süresi (gün)</Label>
              <Input type="number" value={checkoutForm.due_days} onChange={(e) => setCheckoutForm({ ...checkoutForm, due_days: parseInt(e.target.value) })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setCheckoutDialog(false)}>İptal</Button>
            <Button onClick={handleCheckout} variant="hero" disabled={!checkoutForm.user_id || !checkoutForm.book_id || checkoutForm.available_copies <= 0}>Ödünç Ver</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* User Detail Dialog */}
      <Dialog open={userDetailDialog.open} onOpenChange={(open) => setUserDetailDialog({ open, user: null, loading: false })}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Kullanıcı Detayları</DialogTitle></DialogHeader>
          {userDetailDialog.loading ? (
            <div className="flex items-center justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div>
          ) : userDetailDialog.user && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><Label className="text-muted-foreground text-xs">Ad Soyad</Label><p className="font-medium">{userDetailDialog.user.full_name}</p></div>
                <div><Label className="text-muted-foreground text-xs">E-posta</Label><p className="font-medium">{userDetailDialog.user.email}</p></div>
                <div><Label className="text-muted-foreground text-xs">Öğrenci No</Label><p className="font-mono">{userDetailDialog.user.student_id}</p></div>
                <div><Label className="text-muted-foreground text-xs">Bölüm</Label><p>{userDetailDialog.user.department || "-"}</p></div>
              </div>
              <div className="border-t pt-4">
                <h4 className="font-semibold text-sm mb-3">Düzenle</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">Rol</Label>
                    <Select value={userEditForm.role} onValueChange={(v) => setUserEditForm({ ...userEditForm, role: v })}>
                      <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="student">Öğrenci</SelectItem>
                        <SelectItem value="faculty">Öğretim Görevlisi</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Yeni Şifre</Label>
                    <Input type="password" value={userEditForm.password} onChange={(e) => setUserEditForm({ ...userEditForm, password: e.target.value })} placeholder="••••••" className="h-9" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Max Ödünç</Label>
                    <Input type="number" value={userEditForm.max_books} onChange={(e) => setUserEditForm({ ...userEditForm, max_books: parseInt(e.target.value) })} className="h-9" />
                  </div>
                  <div className="flex items-end pb-1">
                    <label className="flex items-center gap-2 text-sm">
                      <input type="checkbox" checked={userEditForm.is_active} onChange={(e) => setUserEditForm({ ...userEditForm, is_active: e.target.checked })} className="rounded" />
                      Aktif Hesap
                    </label>
                  </div>
                </div>
              </div>
              <div className="border-t pt-4">
                <h4 className="font-semibold text-sm mb-3">Ödünç Geçmişi ({userDetailDialog.user.loans.length})</h4>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {userDetailDialog.user.loans.length > 0 ? userDetailDialog.user.loans.map((loan) => (
                    <div key={loan.id} className="flex items-center justify-between p-2 rounded bg-muted/50 text-sm">
                      <div>
                        <p className="font-medium">{loan.book_title}</p>
                        <p className="text-xs text-muted-foreground">{formatDate(loan.checkout_at)}</p>
                      </div>
                      <Badge className={loan.status === "returned" ? "bg-success/10 text-success" : loan.status === "overdue" ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"}>
                        {loan.status === "returned" ? "İade" : loan.status === "overdue" ? "Gecikmiş" : "Aktif"}
                      </Badge>
                    </div>
                  )) : <p className="text-muted-foreground text-sm">Ödünç kaydı yok</p>}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setUserDetailDialog({ open: false, user: null, loading: false })}>İptal</Button>
            <Button onClick={handleUpdateUser} variant="hero" className="gap-2"><Save className="h-4 w-4" /> Kaydet</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Book Dialog */}
      <Dialog open={bookDialog.open} onOpenChange={(open) => setBookDialog({ open, book: null, mode: "add" })}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>{bookDialog.mode === "add" ? "Yeni Kitap Ekle" : "Kitap Düzenle"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1">
              <Label className="text-xs">ISBN * (Barkod okutun veya manuel girin)</Label>
              <div className="flex gap-2">
                <Input
                  value={bookForm.isbn}
                  onChange={(e) => setBookForm({ ...bookForm, isbn: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      lookupBookByIsbn(bookForm.isbn);
                    }
                  }}
                  className="h-9 flex-1"
                  placeholder="ISBN-13 veya ISBN-10"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => lookupBookByIsbn(bookForm.isbn)}
                  disabled={isbnLookupLoading || !bookForm.isbn}
                  className="h-9 px-3"
                >
                  {isbnLookupLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Enter'a basın veya arama butonuna tıklayın</p>
            </div>
            <div className="space-y-1"><Label className="text-xs">Kitap Adı *</Label><Input value={bookForm.title} onChange={(e) => setBookForm({ ...bookForm, title: e.target.value })} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Yazar *</Label><Input value={bookForm.author} onChange={(e) => setBookForm({ ...bookForm, author: e.target.value })} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Yayınevi</Label><Input value={bookForm.publisher} onChange={(e) => setBookForm({ ...bookForm, publisher: e.target.value })} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Yayın Yılı</Label><Input type="number" value={bookForm.publish_year ?? ""} onChange={(e) => {
              const v = e.target.value;
              setBookForm({ ...bookForm, publish_year: v === "" ? undefined : parseInt(v, 10) });
            }} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Dil</Label>
              <Select value={bookForm.language} onValueChange={(v) => setBookForm({ ...bookForm, language: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Türkçe">Türkçe</SelectItem>
                  <SelectItem value="İngilizce">İngilizce</SelectItem>
                  <SelectItem value="Almanca">Almanca</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label className="text-xs">Kategori (Dewey ile Oto Dolar)</Label><Input value={bookForm.category} onChange={(e) => setBookForm({ ...bookForm, category: e.target.value })} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Dewey Kodu (DDC)</Label><Input value={bookForm.dewey_code} onChange={(e) => setBookForm({ ...bookForm, dewey_code: e.target.value })} placeholder="Örn: 510" className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Sayfa</Label><Input type="number" value={bookForm.pages ?? ""} onChange={(e) => {
              const v = e.target.value;
              setBookForm({ ...bookForm, pages: v === "" ? undefined : parseInt(v, 10) });
            }} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Kopya Sayısı *</Label><Input type="number" min={1} value={bookForm.total_copies ?? 1} onChange={(e) => {
              const v = e.target.value;
              const n = v === "" ? 1 : parseInt(v, 10);
              setBookForm({ ...bookForm, total_copies: Number.isFinite(n) && n >= 1 ? n : 1 });
            }} className="h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">Konum</Label><Input value={bookForm.location} onChange={(e) => setBookForm({ ...bookForm, location: e.target.value })} placeholder="A-101" className="h-9" /></div>
            <div className="col-span-2 space-y-1"><Label className="text-xs">Açıklama</Label><Textarea value={bookForm.description} onChange={(e) => setBookForm({ ...bookForm, description: e.target.value })} rows={2} /></div>
            <div className="col-span-2 space-y-1">
              <Label className="text-xs">Kapak Resmi URL</Label>
              <div className="flex gap-3">
                <Input
                  value={bookForm.cover_image}
                  onChange={(e) => setBookForm({ ...bookForm, cover_image: e.target.value })}
                  className="h-9 flex-1"
                  placeholder="ISBN araması ile otomatik dolar veya manuel girin"
                />
                {bookForm.cover_image && (
                  <img
                    src={bookForm.cover_image}
                    alt="Kapak önizleme"
                    className="h-16 w-12 object-cover rounded border border-border"
                    onError={(e) => (e.currentTarget.style.display = 'none')}
                  />
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setBookDialog({ open: false, book: null, mode: "add" })}>İptal</Button>
            <Button onClick={handleSaveBook} variant="hero">{bookDialog.mode === "add" ? "Ekle" : "Güncelle"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Announcement Dialog */}
      <Dialog open={announcementDialog} onOpenChange={setAnnouncementDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>Yeni Duyuru</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1"><Label className="text-xs">Başlık *</Label><Input value={newAnnouncement.title} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })} /></div>
            <div className="space-y-1"><Label className="text-xs">İçerik *</Label><Textarea value={newAnnouncement.content} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })} rows={3} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label className="text-xs">Öncelik</Label>
                <Select value={newAnnouncement.priority} onValueChange={(v) => setNewAnnouncement({ ...newAnnouncement, priority: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Düşük</SelectItem>
                    <SelectItem value="medium">Normal</SelectItem>
                    <SelectItem value="high">Yüksek</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end pb-1">
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={newAnnouncement.is_pinned} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, is_pinned: e.target.checked })} className="rounded" />
                  Sabitle
                </label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAnnouncementDialog(false)}>İptal</Button>
            <Button onClick={handleAddAnnouncement} variant="hero">Oluştur</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Announcement Dialog */}
      <Dialog open={editAnnouncementDialog.open} onOpenChange={(open) => setEditAnnouncementDialog({ open, announcement: null })}>
        <DialogContent>
          <DialogHeader><DialogTitle>Duyuru Düzenle</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1"><Label className="text-xs">Başlık</Label><Input value={editAnnouncement.title} onChange={(e) => setEditAnnouncement({ ...editAnnouncement, title: e.target.value })} /></div>
            <div className="space-y-1"><Label className="text-xs">İçerik</Label><Textarea value={editAnnouncement.content} onChange={(e) => setEditAnnouncement({ ...editAnnouncement, content: e.target.value })} rows={3} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label className="text-xs">Öncelik</Label>
                <Select value={editAnnouncement.priority} onValueChange={(v) => setEditAnnouncement({ ...editAnnouncement, priority: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Düşük</SelectItem>
                    <SelectItem value="medium">Normal</SelectItem>
                    <SelectItem value="high">Yüksek</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end pb-1">
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={editAnnouncement.is_pinned} onChange={(e) => setEditAnnouncement({ ...editAnnouncement, is_pinned: e.target.checked })} className="rounded" />
                  Sabitle
                </label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditAnnouncementDialog({ open: false, announcement: null })}>İptal</Button>
            <Button onClick={handleUpdateAnnouncement} variant="hero" className="gap-2"><Save className="h-4 w-4" /> Güncelle</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
