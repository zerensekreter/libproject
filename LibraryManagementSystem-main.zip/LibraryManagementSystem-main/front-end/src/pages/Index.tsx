import { useState, useEffect, useCallback } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Search,
  BookOpen,
  Users,
  Clock,
  ArrowRight,
  TrendingUp,
  Library,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MainLayout } from "@/components/layout/MainLayout";
import { BookCard } from "@/components/books/BookCard";
import { Badge } from "@/components/ui/badge";
import { booksAPI, announcementsAPI, adminAPI, borrowRequestsAPI, getToken, getUser, loansAPI, recommendationsAPI } from "@/lib/api";
import { BookCardSkeleton } from "@/components/shared/SkeletonCard";
import { RECO_INVALIDATE_KEY } from "@/lib/recommendationsBus";

interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category?: string;
  language: string;
  publish_year?: number;
  total_copies: number;
  available_copies: number;
  cover_image?: string;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: "high" | "medium" | "low";
  created_at: string;
}

interface Stats {
  books: number;
  users: number;
  dailyLoans: number;
}

export default function Index() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [featuredBooks, setFeaturedBooks] = useState<Book[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [stats, setStats] = useState<Stats>({ books: 0, users: 0, dailyLoans: 0 });
  const [featuredLoading, setFeaturedLoading] = useState(true);
  const [forYouLoading, setForYouLoading] = useState(false);
  const [forYouBooks, setForYouBooks] = useState<Book[]>([]);
  const [forYouNote, setForYouNote] = useState<string | null>(null);
  const [pendingBorrowBookIds, setPendingBorrowBookIds] = useState<Set<string>>(new Set());
  const [activeLoanBookIds, setActiveLoanBookIds] = useState<Set<string>>(new Set());

  const loadForYou = useCallback(async () => {
    const token = getToken();
    if (!token) return;
    setForYouLoading(true);
    setForYouNote(null);
    try {
      const [recs, pending, myLoans] = await Promise.all([
        recommendationsAPI.getForMe({ limit: 4 }),
        borrowRequestsAPI.getMine({ status: "pending" }),
        loansAPI.getMyLoans(),
      ]);

      const s = new Set<string>();
      (pending || []).forEach((r: any) => {
        if (r?.book_id) s.add(String(r.book_id));
      });
      setPendingBorrowBookIds(s);
      const a = new Set<string>();
      (myLoans || []).forEach((l: any) => {
        if (l?.book_id) a.add(String(l.book_id));
      });
      setActiveLoanBookIds(a);
      setForYouBooks(recs || []);
      if (!recs || recs.length === 0) {
        const fallback = await booksAPI.getAll({ limit: 4 });
        setForYouBooks(fallback || []);
        setForYouNote("Kişiselleştirme henüz öğreniyor; şimdilik yeni eklenen kitapları gösteriyoruz.");
      }
    } catch (e: any) {
      const fallback = await booksAPI.getAll({ limit: 4 });
      setForYouBooks(fallback || []);
      setForYouNote(e?.response?.data?.detail || "Öneri sistemi şu an hazırlanıyor; şimdilik yeni kitapları gösteriyoruz.");
    } finally {
      setForYouLoading(false);
    }
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setFeaturedLoading(true);
        const [booksData, announcementsData] = await Promise.all([
          booksAPI.getAll({ limit: 4 }),
          announcementsAPI.getAll({ limit: 2 }),
        ]);
        setFeaturedBooks(booksData);
        setAnnouncements(announcementsData);

        // Only fetch metrics if user is admin - prevents 403 errors
        const user = getUser();
        if (user?.role === "admin") {
          try {
            const metrics = await adminAPI.getMetrics();
            setStats({
              books: metrics.books?.total || 0,
              users: metrics.users?.total || 0,
              dailyLoans: metrics.loans?.active || 0,
            });
          } catch {
            // Fallback to book count
            setStats(prev => ({ ...prev, books: booksData.length }));
          }
        } else {
          // Non-admin users just use book data length
          setStats(prev => ({ ...prev, books: booksData.length }));
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setFeaturedLoading(false);
      }
    };
    fetchData();
  }, []);

  // "Sizin için seçtiklerimiz" (personalized) - only if logged in
  useEffect(() => {
    loadForYou();
  }, [location.key, loadForYou]);

  // Invalidate + refresh when user interacts (favorite/borrow/view signals)
  useEffect(() => {
    const onInvalidate = () => loadForYou();
    window.addEventListener("reco:invalidate", onInvalidate as EventListener);
    const onStorage = (e: StorageEvent) => {
      if (e.key === RECO_INVALIDATE_KEY) loadForYou();
    };
    window.addEventListener("storage", onStorage);
    // Fallback polling: yalnızca login varsa; WS kopma senaryoları için düşük frekans
    const token = getToken();
    const interval = token ? setInterval(() => loadForYou(), 60000) : null;
    return () => {
      window.removeEventListener("reco:invalidate", onInvalidate as EventListener);
      window.removeEventListener("storage", onStorage);
      if (interval) clearInterval(interval);
    };
  }, [loadForYou]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/books?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  const statsDisplay = [
    { label: "Kitap Koleksiyonu", value: stats.books > 0 ? `${stats.books.toLocaleString()}+` : "15,000+", icon: BookOpen },
    { label: "Aktif Üye", value: stats.users > 0 ? stats.users.toLocaleString() : "8,000+", icon: Users },
    { label: "Aktif Ödünç", value: stats.dailyLoans > 0 ? `${stats.dailyLoans}` : "100+", icon: TrendingUp },
    { label: "7/24 Erişim", value: "Online", icon: Clock },
  ];

  const mapBookToCardFormat = (book: Book) => ({
    id: book.id,
    title: book.title,
    author: book.author,
    isbn: book.isbn,
    category: book.category || "Genel",
    language: book.language,
    publishYear: book.publish_year || 2020,
    totalCopies: book.total_copies,
    availableCopies: book.available_copies,
    // Prefer stored cover, otherwise try OpenLibrary by ISBN (varies per book). If unavailable, <img onError> falls back to placeholder.svg.
    coverImage: book.cover_image || `https://covers.openlibrary.org/b/isbn/${encodeURIComponent(book.isbn)}-M.jpg`,
    rating: 4.5,
    pages: 200,
    location: "A-001",
    description: "",
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("tr-TR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative gradient-hero overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto py-20 lg:py-32 relative">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Badge variant="secondary" className="mb-4 gap-2">
                <Sparkles className="h-3 w-3" />
                Trakya Üniversitesi Kütüphanesi
              </Badge>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
                Bilgiye Açılan Kapınız
              </h1>
              <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
                Binlerce kitap, akademik dergi ve dijital kaynak ile araştırmalarınızı
                güçlendirin. Üniversite kütüphanesi her zaman yanınızda.
              </p>
            </motion.div>

            {/* Search Bar */}
            <motion.form
              onSubmit={handleSearch}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="relative max-w-2xl mx-auto"
            >
              <div className="relative">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Kitap adı, yazar veya ISBN ile arayın..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-14 pr-32 h-14 text-base rounded-2xl border-2 shadow-lg focus:border-primary"
                  aria-label="Kitap ara"
                />
                <Button
                  type="submit"
                  variant="hero"
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-10"
                >
                  Ara
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </motion.form>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8"
            >
              {statsDisplay.map((stat) => (
                <div
                  key={stat.label}
                  className="bg-card/50 backdrop-blur-sm rounded-xl p-4 border border-border/50"
                >
                  <stat.icon className="h-6 w-6 text-primary mb-2 mx-auto" />
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Books */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="font-display text-2xl lg:text-3xl font-bold">Öne Çıkan Kitaplar</h2>
              <p className="text-muted-foreground mt-1">En çok ödünç alınan ve beğenilen eserler</p>
            </div>
            <Link to="/books">
              <Button variant="outline" className="gap-2">
                Tümünü Gör
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredLoading ? (
              Array.from({ length: 4 }).map((_, i) => <BookCardSkeleton key={i} />)
            ) : (
              featuredBooks.map((book, index) => (
                <BookCard
                  key={book.id}
                  book={mapBookToCardFormat(book)}
                  index={index}
                  isBorrowRequested={pendingBorrowBookIds.has(String(book.id))}
                  hasActiveLoan={activeLoanBookIds.has(String(book.id))}
                />
              ))
            )}
          </div>
        </div>
      </section>

      {/* For You (AI Personalized) */}
      {!!getToken() && (
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="font-display text-2xl lg:text-3xl font-bold">Sizin için Seçtiklerimiz</h2>
                <p className="text-muted-foreground mt-1">
                  Geçmiş etkileşimlerinize göre kişiselleştirilmiş öneriler
                </p>
                {forYouNote && (
                  <p className="text-xs text-muted-foreground mt-2">{forYouNote}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {forYouLoading ? (
                Array.from({ length: 4 }).map((_, i) => <BookCardSkeleton key={i} />)
              ) : forYouBooks.length ? (
                forYouBooks.map((book, index) => (
                  <BookCard
                    key={book.id}
                    book={mapBookToCardFormat(book)}
                    index={index}
                    isBorrowRequested={pendingBorrowBookIds.has(String(book.id))}
                    hasActiveLoan={activeLoanBookIds.has(String(book.id))}
                  />
                ))
              ) : (
                <div className="col-span-full text-center py-10 text-muted-foreground">
                  Daha iyi öneriler için birkaç kitap görüntüleyin veya favorilere ekleyin.
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Announcements */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="font-display text-2xl lg:text-3xl font-bold">Duyurular</h2>
              <p className="text-muted-foreground mt-1">Kütüphaneden son haberler</p>
            </div>
            <Link to="/announcements">
              <Button variant="outline" className="gap-2">
                Tümünü Gör
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {announcements.map((announcement, index) => (
              <motion.div
                key={announcement.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-card rounded-xl p-6 border border-border shadow-card hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <Badge
                    variant={
                      announcement.priority === "high"
                        ? "destructive"
                        : announcement.priority === "medium"
                          ? "default"
                          : "secondary"
                    }
                  >
                    {announcement.priority === "high"
                      ? "Önemli"
                      : announcement.priority === "medium"
                        ? "Duyuru"
                        : "Bilgi"}
                  </Badge>
                  <span className="text-sm text-muted-foreground">{formatDate(announcement.created_at)}</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">{announcement.title}</h3>
                <p className="text-muted-foreground text-sm line-clamp-2">{announcement.content}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-primary">
        <div className="container mx-auto text-center">
          <Library className="h-12 w-12 text-primary-foreground/80 mx-auto mb-6" />
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-primary-foreground mb-4">
            Kütüphane Üyeliğine Hemen Başlayın
          </h2>
          <p className="text-primary-foreground/80 max-w-xl mx-auto mb-8">
            Üniversite öğrenci veya personeli misiniz? Hemen üye olun ve binlerce kaynağa
            ücretsiz erişim sağlayın.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/auth">
              <Button size="lg" variant="secondary" className="gap-2">
                Üye Ol
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="glass" className="text-primary-foreground border-primary-foreground/20">
                İletişime Geç
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
