import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Calendar, User, Bell, Megaphone, Info, AlertTriangle, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { MainLayout } from "@/components/layout/MainLayout";
import { announcementsAPI } from "@/lib/api";

interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: "high" | "medium" | "low";
  is_pinned: boolean;
  created_at: string;
}

const priorityConfig = {
  high: {
    label: "Önemli",
    variant: "destructive" as const,
    icon: AlertTriangle,
    bg: "bg-destructive/5 border-destructive/20",
  },
  medium: {
    label: "Duyuru",
    variant: "default" as const,
    icon: Megaphone,
    bg: "bg-primary/5 border-primary/20",
  },
  low: {
    label: "Bilgi",
    variant: "secondary" as const,
    icon: Info,
    bg: "bg-muted border-border",
  },
};

export default function Announcements() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        const data = await announcementsAPI.getAll();
        setAnnouncements(data);
      } catch (error) {
        console.error("Error fetching announcements:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchAnnouncements();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("tr-TR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto py-8 lg:py-12 flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto py-8 lg:py-12">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Bell className="h-6 w-6 text-primary" />
            </div>
            <h1 className="font-display text-3xl lg:text-4xl font-bold">
              Duyurular
            </h1>
          </div>
          <p className="text-muted-foreground">
            Kütüphaneden önemli haberler ve güncellemeler
          </p>
        </div>

        {/* Announcements List */}
        <div className="space-y-4">
          {announcements.map((announcement, index) => {
            const config = priorityConfig[announcement.priority];
            const PriorityIcon = config.icon;

            return (
              <motion.article
                key={announcement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`rounded-xl border p-6 transition-shadow hover:shadow-lg ${config.bg}`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${announcement.priority === "high"
                          ? "bg-destructive/10"
                          : announcement.priority === "medium"
                            ? "bg-primary/10"
                            : "bg-muted"
                        }`}
                    >
                      <PriorityIcon
                        className={`h-5 w-5 ${announcement.priority === "high"
                            ? "text-destructive"
                            : announcement.priority === "medium"
                              ? "text-primary"
                              : "text-muted-foreground"
                          }`}
                      />
                    </div>
                    <div>
                      <Badge variant={config.variant}>{config.label}</Badge>
                      {announcement.is_pinned && (
                        <Badge variant="outline" className="ml-2">Sabitlenmiş</Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {formatDate(announcement.created_at)}
                    </span>
                  </div>
                </div>

                <h2 className="font-display text-xl font-semibold mb-2">
                  {announcement.title}
                </h2>
                <p className="text-muted-foreground">{announcement.content}</p>
              </motion.article>
            );
          })}
        </div>

        {/* Empty State */}
        {announcements.length === 0 && (
          <div className="text-center py-16">
            <Megaphone className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Duyuru Yok</h3>
            <p className="text-muted-foreground">
              Şu anda görüntülenecek duyuru bulunmuyor.
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
