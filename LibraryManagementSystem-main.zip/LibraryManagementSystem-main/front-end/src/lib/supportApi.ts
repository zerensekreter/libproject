import api, { getToken } from './api';

const API_VERSION = '/api/v1';
const WS_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace('http', 'ws');

// Types
export interface SupportSession {
    id: string;
    user_id: string;
    user_name: string;
    user_email: string;
    status: 'active' | 'closed';
    last_message_at: string;
    last_message_preview: string | null;
    unread_count: number;
    user_unread_count: number;
    created_at: string;
    closed_at: string | null;
    is_online: boolean;
}

export interface ChatMessage {
    id: string;
    session_id: string;
    sender_id: string | null;
    sender_name: string;
    sender_type: 'user' | 'admin' | 'system';
    content: string;
    delivered?: boolean;
    is_read: boolean;
    created_at: string;
}

// REST API
export const supportAPI = {
    // Kullanıcı endpoints
    createOrGetSession: async (): Promise<SupportSession> => {
        const response = await api.post(`${API_VERSION}/support/sessions`);
        return response.data;
    },

    getMySession: async (): Promise<SupportSession | null> => {
        const response = await api.get(`${API_VERSION}/support/my-session`);
        return response.data;
    },

    getMyUnreadCount: async (): Promise<{ unread_count: number }> => {
        const response = await api.get(`${API_VERSION}/support/my-unread-count`);
        return response.data;
    },

    getMessages: async (sessionId: string, skip = 0, limit = 50): Promise<ChatMessage[]> => {
        const response = await api.get(`${API_VERSION}/support/sessions/${sessionId}/messages`, {
            params: { skip, limit }
        });
        return response.data;
    },

    getSessionHistory: async (skip = 0, limit = 20): Promise<SupportSession[]> => {
        const response = await api.get(`${API_VERSION}/support/history`, {
            params: { skip, limit }
        });
        return response.data;
    },

    // Public endpoint
    getAdminOnlineStatus: async (): Promise<{ online: boolean }> => {
        const response = await api.get(`${API_VERSION}/support/admin/online-status`);
        return response.data;
    },

    // Admin endpoints
    getSessions: async (status?: string): Promise<SupportSession[]> => {
        const response = await api.get(`${API_VERSION}/support/sessions`, {
            params: status ? { status } : undefined
        });
        return response.data;
    },

    getAdminUnreadCount: async (): Promise<{ unread_count: number }> => {
        const response = await api.get(`${API_VERSION}/support/admin/unread-count`);
        return response.data;
    },

    closeSession: async (sessionId: string): Promise<void> => {
        await api.post(`${API_VERSION}/support/sessions/${sessionId}/close`);
    },

    reopenSession: async (sessionId: string): Promise<void> => {
        await api.post(`${API_VERSION}/support/sessions/${sessionId}/reopen`);
    },

    // WebSocket URLs
    getUserWebSocketUrl: (sessionId: string): string => {
        const token = getToken();
        return `${WS_BASE_URL}${API_VERSION}/support/ws/${sessionId}?token=${token}`;
    },

    getAdminWebSocketUrl: (): string => {
        const token = getToken();
        return `${WS_BASE_URL}${API_VERSION}/support/ws/admin?token=${token}`;
    }
};

// Admin ops API (enterprise)
export const adminAPI = {
    getAiStatus: async () => {
        const response = await api.get(`${API_VERSION}/admin/ai/status`);
        return response.data;
    },
    retrainAi: async () => {
        const response = await api.post(`${API_VERSION}/admin/ai/retrain`);
        return response.data;
    }
};

// Notification sound utility
let notificationSound: HTMLAudioElement | null = null;

export const playNotificationSound = () => {
    if (!notificationSound) {
        // Simple beep sound using data URL
        notificationSound = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2teleVknU6Ha0bJuRxM2dqzN0cSDbUYnRKjI1MamiG5LGC+Su9XElnxpSB8vkLzSx5iHako+TqnK08mgmnFPPE+bwMvPpodvRiRAidTP0amYhlpMRImvx9HVqYxjQzk+g6nN1K2TdU89PX2hwdCrlX5dUj06eKK7y6yhe2BWQESHrMfHp49ySD1AeJ27wquZdVI7I0R8pbvCqpmFXEU4QnWhucOtmolhRDlFep64wLGdk3ZZPTJBa5qyv7OdkH1bTD5GZ5Sqt7OhjH1gSz0/XZGZ');
    }
    notificationSound.currentTime = 0;
    notificationSound.volume = 0.5;
    notificationSound.play().catch(() => {
        // Ignore autoplay restrictions
    });
};
