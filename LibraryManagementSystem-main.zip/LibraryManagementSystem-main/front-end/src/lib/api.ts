import axios, { AxiosError, AxiosInstance } from 'axios';

// API Base URL - Backend server
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
const API_VERSION = '/api/v1';

// Create axios instance
const api: AxiosInstance = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Token management
export const getToken = (): string | null => {
    return localStorage.getItem('access_token');
};

export const setToken = (token: string): void => {
    localStorage.setItem('access_token', token);
};

export const removeToken = (): void => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
};

export const getUser = () => {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
};

export const setUser = (user: any): void => {
    localStorage.setItem('user', JSON.stringify(user));
};

// Request interceptor - add auth token
api.interceptors.request.use(
    (config) => {
        const token = getToken();
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// Response interceptor - handle errors
api.interceptors.response.use(
    (response) => response,
    (error: AxiosError) => {
        if (error.response?.status === 401) {
            // Only redirect to auth if user was logged in (had a token)
            // This prevents redirect for public API calls that return 401
            const hadToken = getToken();
            if (hadToken) {
                removeToken();
                window.location.href = '/auth';
            }
        }
        return Promise.reject(error);
    }
);

// Auth API
export const authAPI = {
    login: async (email: string, password: string) => {
        const formData = new URLSearchParams();
        formData.append('username', email);
        formData.append('password', password);

        const response = await api.post(`${API_VERSION}/auth/login`, formData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
        return response.data;
    },

    register: async (data: {
        email: string;
        password: string;
        student_id: string;
        full_name: string;
        department?: string;
    }) => {
        const response = await api.post(`${API_VERSION}/auth/register`, data);
        return response.data;
    },

    getMe: async () => {
        const response = await api.get(`${API_VERSION}/auth/me`);
        return response.data;
    },
};

// Books API
export const booksAPI = {
    getAll: async (
        params?: {
        skip?: number;
        limit?: number;
        search?: string;
        category?: string;
        available_only?: boolean;
    },
        options?: { signal?: AbortSignal }
    ) => {
        const response = await api.get(`${API_VERSION}/books/`, { params, signal: options?.signal });
        return response.data;
    },

    getById: async (id: string) => {
        const response = await api.get(`${API_VERSION}/books/${id}`);
        return response.data;
    },

    getByIsbn: async (isbn: string) => {
        const response = await api.get(`${API_VERSION}/books/isbn/${isbn}`);
        return response.data;
    },

    getCategories: async () => {
        const response = await api.get(`${API_VERSION}/books/categories`);
        return response.data;
    },

    create: async (data: any) => {
        const response = await api.post(`${API_VERSION}/books/`, data);
        return response.data;
    },

    update: async (id: string, data: any) => {
        const response = await api.put(`${API_VERSION}/books/${id}`, data);
        return response.data;
    },

    delete: async (id: string) => {
        const response = await api.delete(`${API_VERSION}/books/${id}`);
        return response.data;
    },
};

// Users API
export const usersAPI = {
    getAll: async (params?: { skip?: number; limit?: number; search?: string }) => {
        const response = await api.get(`${API_VERSION}/users/`, { params });
        return response.data;
    },

    getById: async (id: string) => {
        const response = await api.get(`${API_VERSION}/users/${id}`);
        return response.data;
    },

    getDetail: async (id: string) => {
        const response = await api.get(`${API_VERSION}/users/${id}/detail`);
        return response.data;
    },

    lookupByStudentId: async (studentId: string) => {
        const response = await api.get(`${API_VERSION}/users/lookup/${studentId}`);
        return response.data;
    },

    update: async (id: string, data: { role?: string; password?: string; is_active?: boolean; max_books?: number }) => {
        const response = await api.put(`${API_VERSION}/users/${id}`, data);
        return response.data;
    },

    deactivate: async (id: string) => {
        const response = await api.delete(`${API_VERSION}/users/${id}`);
        return response.data;
    },
};

// Loans API
export const loansAPI = {
    getAll: async (params?: { skip?: number; limit?: number; status?: string }) => {
        const response = await api.get(`${API_VERSION}/loans/`, { params });
        return response.data;
    },

    getMyLoans: async () => {
        const response = await api.get(`${API_VERSION}/loans/my-loans`);
        return response.data;
    },

    getHistory: async (params?: { skip?: number; limit?: number }) => {
        const response = await api.get(`${API_VERSION}/loans/history`, { params });
        return response.data;
    },

    getOverdue: async () => {
        const response = await api.get(`${API_VERSION}/loans/overdue`);
        return response.data;
    },

    checkout: async (data: { user_id: string; book_id: string; due_days?: number }) => {
        const response = await api.post(`${API_VERSION}/loans/checkout`, data);
        return response.data;
    },

    return: async (data: { loan_id: string; notes?: string }) => {
        const response = await api.post(`${API_VERSION}/loans/return`, data);
        return response.data;
    },
};

// Announcements API
export const announcementsAPI = {
    getAll: async (params?: { skip?: number; limit?: number; active_only?: boolean }) => {
        const response = await api.get(`${API_VERSION}/announcements/`, { params });
        return response.data;
    },

    create: async (data: { title: string; content: string; priority?: string; is_pinned?: boolean }) => {
        const response = await api.post(`${API_VERSION}/announcements/`, data);
        return response.data;
    },

    update: async (id: string, data: { title?: string; content?: string; priority?: string; is_pinned?: boolean; is_active?: boolean }) => {
        const response = await api.put(`${API_VERSION}/announcements/${id}`, data);
        return response.data;
    },

    delete: async (id: string) => {
        const response = await api.delete(`${API_VERSION}/announcements/${id}`);
        return response.data;
    },
};

// Contact API
export const contactAPI = {
    submit: async (data: { name: string; email: string; subject: string; message: string }) => {
        const response = await api.post(`${API_VERSION}/contact/`, data);
        return response.data;
    },

    getAll: async () => {
        const response = await api.get(`${API_VERSION}/contact/`);
        return response.data;
    },
};

// Admin API
export const adminAPI = {
    getStatus: async () => {
        const response = await api.get(`${API_VERSION}/admin/status`);
        return response.data;
    },

    getMetrics: async () => {
        const response = await api.get(`${API_VERSION}/admin/metrics`);
        return response.data;
    },

    getOverdueLoans: async () => {
        const response = await api.get(`${API_VERSION}/admin/overdue-loans`);
        return response.data;
    },
};

// Favorites API
export const favoritesAPI = {
    getAll: async () => {
        const response = await api.get(`${API_VERSION}/favorites`);
        return response.data;
    },

    add: async (bookId: string) => {
        const response = await api.post(`${API_VERSION}/favorites/${bookId}`);
        return response.data;
    },

    remove: async (bookId: string) => {
        const response = await api.delete(`${API_VERSION}/favorites/${bookId}`);
        return response.data;
    },

    check: async (bookId: string) => {
        const response = await api.get(`${API_VERSION}/favorites/check/${bookId}`);
        return response.data;
    },
};

// Borrow Requests API
export const borrowRequestsAPI = {
    getAll: async (status?: string) => {
        const response = await api.get(`${API_VERSION}/borrow-requests`, { params: { status } });
        return response.data;
    },

    getMine: async (params?: { status?: string; book_id?: string }) => {
        const response = await api.get(`${API_VERSION}/borrow-requests/me`, { params });
        return response.data;
    },

    create: async (bookId: string) => {
        const response = await api.post(`${API_VERSION}/borrow-requests/${bookId}`);
        return response.data;
    },

    cancel: async (requestId: string) => {
        const response = await api.delete(`${API_VERSION}/borrow-requests/${requestId}`);
        return response.data;
    },

    process: async (requestId: string, action: 'approve' | 'reject', notes?: string) => {
        const response = await api.post(`${API_VERSION}/borrow-requests/${requestId}/process`, { action, notes });
        return response.data;
    },
};

// Notifications API
export const notificationsAPI = {
    getAll: async () => {
        const response = await api.get(`${API_VERSION}/notifications`);
        return response.data;
    },

    getUnreadCount: async () => {
        const response = await api.get(`${API_VERSION}/notifications/unread-count`);
        return response.data;
    },

    markAsRead: async (notificationId: string) => {
        const response = await api.post(`${API_VERSION}/notifications/${notificationId}/read`);
        return response.data;
    },

    markAllAsRead: async () => {
        const response = await api.post(`${API_VERSION}/notifications/read-all`);
        return response.data;
    },
};

// Password API
export const passwordAPI = {
    change: async (currentPassword: string, newPassword: string) => {
        const response = await api.post(`${API_VERSION}/change-password`, {
            current_password: currentPassword,
            new_password: newPassword,
        });
        return response.data;
    },
};

// Recommendations (AI)
export const recommendationsAPI = {
    query: async (data: { text: string; limit?: number }) => {
        const response = await api.post(`${API_VERSION}/recommendations/query`, {
            text: data.text,
            limit: data.limit ?? 5
        });
        return response.data;
    },
    getForMe: async (params?: { limit?: number; q?: string }) => {
        const response = await api.get(`${API_VERSION}/recommendations/me`, { params });
        return response.data;
    },
};

// Events (AI signals) - requires auth
export const eventsAPI = {
    trackBookView: async (bookId: string) => {
        const response = await api.post(`${API_VERSION}/events/book-view/${bookId}`);
        return response.data;
    },
    trackSearch: async (query: string) => {
        const response = await api.post(`${API_VERSION}/events/search`, { query });
        return response.data;
    },
    trackRecommendationClick: async (bookId: string) => {
        const response = await api.post(`${API_VERSION}/events/recommendation-click/${bookId}`);
        return response.data;
    },
};

// RFID API
export const rfidAPI = {
    getStatus: async () => {
        const response = await api.get(`${API_VERSION}/rfid/status`);
        return response.data;
    },

    startAssignment: async (bookId: string, timeout: number = 30) => {
        const response = await api.post(`${API_VERSION}/books/${bookId}/start-rfid-assignment`, { timeout });
        return response.data;
    },

    scanLookup: async (timeout: number = 10) => {
        const response = await api.post(`${API_VERSION}/rfid/scan-lookup`, { timeout });
        return response.data;
    },

    lookupByUid: async (uid: string) => {
        const response = await api.get(`${API_VERSION}/rfid/lookup/${uid}`);
        return response.data;
    },

    getCopies: async (bookId: string) => {
        const response = await api.get(`${API_VERSION}/rfid/copies/${bookId}`);
        return response.data;
    },

    deleteCopy: async (copyId: string) => {
        const response = await api.delete(`${API_VERSION}/rfid/copies/${copyId}`);
        return response.data;
    },
};

export default api;
