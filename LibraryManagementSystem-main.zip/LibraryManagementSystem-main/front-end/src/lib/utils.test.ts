import { describe, it, expect } from 'vitest'
import { cn } from './utils'

describe('cn utility function', () => {
    it('should merge class names correctly', () => {
        const result = cn('text-red-500', 'bg-blue-500')
        expect(result).toBe('text-red-500 bg-blue-500')
    })

    it('should handle conditional classes', () => {
        const isActive = true
        const result = cn('base-class', isActive && 'active-class')
        expect(result).toContain('base-class')
        expect(result).toContain('active-class')
    })

    it('should handle falsy values', () => {
        const result = cn('base', false, null, undefined, 'other')
        expect(result).toBe('base other')
    })

    it('should merge tailwind classes properly', () => {
        const result = cn('p-4', 'p-2')
        expect(result).toBe('p-2')
    })
})
