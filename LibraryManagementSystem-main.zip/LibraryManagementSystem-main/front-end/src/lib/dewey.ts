export const DEWEY_CATEGORIES: Record<string, string> = {
  "000": "Bilgisayar, Bilgi ve Genel Çalışmalar",
  "100": "Felsefe ve Psikoloji",
  "200": "Din",
  "300": "Sosyal Bilimler",
  "400": "Dil",
  "500": "Bilim",
  "600": "Teknoloji (Uygulamalı Bilimler)",
  "700": "Sanat ve Eğlence",
  "800": "Edebiyat",
  "900": "Tarih ve Coğrafya",
};

export const getDeweyCategory = (deweyCode: string | null | undefined): string | null => {
  if (!deweyCode) return null;
  // Sadece sayısal kısmı alıp ilk basamağı kontrol etmek
  const firstDigitPattern = deweyCode.match(/^(\d)/);
  if (!firstDigitPattern) return null;

  const firstDigit = firstDigitPattern[1];
  const mainCategoryCode = `${firstDigit}00`;
  
  return DEWEY_CATEGORIES[mainCategoryCode] || null;
};
