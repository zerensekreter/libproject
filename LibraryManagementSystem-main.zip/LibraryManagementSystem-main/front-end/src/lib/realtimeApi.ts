import { getToken } from "@/lib/api";

const API_VERSION = "/api/v1";
const WS_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "http://localhost:8000").replace("http", "ws");

export const realtimeAPI = {
  getRealtimeWsUrl: (): string => {
    const token = getToken();
    return `${WS_BASE_URL}${API_VERSION}/realtime/ws?token=${token}`;
  },
};


