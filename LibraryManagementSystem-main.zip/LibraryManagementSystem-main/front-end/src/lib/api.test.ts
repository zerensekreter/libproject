import { describe, it, expect, vi, beforeEach } from 'vitest'
import { getToken, setToken, removeToken, getUser, setUser } from './api'

describe('Token Management', () => {
    beforeEach(() => {
        localStorage.clear()
    })

    it('should set and get token', () => {
        setToken('test-token-123')
        expect(getToken()).toBe('test-token-123')
    })

    it('should return null when no token', () => {
        expect(getToken()).toBeNull()
    })

    it('should remove token and user', () => {
        setToken('test-token')
        setUser({ name: 'Test User' })
        removeToken()
        expect(getToken()).toBeNull()
        expect(localStorage.getItem('user')).toBeNull()
    })
})

describe('User Management', () => {
    beforeEach(() => {
        localStorage.clear()
    })

    it('should set and get user', () => {
        const user = { id: '1', name: 'Test User', email: 'test@example.com' }
        setUser(user)
        expect(getUser()).toEqual(user)
    })

    it('should return null when no user', () => {
        expect(getUser()).toBeNull()
    })
})
