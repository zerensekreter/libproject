/**
 * Lightweight invalidation bus for "Sizin için Seçtiklerimiz".
 * - Same tab: CustomEvent
 * - Cross-tab: localStorage + storage event
 */

export const RECO_INVALIDATE_KEY = "reco_invalidate_at";

export function invalidateForYouRecommendations() {
  try {
    localStorage.setItem(RECO_INVALIDATE_KEY, String(Date.now()));
  } catch {
    // ignore
  }
  try {
    window.dispatchEvent(new CustomEvent("reco:invalidate"));
  } catch {
    // ignore
  }
}


