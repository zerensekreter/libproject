import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

import { borrowRequestsAPI, getToken } from "@/lib/api";
import { invalidateForYouRecommendations } from "@/lib/recommendationsBus";

type BorrowActionInput = {
  bookId: string;
  bookTitle: string;
  isAvailable: boolean;
};

type BorrowActionResult = {
  borrowLoading: boolean;
  requested: boolean;
  requestBorrow: (e?: React.MouseEvent) => Promise<void>;
  setRequested: (v: boolean) => void;
};

export function useBorrowRequestAction(input: BorrowActionInput): BorrowActionResult {
  const navigate = useNavigate();
  const [borrowLoading, setBorrowLoading] = useState(false);
  const [requested, setRequested] = useState(false);

  const requestBorrow = useCallback(
    async (e?: React.MouseEvent) => {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }

      const token = getToken();
      if (!token) {
        toast.error("Giriş yapmalısınız", { description: "Kitap ödünç almak için giriş yapın." });
        navigate("/auth");
        return;
      }

      if (!input.isAvailable) {
        toast.info("Kitap mevcut değil", { description: "Bu kitap şu an ödünç verilmiş durumda." });
        return;
      }

      setBorrowLoading(true);
      try {
        await borrowRequestsAPI.create(input.bookId);
        setRequested(true);
        toast.success("Ödünç Talebi Gönderildi", {
          description: `"${input.bookTitle}" için talebiniz yöneticiye iletildi.`,
        });
        invalidateForYouRecommendations();
      } catch (err: unknown) {
        const e2 = err as { response?: { data?: { detail?: string } } };
        const detail = e2?.response?.data?.detail || "Talep gönderilemedi";
        // If already requested, reflect it locally so user gets immediate feedback
        if (typeof detail === "string" && detail.toLowerCase().includes("istek")) {
          setRequested(true);
        }
        toast.error(detail);
      } finally {
        setBorrowLoading(false);
      }
    },
    [input.bookId, input.bookTitle, input.isAvailable, navigate]
  );

  return { borrowLoading, requested, requestBorrow, setRequested };
}



