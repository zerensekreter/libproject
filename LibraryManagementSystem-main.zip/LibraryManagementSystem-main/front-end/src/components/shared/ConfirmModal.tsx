import { ReactNode } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertTriangle, Info, CheckCircle2, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface ConfirmModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  confirmText?: string;
  cancelText?: string;
  variant?: "default" | "destructive" | "warning" | "success";
  onConfirm: () => void;
  onCancel?: () => void;
  icon?: ReactNode;
}

const variantStyles = {
  default: {
    icon: <Info className="h-6 w-6" />,
    iconBg: "bg-primary/10 text-primary",
    confirmClass: "",
  },
  destructive: {
    icon: <XCircle className="h-6 w-6" />,
    iconBg: "bg-destructive/10 text-destructive",
    confirmClass: "bg-destructive hover:bg-destructive/90",
  },
  warning: {
    icon: <AlertTriangle className="h-6 w-6" />,
    iconBg: "bg-warning/10 text-warning",
    confirmClass: "bg-warning text-warning-foreground hover:bg-warning/90",
  },
  success: {
    icon: <CheckCircle2 className="h-6 w-6" />,
    iconBg: "bg-success/10 text-success",
    confirmClass: "bg-success hover:bg-success/90",
  },
};

export function ConfirmModal({
  open,
  onOpenChange,
  title,
  description,
  confirmText = "Onayla",
  cancelText = "İptal",
  variant = "default",
  onConfirm,
  onCancel,
  icon,
}: ConfirmModalProps) {
  const styles = variantStyles[variant];

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-start gap-4">
            <div className={cn("p-3 rounded-xl", styles.iconBg)}>
              {icon || styles.icon}
            </div>
            <div className="flex-1">
              <AlertDialogTitle className="text-lg">{title}</AlertDialogTitle>
              <AlertDialogDescription className="mt-2">
                {description}
              </AlertDialogDescription>
            </div>
          </div>
        </AlertDialogHeader>
        <AlertDialogFooter className="mt-4">
          <AlertDialogCancel onClick={onCancel}>{cancelText}</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className={styles.confirmClass}
          >
            {confirmText}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
