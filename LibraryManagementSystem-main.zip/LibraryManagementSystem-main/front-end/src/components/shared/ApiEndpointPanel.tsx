import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Code2, ChevronDown, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ApiEndpoint {
  method: string;
  path: string;
  description: string;
  queryParams?: string[];
  exampleRequest?: string | object;
  exampleResponse: object;
}

interface ApiEndpointPanelProps {
  title: string;
  endpoints: Record<string, ApiEndpoint>;
}

const methodColors: Record<string, string> = {
  GET: "bg-success/20 text-success",
  POST: "bg-primary/20 text-primary",
  PUT: "bg-warning/20 text-warning",
  DELETE: "bg-destructive/20 text-destructive",
};

export function ApiEndpointPanel({ title, endpoints }: ApiEndpointPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="border border-border rounded-xl overflow-hidden bg-card shadow-card">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-inset"
        aria-expanded={isOpen}
        aria-controls="api-panel-content"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Code2 className="h-5 w-5 text-primary" />
          </div>
          <div className="text-left">
            <h3 className="font-semibold text-sm">API Dokümantasyonu</h3>
            <p className="text-xs text-muted-foreground">{title}</p>
          </div>
        </div>
        <ChevronDown
          className={cn(
            "h-5 w-5 text-muted-foreground transition-transform duration-200",
            isOpen && "rotate-180"
          )}
        />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="api-panel-content"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="p-4 pt-0 space-y-4 max-h-[500px] overflow-y-auto custom-scrollbar">
              {Object.entries(endpoints).map(([key, endpoint]) => (
                <div
                  key={key}
                  className="border border-border rounded-lg p-4 space-y-3 bg-muted/30"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={cn(
                          "px-2 py-0.5 rounded text-xs font-mono font-semibold",
                          methodColors[endpoint.method]
                        )}
                      >
                        {endpoint.method}
                      </span>
                      <code className="text-sm font-mono text-foreground bg-background px-2 py-0.5 rounded">
                        {endpoint.path}
                      </code>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground">
                    {endpoint.description}
                  </p>

                  {endpoint.queryParams && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">
                        Query Parameters:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {endpoint.queryParams.map((param) => (
                          <span
                            key={param}
                            className="px-2 py-0.5 rounded bg-accent/30 text-xs font-mono"
                          >
                            {param}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {endpoint.exampleRequest && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-xs font-medium text-muted-foreground">
                          Örnek İstek:
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2"
                          onClick={() =>
                            copyToClipboard(
                              typeof endpoint.exampleRequest === "string"
                                ? endpoint.exampleRequest
                                : JSON.stringify(endpoint.exampleRequest, null, 2),
                              `req-${key}`
                            )
                          }
                        >
                          {copiedKey === `req-${key}` ? (
                            <Check className="h-3 w-3" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </Button>
                      </div>
                      <pre className="text-xs font-mono bg-sidebar text-sidebar-foreground p-3 rounded-lg overflow-x-auto">
                        {typeof endpoint.exampleRequest === "string"
                          ? endpoint.exampleRequest
                          : JSON.stringify(endpoint.exampleRequest, null, 2)}
                      </pre>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs font-medium text-muted-foreground">
                        Örnek Yanıt:
                      </p>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2"
                        onClick={() =>
                          copyToClipboard(
                            JSON.stringify(endpoint.exampleResponse, null, 2),
                            `res-${key}`
                          )
                        }
                      >
                        {copiedKey === `res-${key}` ? (
                          <Check className="h-3 w-3" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </Button>
                    </div>
                    <pre className="text-xs font-mono bg-sidebar text-sidebar-foreground p-3 rounded-lg overflow-x-auto max-h-40">
                      {JSON.stringify(endpoint.exampleResponse, null, 2)}
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
