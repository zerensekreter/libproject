import { useEffect, useRef, useState } from "react";

import { getToken } from "@/lib/api";
import { realtimeAPI } from "@/lib/realtimeApi";
import { invalidateForYouRecommendations } from "@/lib/recommendationsBus";

type RecoEvent = { type: "reco_invalidate"; reason?: string; ts?: number };

export function RecommendationsRealtimeBridge() {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const reconnectAttemptRef = useRef(0);
  const invalidateTimerRef = useRef<number | null>(null);
  const [connected, setConnected] = useState(false);

  const debounceInvalidate = () => {
    // collapse bursts (e.g., rapid views) into a single refetch
    if (invalidateTimerRef.current) window.clearTimeout(invalidateTimerRef.current);
    invalidateTimerRef.current = window.setTimeout(() => {
      invalidateForYouRecommendations();
    }, 250);
  };

  const closeWs = () => {
    if (wsRef.current) {
      try {
        wsRef.current.close(1000, "closing");
      } catch {
        // ignore
      }
      wsRef.current = null;
    }
    setConnected(false);
  };

  const scheduleReconnect = (delayMs: number) => {
    if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
    reconnectTimerRef.current = window.setTimeout(() => {
      connect();
    }, delayMs);
  };

  const connect = () => {
    const token = getToken();
    if (!token) {
      closeWs();
      reconnectAttemptRef.current = 0;
      return;
    }

    // avoid duplicate connections
    if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const ws = new WebSocket(realtimeAPI.getRealtimeWsUrl());
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      reconnectAttemptRef.current = 0;
    };

    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data) as RecoEvent;
        if (msg?.type === "reco_invalidate") {
          debounceInvalidate();
        }
      } catch {
        // ignore malformed
      }
    };

    ws.onclose = (evt) => {
      setConnected(false);
      wsRef.current = null;
      // Normal close -> no aggressive reconnect
      if (evt.code === 1000) return;
      // Exponential backoff with jitter (caps at 30s)
      const attempt = Math.min(reconnectAttemptRef.current + 1, 6);
      reconnectAttemptRef.current = attempt;
      const base = Math.min(30000, 500 * (2 ** attempt));
      const jitter = Math.floor(Math.random() * 250);
      scheduleReconnect(base + jitter);
    };

    ws.onerror = () => {
      // Will trigger onclose; keep minimal handling
      setConnected(false);
    };
  };

  useEffect(() => {
    connect();

    // Reconnect on token changes across tabs or logout/login
    const onStorage = (e: StorageEvent) => {
      if (e.key === "access_token") {
        closeWs();
        scheduleReconnect(250);
      }
    };
    window.addEventListener("storage", onStorage);

    return () => {
      window.removeEventListener("storage", onStorage);
      if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
      if (invalidateTimerRef.current) window.clearTimeout(invalidateTimerRef.current);
      closeWs();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // component is headless; keep a tiny state to avoid TS complaining about unused connected in future
  void connected;
  return null;
}


