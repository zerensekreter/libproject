import { useEffect, useState } from "react";
import { Search, SlidersHorizontal, X, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";

// Inline categories and languages (previously from mockData)
const categories = [
  "Tümü",
  "Roman",
  "Bilim",
  "Tarih",
  "Felsefe",
  "Psikoloji",
  "Edebiyat",
  "Bilgisayar",
  "Ekonomi",
  "Hukuk",
  "Tıp",
  "Mühendislik",
];

const languages = ["Tümü", "Türkçe", "İngilizce", "Almanca", "Fransızca", "Arapça"];

interface BooksFilterProps {
  onSearch: (query: string) => void;
  suggestions?: Array<{
    id: string;
    title: string;
    author: string;
    isbn: string;
    category?: string;
    available_copies?: number;
  }>;
  onSelectSuggestion?: (bookId: string) => void;
  onCategoryChange: (category: string) => void;
  onLanguageChange: (language: string) => void;
  onSortChange: (sort: string) => void;
  onAvailableOnlyChange: (available: boolean) => void;
  activeFilters: {
    search: string;
    category: string;
    language: string;
    sort: string;
    availableOnly: boolean;
  };
  isSearching?: boolean;
}

const sortOptions = [
  { value: "title-asc", label: "A-Z (Başlık)" },
  { value: "title-desc", label: "Z-A (Başlık)" },
  { value: "rating-desc", label: "En Yüksek Puan" },
  { value: "year-desc", label: "En Yeni" },
  { value: "year-asc", label: "En Eski" },
];

export function BooksFilter({
  onSearch,
  suggestions = [],
  onSelectSuggestion,
  onCategoryChange,
  onLanguageChange,
  onSortChange,
  onAvailableOnlyChange,
  activeFilters,
  isSearching = false,
}: BooksFilterProps) {
  const [searchValue, setSearchValue] = useState(activeFilters.search);
  const [isSuggestOpen, setIsSuggestOpen] = useState(false);
  const [activeIdx, setActiveIdx] = useState(-1);

  const renderHighlight = (text: string, query: string) => {
    const q = (query || "").trim();
    if (!q) return text;
    const lower = text.toLowerCase();
    const qLower = q.toLowerCase();
    if (!lower.includes(qLower)) return text;

    // Highlight all occurrences (case-insensitive) safely without regex edge-cases
    const parts: Array<{ t: string; m: boolean }> = [];
    let i = 0;
    while (i < text.length) {
      const next = lower.indexOf(qLower, i);
      if (next === -1) {
        parts.push({ t: text.slice(i), m: false });
        break;
      }
      if (next > i) parts.push({ t: text.slice(i, next), m: false });
      parts.push({ t: text.slice(next, next + q.length), m: true });
      i = next + q.length;
    }

    return (
      <>
        {parts.map((p, idx) =>
          p.m ? (
            <span
              key={idx}
              className="rounded-sm bg-primary/15 text-primary font-semibold px-0.5"
            >
              {p.t}
            </span>
          ) : (
            <span key={idx}>{p.t}</span>
          )
        )}
      </>
    );
  };

  // Keep local input in sync if parent resets filters externally
  useEffect(() => {
    setSearchValue(activeFilters.search);
  }, [activeFilters.search]);

  const activeFilterCount = [
    activeFilters.category !== "Tümü",
    activeFilters.language !== "Tümü",
    activeFilters.availableOnly,
  ].filter(Boolean).length;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchValue);
  };

  const clearAllFilters = () => {
    setSearchValue("");
    onSearch("");
    onCategoryChange("Tümü");
    onLanguageChange("Tümü");
    onSortChange("title-asc");
    onAvailableOnlyChange(false);
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <form onSubmit={handleSearchSubmit} className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Kitap adı, yazar veya ISBN ile arayın..."
          value={searchValue}
          onChange={(e) => {
            const v = e.target.value;
            setSearchValue(v);
            // "Yazdıkça arama" (liste, aşağıda dinamik güncellenir)
            onSearch(v);
            setIsSuggestOpen(!!v.trim());
            setActiveIdx(-1);
          }}
          onFocus={() => setIsSuggestOpen(!!searchValue.trim())}
          onBlur={() => {
            // Allow click on suggestions before closing
            setTimeout(() => setIsSuggestOpen(false), 120);
          }}
          onKeyDown={(e) => {
            if (!isSuggestOpen || suggestions.length === 0) return;
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActiveIdx((p) => Math.min(p + 1, suggestions.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActiveIdx((p) => Math.max(p - 1, 0));
            } else if (e.key === "Enter") {
              if (activeIdx >= 0 && activeIdx < suggestions.length) {
                e.preventDefault();
                onSelectSuggestion?.(suggestions[activeIdx].id);
                setIsSuggestOpen(false);
              }
            } else if (e.key === "Escape") {
              setIsSuggestOpen(false);
            }
          }}
          className="pl-12 pr-4 h-12 rounded-xl border-2 focus:border-primary"
          aria-label="Kitap ara"
        />
        {isSearching && !!searchValue.trim() && (
          <div className="absolute right-10 top-1/2 -translate-y-1/2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
          </div>
        )}
        {searchValue && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
            onClick={() => {
              setSearchValue("");
              onSearch("");
              setIsSuggestOpen(false);
              setActiveIdx(-1);
            }}
            aria-label="Aramayı temizle"
          >
            <X className="h-4 w-4" />
          </Button>
        )}

        {/* Typeahead suggestions */}
        {isSuggestOpen && !!searchValue.trim() && suggestions.length > 0 && (
          <div className="absolute left-0 right-0 mt-2 rounded-xl border border-border bg-card shadow-xl overflow-hidden z-40">
            <div className="max-h-80 overflow-y-auto">
              {suggestions.map((s, idx) => (
                <button
                  key={s.id}
                  type="button"
                  className={
                    "w-full text-left px-4 py-3 border-b border-border last:border-0 transition-colors " +
                    (idx === activeIdx ? "bg-primary/10" : "hover:bg-muted/50")
                  }
                  onMouseEnter={() => setActiveIdx(idx)}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => {
                    onSelectSuggestion?.(s.id);
                    setIsSuggestOpen(false);
                  }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">
                        {renderHighlight(s.title, searchValue)}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        {renderHighlight(s.author, searchValue)} •{" "}
                        <span className="font-mono">{renderHighlight(s.isbn, searchValue)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {typeof s.available_copies === "number" && (
                        <span className={"text-xs font-medium " + (s.available_copies > 0 ? "text-success" : "text-destructive")}>
                          {s.available_copies > 0 ? `${s.available_copies} Mevcut` : "Tükendi"}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
            <div className="px-4 py-2 text-xs text-muted-foreground bg-muted/30">
              ↑↓ ile gez, Enter ile aç, Esc ile kapat
            </div>
          </div>
        )}
      </form>

      {/* Filters Row */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Category Select */}
        <Select value={activeFilters.category} onValueChange={onCategoryChange}>
          <SelectTrigger className="w-[180px] h-10">
            <SelectValue placeholder="Kategori" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Language Select */}
        <Select value={activeFilters.language} onValueChange={onLanguageChange}>
          <SelectTrigger className="w-[140px] h-10">
            <SelectValue placeholder="Dil" />
          </SelectTrigger>
          <SelectContent>
            {languages.map((lang) => (
              <SelectItem key={lang} value={lang}>
                {lang}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Sort Select */}
        <Select value={activeFilters.sort} onValueChange={onSortChange}>
          <SelectTrigger className="w-[160px] h-10">
            <SelectValue placeholder="Sırala" />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Advanced Filters Popover */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="h-10 gap-2">
              <SlidersHorizontal className="h-4 w-4" />
              Filtreler
              {activeFilterCount > 0 && (
                <Badge variant="default" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-72">
            <div className="space-y-4">
              <h4 className="font-medium">Gelişmiş Filtreler</h4>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={activeFilters.availableOnly}
                  onChange={(e) => onAvailableOnlyChange(e.target.checked)}
                  className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
                />
                <span className="text-sm">Sadece mevcut kitaplar</span>
              </label>

              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={clearAllFilters}
              >
                Tüm Filtreleri Temizle
              </Button>
            </div>
          </PopoverContent>
        </Popover>

        {/* Clear All Button */}
        {(activeFilters.search || activeFilterCount > 0) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAllFilters}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4 mr-1" />
            Temizle
          </Button>
        )}
      </div>

      {/* Active Filters Display */}
      {(activeFilters.search || activeFilterCount > 0) && (
        <div className="flex flex-wrap gap-2">
          {activeFilters.search && (
            <Badge variant="secondary" className="gap-1">
              Arama: "{activeFilters.search}"
              <button
                onClick={() => {
                  setSearchValue("");
                  onSearch("");
                }}
                className="ml-1 hover:text-destructive"
                aria-label="Arama filtresini kaldır"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          {activeFilters.category !== "Tümü" && (
            <Badge variant="secondary" className="gap-1">
              {activeFilters.category}
              <button
                onClick={() => onCategoryChange("Tümü")}
                className="ml-1 hover:text-destructive"
                aria-label="Kategori filtresini kaldır"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          {activeFilters.language !== "Tümü" && (
            <Badge variant="secondary" className="gap-1">
              {activeFilters.language}
              <button
                onClick={() => onLanguageChange("Tümü")}
                className="ml-1 hover:text-destructive"
                aria-label="Dil filtresini kaldır"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          {activeFilters.availableOnly && (
            <Badge variant="secondary" className="gap-1">
              Sadece mevcut
              <button
                onClick={() => onAvailableOnlyChange(false)}
                className="ml-1 hover:text-destructive"
                aria-label="Mevcut filtresi kaldır"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}
