import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { BookOpen, ChevronRight, MapPin } from "lucide-react";
import { useEffect, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { Book } from "@/data/mockData";
import { useBorrowRequestAction } from "@/hooks/useBorrowRequestAction";

interface BookListItemProps {
  book: Book;
  index?: number;
  /** If true, this book already has a pending borrow request for the current user */
  isBorrowRequested?: boolean;
  /** If true, this book is already in user's active loans */
  hasActiveLoan?: boolean;
}

export function BookListItem({ book, index = 0, isBorrowRequested, hasActiveLoan }: BookListItemProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const isAvailable = book.availableCopies > 0;

  const { borrowLoading, requested, requestBorrow, setRequested } = useBorrowRequestAction({
    bookId: book.id,
    bookTitle: book.title,
    isAvailable,
  });

  useEffect(() => {
    if (isBorrowRequested) setRequested(true);
  }, [isBorrowRequested, setRequested]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03, duration: 0.25 }}
      className="group bg-card rounded-2xl border border-border shadow-card hover:shadow-lg hover:border-primary/20 transition-all hover:-translate-y-0.5"
    >
      <div className="p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-5">
          {/* Cover */}
          <Link to={`/books/${book.id}`} className="flex-shrink-0">
            <div className="relative w-full sm:w-28 h-40 sm:h-40 rounded-xl overflow-hidden bg-muted">
              {!imageLoaded && !imageError && (
                <div className="absolute inset-0 skeleton-shimmer" />
              )}
              <img
                src={imageError ? "/placeholder.svg" : book.coverImage}
                alt={book.title}
                loading="lazy"
                onLoad={() => setImageLoaded(true)}
                onError={() => setImageError(true)}
                className={cn(
                  "w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]",
                  !imageLoaded && "opacity-0"
                )}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 via-transparent to-transparent" />
              <div className="absolute top-2 right-2">
                <Badge
                  variant={isAvailable ? "default" : "destructive"}
                  className={cn("shadow-md", isAvailable && "bg-success hover:bg-success/90")}
                >
                  {isAvailable ? `${book.availableCopies} Mevcut` : "Tükendi"}
                </Badge>
              </div>
            </div>
          </Link>

          {/* Content */}
          <div className="flex-1 min-w-0 flex flex-col">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <Link to={`/books/${book.id}`} className="block">
                  <h3 className="font-display font-semibold text-base sm:text-lg leading-snug line-clamp-2 group-hover:text-primary transition-colors">
                    {book.title}
                  </h3>
                </Link>
                <p className="text-sm text-muted-foreground line-clamp-1">{book.author}</p>
              </div>
              <div className="hidden sm:flex items-center gap-2">
                <Badge variant="secondary" className="flex-shrink-0">
                  {book.category}
                </Badge>
                {book.deweyCode && (
                  <Badge variant="outline" className="flex-shrink-0 bg-blue-50/50 text-blue-600 border-blue-200">
                    DDC: {book.deweyCode}
                  </Badge>
                )}
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span className="rounded-full bg-muted/50 px-2 py-1">ISBN: {book.isbn}</span>
              <span className="rounded-full bg-muted/50 px-2 py-1">{book.language}</span>
              <span className="rounded-full bg-muted/50 px-2 py-1">{book.pages} syf</span>
              <span className="rounded-full bg-muted/50 px-2 py-1">{book.publishYear}</span>
            </div>

            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span className="truncate">{book.location}</span>
            </div>

            {book.description && (
              <p className="mt-3 text-sm text-muted-foreground line-clamp-2">
                {book.description}
              </p>
            )}

            {/* Actions */}
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
              <Button
                variant={requested || !!hasActiveLoan || !isAvailable ? "secondary" : "hero"}
                size="sm"
                className="sm:w-44 justify-center"
                onClick={requestBorrow}
                disabled={borrowLoading || requested || !!hasActiveLoan || !isAvailable}
                title={
                  requested
                    ? "Talebiniz alındı. Yönetici onayı bekleniyor."
                    : hasActiveLoan
                      ? "Bu kitap zaten aktif ödünçlerinizde."
                      : undefined
                }
              >
                <BookOpen className="h-4 w-4" />
                {requested ? "Talebiniz Alındı" : hasActiveLoan ? "Aktif Ödünç" : isAvailable ? "Ödünç Al" : "Ödünç Verildi"}
              </Button>

              <Link to={`/books/${book.id}`} className="sm:ml-auto">
                <Button variant="ghost" size="sm" className="gap-1">
                  Detaylar <ChevronRight className="h-4 w-4" />
                </Button>
              </Link>

              <div className="sm:hidden flex items-center gap-2">
                <Badge variant="secondary">{book.category}</Badge>
                {book.deweyCode && (
                  <Badge variant="outline" className="bg-blue-50/50 text-blue-600 border-blue-200">
                    DDC: {book.deweyCode}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}


