import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Star, MapPin, BookOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Book } from "@/data/mockData";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import { eventsAPI, getToken } from "@/lib/api";
import { useBorrowRequestAction } from "@/hooks/useBorrowRequestAction";

interface BookCardProps {
  book: Book;
  index?: number;
  /** If true, this book already has a pending borrow request for the current user */
  isBorrowRequested?: boolean;
  /** If true, this book is already in user's active loans */
  hasActiveLoan?: boolean;
}

export function BookCard({ book, index = 0, isBorrowRequested, hasActiveLoan }: BookCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  
  const isAvailable = book.availableCopies > 0;

  const { borrowLoading, requested, requestBorrow, setRequested } = useBorrowRequestAction({
    bookId: book.id,
    bookTitle: book.title,
    isAvailable,
  });

  // Sync from parent (server-known pending state)
  useEffect(() => {
    if (isBorrowRequested) setRequested(true);
  }, [isBorrowRequested, setRequested]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
      className="group bg-card rounded-xl overflow-hidden shadow-card border border-border hover:shadow-lg hover:border-primary/20 transition-all duration-300"
    >
      <Link
        to={`/books/${book.id}`}
        className="block"
        onClick={() => {
          // If this card is shown inside recommendations section, we still log it as a valuable signal.
          const token = getToken();
          if (!token) return;
          eventsAPI.trackRecommendationClick(book.id).catch(() => {});
        }}
      >
        <div className="relative aspect-[3/4] overflow-hidden bg-muted">
          {!imageLoaded && !imageError && (
            <div className="absolute inset-0 animate-pulse bg-muted" />
          )}
          <img
            src={imageError ? "/placeholder.svg" : book.coverImage}
            alt={book.title}
            loading="lazy"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
            className={cn(
              "w-full h-full object-cover transition-all duration-500 group-hover:scale-105",
              !imageLoaded && "opacity-0"
            )}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          
          {/* Availability Badge */}
          <div className="absolute top-3 right-3">
            <Badge
              variant={isAvailable ? "default" : "destructive"}
              className={cn(
                "shadow-md",
                isAvailable && "bg-success hover:bg-success/90"
              )}
            >
              {isAvailable ? `${book.availableCopies} Mevcut` : "Tükendi"}
            </Badge>
          </div>

          {/* Quick Action - appears on hover */}
          <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
            <Button
              variant="hero"
              size="sm"
              className="w-full"
              onClick={requestBorrow}
              disabled={borrowLoading || requested || !!hasActiveLoan || !isAvailable}
              title={
                requested
                  ? "Talebiniz alındı. Yönetici onayı bekleniyor."
                  : hasActiveLoan
                    ? "Bu kitap zaten aktif ödünçlerinizde."
                  : !isAvailable
                    ? "Bu kitap şu an ödünç verilmiş durumda."
                    : undefined
              }
            >
              <BookOpen className="h-4 w-4" />
              {requested ? "Talebiniz Alındı" : hasActiveLoan ? "Aktif Ödünç" : isAvailable ? "Ödünç Al" : "Ödünç Verildi"}
            </Button>
          </div>
        </div>
      </Link>

      <div className="p-4 space-y-2">
        <Link to={`/books/${book.id}`}>
          <h3 className="font-display font-semibold text-sm line-clamp-2 group-hover:text-primary transition-colors">
            {book.title}
          </h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-1">{book.author}</p>

        <div className="flex items-center justify-between pt-2">
          <Badge variant="secondary" className="text-xs">
            {book.category}
          </Badge>
          {book.deweyCode && (
            <Badge variant="outline" className="text-xs ml-1 bg-blue-50/50 text-blue-600 border-blue-200">
              DDC: {book.deweyCode}
            </Badge>
          )}
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-warning text-warning" />
            <span className="font-medium">{book.rating}</span>
            <span>({book.reviewCount})</span>
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs text-muted-foreground pt-1">
          <MapPin className="h-3 w-3" />
          <span>{book.location}</span>
        </div>
      </div>
    </motion.div>
  );
}
