import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BookCard } from "./BookCard";
import { BookListItem } from "./BookListItem";
import { BooksFilter } from "./BooksFilter";
import { BookCardSkeleton } from "@/components/shared/SkeletonCard";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, LayoutGrid, List, Loader2 } from "lucide-react";
import { booksAPI, borrowRequestsAPI, eventsAPI, getToken, loansAPI } from "@/lib/api";
import { cn } from "@/lib/utils";
import { RECO_INVALIDATE_KEY } from "@/lib/recommendationsBus";

const ITEMS_PER_PAGE = 8;

interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publisher?: string;
  publish_year?: number;
  language: string;
  category?: string;
  pages?: number;
  total_copies: number;
  available_copies: number;
  location?: string;
  description?: string;
  cover_image?: string;
  dewey_code?: string;
  borrow_count: number;
}

export function BooksList() {
  const navigate = useNavigate();
  const [books, setBooks] = useState<Book[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [pendingBorrowBookIds, setPendingBorrowBookIds] = useState<Set<string>>(new Set());
  const [activeLoanBookIds, setActiveLoanBookIds] = useState<Set<string>>(new Set());
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    search: "",
    category: "Tümü",
    language: "Tümü",
    sort: "title-asc",
    availableOnly: false,
  });

  useEffect(() => {
    const controller = new AbortController();
    const t = setTimeout(async () => {
      setIsLoading(true);
      try {
        const params: Record<string, string | boolean> = {};
        const q = (filters.search || "").trim();
        if (q) params.search = q;
        if (filters.category !== "Tümü") params.category = filters.category;
        if (filters.availableOnly) params.available_only = true;

        const data = await booksAPI.getAll(params, { signal: controller.signal });
        setBooks(data);
      } catch (error: unknown) {
        // Abort/cancel is expected during fast typing
        const maybeCancel = error as { code?: string; name?: string };
        if (maybeCancel?.code === "ERR_CANCELED" || maybeCancel?.name === "CanceledError") return;
        console.error("Error fetching books:", error);
      } finally {
        setIsLoading(false);
      }
    }, 250); // debounce for "yazdıkça arama"

    return () => {
      clearTimeout(t);
      controller.abort();
    };
  }, [filters.search, filters.category, filters.availableOnly]);

  // Pending borrow requests (to show "Talebiniz alındı" instead of "Ödünç Al")
  useEffect(() => {
    const token = getToken();
    if (!token) {
      setPendingBorrowBookIds(new Set());
      return;
    }

    let cancelled = false;
    const loadPending = async () => {
      try {
        const [pending, myLoans] = await Promise.all([
          borrowRequestsAPI.getMine({ status: "pending" }),
          loansAPI.getMyLoans(),
        ]);
        if (cancelled) return;
        const s = new Set<string>();
        (pending || []).forEach((r: any) => {
          if (r?.book_id) s.add(String(r.book_id));
        });
        setPendingBorrowBookIds(s);
        const a = new Set<string>();
        (myLoans || []).forEach((l: any) => {
          if (l?.book_id) a.add(String(l.book_id));
        });
        setActiveLoanBookIds(a);
      } catch {
        if (!cancelled) {
          setPendingBorrowBookIds(new Set());
          setActiveLoanBookIds(new Set());
        }
      }
    };

    loadPending();
    // Fallback polling: yalnızca login varsa; WS push ile anlık güncelleme var; bu sadece güvenlik ağı.
    const interval = token ? setInterval(loadPending, 60000) : null;
    const onInvalidate = () => loadPending();
    window.addEventListener("reco:invalidate", onInvalidate as EventListener);
    const onStorage = (e: StorageEvent) => {
      if (e.key === RECO_INVALIDATE_KEY) loadPending();
    };
    window.addEventListener("storage", onStorage);
    return () => {
      cancelled = true;
      if (interval) clearInterval(interval);
      window.removeEventListener("reco:invalidate", onInvalidate as EventListener);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  // Track search events (debounced) for personalization
  useEffect(() => {
    const token = getToken();
    if (!token) return;
    const q = (filters.search || "").trim();
    if (!q) return;

    const t = setTimeout(() => {
      eventsAPI.trackSearch(q).catch(() => {
        // ignore
      });
    }, 700);
    return () => clearTimeout(t);
  }, [filters.search]);

  // Filter and sort books locally
  const filteredBooks = [...books]
    .filter((book) => {
      if (filters.language !== "Tümü" && book.language !== filters.language) return false;
      return true;
    })
    .sort((a, b) => {
      switch (filters.sort) {
        case "title-asc":
          return a.title.localeCompare(b.title);
        case "title-desc":
          return b.title.localeCompare(a.title);
        case "year-desc":
          return (b.publish_year || 0) - (a.publish_year || 0);
        case "year-asc":
          return (a.publish_year || 0) - (b.publish_year || 0);
        default:
          return 0;
      }
    });

  // Pagination
  const totalPages = Math.ceil(filteredBooks.length / ITEMS_PER_PAGE);
  const paginatedBooks = filteredBooks.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleFilterChange = (key: keyof typeof filters, value: string | boolean) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const suggestions = (() => {
    const q = (filters.search || "").trim();
    if (!q) return [];
    // Use currently loaded results (already fetched with search param)
    return filteredBooks.slice(0, 5).map((b) => ({
      id: b.id,
      title: b.title,
      author: b.author,
      isbn: b.isbn,
      category: b.category,
      available_copies: b.available_copies,
    }));
  })();

  // Map to BookCard format
  const mapBookToCardFormat = (book: Book) => ({
    id: book.id,
    title: book.title,
    author: book.author,
    isbn: book.isbn,
    category: book.category || "Genel",
    deweyCode: book.dewey_code,
    language: book.language,
    publishYear: book.publish_year || 2020,
    totalCopies: book.total_copies,
    availableCopies: book.available_copies,
    coverImage: book.cover_image || `https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=200&h=300&fit=crop`,
    rating: 4.5,
    pages: book.pages || 200,
    location: book.location || "A-001",
    description: book.description || "",
  });

  return (
    <div className="space-y-6">
      {/* Filters */}
      <BooksFilter
        activeFilters={filters}
        onSearch={(query) => handleFilterChange("search", query)}
        suggestions={suggestions}
        onSelectSuggestion={(bookId) => navigate(`/books/${bookId}`)}
        onCategoryChange={(cat) => handleFilterChange("category", cat)}
        onLanguageChange={(lang) => handleFilterChange("language", lang)}
        onSortChange={(sort) => handleFilterChange("sort", sort)}
        onAvailableOnlyChange={(available) => handleFilterChange("availableOnly", available)}
        isSearching={isLoading && !!(filters.search || "").trim()}
      />

      {/* Results Header */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          <span className="font-medium text-foreground">{filteredBooks.length}</span> kitap bulundu
        </p>
        <div className="flex items-center gap-1 border border-border rounded-lg p-1">
          <Button
            variant={viewMode === "grid" ? "default" : "ghost"}
            size="icon"
            className="h-8 w-8"
            onClick={() => setViewMode("grid")}
            aria-label="Grid görünümü"
            aria-pressed={viewMode === "grid"}
          >
            <LayoutGrid className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === "list" ? "default" : "ghost"}
            size="icon"
            className="h-8 w-8"
            onClick={() => setViewMode("list")}
            aria-label="Liste görünümü"
            aria-pressed={viewMode === "list"}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Books Grid/List */}
      {isLoading ? (
        viewMode === "grid" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <BookCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <BookCardSkeleton key={i} />
            ))}
          </div>
        )
      ) : paginatedBooks.length > 0 ? (
        viewMode === "grid" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {paginatedBooks.map((book, index) => (
              <BookCard
                key={book.id}
                book={mapBookToCardFormat(book)}
                index={index}
                isBorrowRequested={pendingBorrowBookIds.has(String(book.id))}
                hasActiveLoan={activeLoanBookIds.has(String(book.id))}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {paginatedBooks.map((book, index) => (
              <BookListItem
                key={book.id}
                book={mapBookToCardFormat(book)}
                index={index}
                isBorrowRequested={pendingBorrowBookIds.has(String(book.id))}
                hasActiveLoan={activeLoanBookIds.has(String(book.id))}
              />
            ))}
          </div>
        )
      ) : (
        <div className="text-center py-16">
          <div className="text-6xl mb-4">📚</div>
          <h3 className="text-lg font-semibold mb-2">Kitap Bulunamadı</h3>
          <p className="text-muted-foreground">
            Arama kriterlerinize uygun kitap bulunamadı. Filtreleri değiştirmeyi deneyin.
          </p>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-6">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            aria-label="Önceki sayfa"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <div className="flex items-center gap-1">
            {Array.from({ length: Math.min(totalPages, 5) }).map((_, i) => (
              <Button
                key={i}
                variant={currentPage === i + 1 ? "default" : "ghost"}
                size="icon"
                className="h-9 w-9"
                onClick={() => setCurrentPage(i + 1)}
                aria-label={`Sayfa ${i + 1}`}
                aria-current={currentPage === i + 1 ? "page" : undefined}
              >
                {i + 1}
              </Button>
            ))}
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            aria-label="Sonraki sayfa"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}
