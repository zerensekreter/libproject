import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  Building,
  CreditCard,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { authAPI, setToken, setUser } from "@/lib/api";

const loginSchema = z.object({
  email: z.string().email("Geçerli bir e-posta adresi giriniz"),
  password: z.string().min(8, "Şifre en az 8 karakter olmalı"),
});

const registerSchema = z.object({
  name: z.string()
    .min(2, "Ad en az 2 karakter olmalı")
    .max(100, "Ad en fazla 100 karakter olmalı")
    .regex(/^[^<>"']*$/, "İsim geçersiz karakterler içeriyor"),
  email: z.string().email("Geçerli bir e-posta adresi giriniz"),
  studentId: z.string()
    .min(5, "Öğrenci numarası en az 5 karakter olmalı")
    .max(20, "Öğrenci numarası en fazla 20 karakter olmalı")
    .regex(/^[a-zA-Z0-9]+$/, "Öğrenci numarası sadece harf ve rakam içerebilir"),
  department: z.string().min(1, "Bölüm seçiniz"),
  gradeLevel: z.string().min(1, "Sınıf seçiniz"),
  password: z.string()
    .min(8, "Şifre en az 8 karakter olmalı")
    .max(128, "Şifre çok uzun")
    .regex(/[A-Z]/, "Şifre en az bir büyük harf içermeli")
    .regex(/[a-z]/, "Şifre en az bir küçük harf içermeli")
    .regex(/[0-9]/, "Şifre en az bir rakam içermeli"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Şifreler eşleşmiyor",
  path: ["confirmPassword"],
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

const departments = [
  "Bankacılık ve Sigortacılık",
  "Bilişim Sistemleri ve Teknolojileri",
  "Gümrük İşletme",
  "Halkla İlişkiler ve Reklamcılık",
  "Uluslararası Ticaret ve Finansman",
  "Yönetim Bilişim Sistemleri",
];

const gradeLevels = [
  { value: "1", label: "1. Sınıf" },
  { value: "2", label: "2. Sınıf" },
  { value: "3", label: "3. Sınıf" },
  { value: "4", label: "4. Sınıf" },
];

export function AuthForm() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
  });

  const onLogin = async (data: LoginFormData) => {
    setIsLoading(true);
    try {
      const response = await authAPI.login(data.email, data.password);
      setToken(response.access_token);

      // Get user info
      const user = await authAPI.getMe();
      setUser(user);

      toast.success("Giriş Başarılı", {
        description: user.role === "admin" ? "Admin paneline yönlendiriliyorsunuz..." : "Ana sayfaya yönlendiriliyorsunuz...",
      });

      // Redirect admin users to admin panel
      setTimeout(() => navigate(user.role === "admin" ? "/admin" : "/"), 1000);
    } catch (error: any) {
      toast.error("Giriş Başarısız", {
        description: error.response?.data?.detail || "E-posta veya şifre hatalı",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onRegister = async (data: RegisterFormData) => {
    setIsLoading(true);
    try {
      await authAPI.register({
        email: data.email,
        password: data.password,
        student_id: data.studentId,
        full_name: data.name,
        department: `${data.department} - ${data.gradeLevel}. Sınıf`,
      });

      toast.success("Kayıt Başarılı", {
        description: "Şimdi giriş yapabilirsiniz.",
      });

      setMode("login");
      loginForm.setValue("email", data.email);
    } catch (error: any) {
      toast.error("Kayıt Başarısız", {
        description: error.response?.data?.detail || "Bir hata oluştu",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Mode Toggle */}
      <div className="flex p-1 bg-muted rounded-xl mb-8">
        <button
          onClick={() => setMode("login")}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${mode === "login"
            ? "bg-card shadow-sm text-foreground"
            : "text-muted-foreground hover:text-foreground"
            }`}
        >
          Giriş Yap
        </button>
        <button
          onClick={() => setMode("register")}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${mode === "register"
            ? "bg-card shadow-sm text-foreground"
            : "text-muted-foreground hover:text-foreground"
            }`}
        >
          Kayıt Ol
        </button>
      </div>

      <AnimatePresence mode="wait">
        {mode === "login" ? (
          <motion.form
            key="login"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.2 }}
            onSubmit={loginForm.handleSubmit(onLogin)}
            className="space-y-5"
          >
            <div className="space-y-2">
              <Label htmlFor="login-email">E-posta</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="login-email"
                  type="email"
                  placeholder="ornek@university.edu.tr"
                  className="pl-10"
                  {...loginForm.register("email")}
                />
              </div>
              {loginForm.formState.errors.email && (
                <p className="text-xs text-destructive">
                  {loginForm.formState.errors.email.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="login-password">Şifre</Label>
                <a href="#" className="text-xs text-primary hover:underline">
                  Şifremi Unuttum
                </a>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="login-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="pl-10 pr-10"
                  {...loginForm.register("password")}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Şifreyi gizle" : "Şifreyi göster"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {loginForm.formState.errors.password && (
                <p className="text-xs text-destructive">
                  {loginForm.formState.errors.password.message}
                </p>
              )}
            </div>

            <Button type="submit" variant="hero" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  Giriş Yap
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </motion.form>
        ) : (
          <motion.form
            key="register"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            onSubmit={registerForm.handleSubmit(onRegister)}
            className="space-y-5"
          >
            <div className="space-y-2">
              <Label htmlFor="register-name">Ad Soyad</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="register-name"
                  placeholder="Adınız Soyadınız"
                  className="pl-10"
                  {...registerForm.register("name")}
                />
              </div>
              {registerForm.formState.errors.name && (
                <p className="text-xs text-destructive">
                  {registerForm.formState.errors.name.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="register-email">E-posta</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="register-email"
                  type="email"
                  placeholder="ornek@university.edu.tr"
                  className="pl-10"
                  {...registerForm.register("email")}
                />
              </div>
              {registerForm.formState.errors.email && (
                <p className="text-xs text-destructive">
                  {registerForm.formState.errors.email.message}
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="register-studentId">Öğrenci No</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="register-studentId"
                    placeholder="2024010001"
                    className="pl-10"
                    {...registerForm.register("studentId")}
                  />
                </div>
                {registerForm.formState.errors.studentId && (
                  <p className="text-xs text-destructive">
                    {registerForm.formState.errors.studentId.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="register-gradeLevel">Sınıf</Label>
                <Select onValueChange={(value) => registerForm.setValue("gradeLevel", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seçiniz" />
                  </SelectTrigger>
                  <SelectContent>
                    {gradeLevels.map((grade) => (
                      <SelectItem key={grade.value} value={grade.value}>
                        {grade.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {registerForm.formState.errors.gradeLevel && (
                  <p className="text-xs text-destructive">
                    {registerForm.formState.errors.gradeLevel.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="register-department">Bölüm</Label>
              <Select onValueChange={(value) => registerForm.setValue("department", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Bölüm Seçiniz" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {registerForm.formState.errors.department && (
                <p className="text-xs text-destructive">
                  {registerForm.formState.errors.department.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="register-password">Şifre</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="register-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="pl-10 pr-10"
                  {...registerForm.register("password")}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Şifreyi gizle" : "Şifreyi göster"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {registerForm.formState.errors.password && (
                <p className="text-xs text-destructive">
                  {registerForm.formState.errors.password.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="register-confirmPassword">Şifre Tekrar</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="register-confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  className="pl-10"
                  {...registerForm.register("confirmPassword")}
                />
              </div>
              {registerForm.formState.errors.confirmPassword && (
                <p className="text-xs text-destructive">
                  {registerForm.formState.errors.confirmPassword.message}
                </p>
              )}
            </div>

            <Button type="submit" variant="hero" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  Kayıt Ol
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </motion.form>
        )}
      </AnimatePresence>

      <p className="text-xs text-center text-muted-foreground mt-6">
        Devam ederek{" "}
        <a href="#" className="text-primary hover:underline">
          Kullanım Koşulları
        </a>{" "}
        ve{" "}
        <a href="#" className="text-primary hover:underline">
          Gizlilik Politikası
        </a>
        'nı kabul etmiş olursunuz.
      </p>
    </div>
  );
}
