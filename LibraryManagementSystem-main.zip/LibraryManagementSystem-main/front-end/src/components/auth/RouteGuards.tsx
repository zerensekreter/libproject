import { useEffect, useMemo, useState } from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { authAPI, getToken, getUser, removeToken, setUser } from "@/lib/api";
import { Loader2 } from "lucide-react";

type AuthStatus = "checking" | "guest" | "authed";

function useAuth() {
  const location = useLocation();
  const [status, setStatus] = useState<AuthStatus>("checking");
  const [role, setRole] = useState<string | null>(null);

  const token = useMemo(() => getToken(), []);

  useEffect(() => {
    if (!token) {
      setStatus("guest");
      setRole(null);
      return;
    }

    const cached = getUser();
    if (cached?.role) {
      setStatus("authed");
      setRole(cached.role);
      return;
    }

    (async () => {
      try {
        const me = await authAPI.getMe();
        setUser(me);
        setStatus("authed");
        setRole(me.role ?? null);
      } catch {
        // Token expired/invalid
        removeToken();
        setStatus("guest");
        setRole(null);
      }
    })();
  }, [token, location.key]);

  return { status, role };
}

export function RequireAuth() {
  const location = useLocation();
  const { status } = useAuth();

  if (status === "checking") {
    return (
      <div className="min-h-[60vh] flex items-center justify-center text-muted-foreground gap-2">
        <Loader2 className="h-4 w-4 animate-spin" />
        Yükleniyor...
      </div>
    );
  }
  if (status === "guest") return <Navigate to="/auth" replace state={{ from: location.pathname }} />;
  return <Outlet />;
}

export function RequireAdmin() {
  const { status, role } = useAuth();

  if (status === "checking") {
    return (
      <div className="min-h-[60vh] flex items-center justify-center text-muted-foreground gap-2">
        <Loader2 className="h-4 w-4 animate-spin" />
        Yükleniyor...
      </div>
    );
  }
  if (status === "guest") return <Navigate to="/auth" replace />;
  if (role !== "admin") return <Navigate to="/" replace />;
  return <Outlet />;
}


