import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Server,
  Database,
  Wifi,
  HardDrive,
  Cpu,
  MemoryStick,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface HealthMetric {
  name: string;
  icon: typeof Server;
  status: "healthy" | "warning" | "critical";
  value: number;
  unit: string;
  description: string;
}

const statusStyles = {
  healthy: {
    color: "text-success",
    bg: "bg-success/10",
    icon: CheckCircle2,
    label: "Sağlıklı",
  },
  warning: {
    color: "text-warning",
    bg: "bg-warning/10",
    icon: AlertTriangle,
    label: "Uyarı",
  },
  critical: {
    color: "text-destructive",
    bg: "bg-destructive/10",
    icon: XCircle,
    label: "Kritik",
  },
};

export function ServerHealthWidget() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [metrics, setMetrics] = useState<HealthMetric[]>([
    {
      name: "API Sunucusu",
      icon: Server,
      status: "healthy",
      value: 99.9,
      unit: "% uptime",
      description: "Son 30 gün",
    },
    {
      name: "Veritabanı",
      icon: Database,
      status: "healthy",
      value: 45,
      unit: "ms",
      description: "Ortalama yanıt süresi",
    },
    {
      name: "Ağ Bağlantısı",
      icon: Wifi,
      status: "healthy",
      value: 100,
      unit: "Mbps",
      description: "Bant genişliği",
    },
    {
      name: "Disk Kullanımı",
      icon: HardDrive,
      status: "warning",
      value: 78,
      unit: "%",
      description: "234 GB / 300 GB",
    },
    {
      name: "CPU Kullanımı",
      icon: Cpu,
      status: "healthy",
      value: 32,
      unit: "%",
      description: "8 çekirdek",
    },
    {
      name: "Bellek",
      icon: MemoryStick,
      status: "healthy",
      value: 65,
      unit: "%",
      description: "10.4 GB / 16 GB",
    },
  ]);

  const overallStatus = metrics.some((m) => m.status === "critical")
    ? "critical"
    : metrics.some((m) => m.status === "warning")
    ? "warning"
    : "healthy";

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setLastUpdated(new Date());
    setIsRefreshing(false);
  };

  const getProgressColor = (status: HealthMetric["status"]) => {
    switch (status) {
      case "healthy":
        return "bg-success";
      case "warning":
        return "bg-warning";
      case "critical":
        return "bg-destructive";
    }
  };

  const OverallStatusIcon = statusStyles[overallStatus].icon;

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={cn("p-2 rounded-lg", statusStyles[overallStatus].bg)}>
            <Server className={cn("h-5 w-5", statusStyles[overallStatus].color)} />
          </div>
          <div>
            <h3 className="font-display font-semibold">Sunucu Durumu</h3>
            <div className="flex items-center gap-2 text-sm">
              <OverallStatusIcon className={cn("h-4 w-4", statusStyles[overallStatus].color)} />
              <span className={statusStyles[overallStatus].color}>
                {statusStyles[overallStatus].label}
              </span>
            </div>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleRefresh}
          disabled={isRefreshing}
          aria-label="Yenile"
        >
          <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
        </Button>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((metric, index) => {
          const MetricIcon = metric.icon;
          const StatusIcon = statusStyles[metric.status].icon;
          
          return (
            <motion.div
              key={metric.name}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className={cn(
                "p-4 rounded-lg border transition-colors",
                metric.status === "critical"
                  ? "border-destructive/50 bg-destructive/5"
                  : metric.status === "warning"
                  ? "border-warning/50 bg-warning/5"
                  : "border-border bg-muted/30"
              )}
            >
              <div className="flex items-center justify-between mb-3">
                <MetricIcon className="h-4 w-4 text-muted-foreground" />
                <StatusIcon className={cn("h-4 w-4", statusStyles[metric.status].color)} />
              </div>
              <p className="text-sm font-medium mb-1">{metric.name}</p>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-xl font-bold">{metric.value}</span>
                <span className="text-sm text-muted-foreground">{metric.unit}</span>
              </div>
              {metric.unit === "%" && (
                <div className="relative h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${metric.value}%` }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className={cn("absolute h-full rounded-full", getProgressColor(metric.status))}
                  />
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-2">{metric.description}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border">
        <span>Son güncelleme: {lastUpdated.toLocaleTimeString("tr-TR")}</span>
        <span>Otomatik yenileme: 60s</span>
      </div>
    </div>
  );
}
