import { Dispatch, SetStateAction, useEffect, useRef } from "react";
import { getToken } from "@/lib/api";
import { supportAPI, playNotificationSound } from "@/lib/supportApi";
import { toast } from "sonner";

type Props = {
  /** Current active section in Admin page (e.g. "dashboard", "support") */
  activeSection: string;
  /** Setter for unread count */
  setUnreadCount: Dispatch<SetStateAction<number>>;
};

/**
 * Global admin support notifier:
 * - Keeps a lightweight WebSocket connection while admin is NOT in the support tab.
 * - On new user message: increments unread, plays a sound, and shows a toast.
 *
 * Why:
 * AdminSupportPanel is only mounted when activeSection === "support".
 * Without this notifier, admin won't receive realtime notifications on dashboard.
 */
export function AdminSupportNotifier({ activeSection, setUnreadCount }: Props) {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<number | null>(null);
  const mountedRef = useRef(false);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (reconnectRef.current) {
        window.clearTimeout(reconnectRef.current);
        reconnectRef.current = null;
      }
      if (wsRef.current) {
        wsRef.current.close(1000, "Admin notifier unmount");
        wsRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const token = getToken();
    // Only connect when:
    // - logged in
    // - admin is NOT on the support tab (avoid double WS with AdminSupportPanel)
    if (!token || activeSection === "support") {
      if (wsRef.current) {
        wsRef.current.close(1000, "Support tab active");
        wsRef.current = null;
      }
      return;
    }

    const connect = () => {
      if (!mountedRef.current) return;
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) return;

      const wsUrl = supportAPI.getAdminWebSocketUrl();
      const ws = new WebSocket(wsUrl);

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data?.type === "new_message") {
            // New message from user: best effort local increment (polling will reconcile)
            setUnreadCount((prev) => prev + 1);
            playNotificationSound();
            toast.info("Yeni destek mesajı", {
              description: "Canlı Destek sekmesine giderek yanıtlayabilirsiniz.",
            });
          }
        } catch {
          // ignore malformed payloads
        }
      };

      ws.onclose = (e) => {
        wsRef.current = null;
        if (!mountedRef.current) return;
        // If closed unexpectedly, retry
        if (e.code !== 1000) {
          reconnectRef.current = window.setTimeout(connect, 2500);
        }
      };

      ws.onerror = () => {
        // Let onclose handle reconnect
      };

      wsRef.current = ws;
    };

    connect();
    return () => {
      // keep connection; cleanup happens on tab switch/unmount
    };
    // Intentionally depend on activeSection + token only.
    // unreadCount is handled via props update; see below improvement note.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeSection]);

  return null;
}


