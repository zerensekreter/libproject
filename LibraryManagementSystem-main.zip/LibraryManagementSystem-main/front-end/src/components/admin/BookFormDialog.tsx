import { useState, useEffect } from "react";
import { Loader2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface BookFormDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    book?: any;
}

export function BookFormDialog({ open, onOpenChange, book }: BookFormDialogProps) {
    const [loading, setLoading] = useState(false);
    const [autoFilling, setAutoFilling] = useState(false);
    const [formData, setFormData] = useState({
        isbn: "",
        title: "",
        author: "",
        publisher: "",
        year: new Date().getFullYear().toString(),
        language: "Türkçe",
        category: "",
        pages: "",
        totalCopies: "1",
        location: "",
        summary: "",
        coverUrl: "",
    });

    useEffect(() => {
        if (book) {
            setFormData({
                isbn: book.isbn || "",
                title: book.title || "",
                author: book.author || "",
                publisher: book.publisher || "",
                year: book.publishYear?.toString() || "",
                language: book.language || "Türkçe",
                category: book.category || "",
                pages: book.pages?.toString() || "",
                totalCopies: book.totalCopies?.toString() || "1",
                location: book.location || "",
                summary: book.description || "",
                coverUrl: book.coverImage || "",
            });
        } else {
            setFormData({
                isbn: "",
                title: "",
                author: "",
                publisher: "",
                year: new Date().getFullYear().toString(),
                language: "Türkçe",
                category: "",
                pages: "",
                totalCopies: "1",
                location: "",
                summary: "",
                coverUrl: "",
            });
        }
    }, [book, open]);

    // ISBN ile otomatik kitap bilgisi çekme (Google Books API veya Open Library API)
    const handleIsbnLookup = async () => {
        if (formData.isbn.length < 10) {
            toast.error("Geçerli bir ISBN numarası girin (10 veya 13 rakam)");
            return;
        }

        setAutoFilling(true);
        try {
            // TODO: Backend API'ye istek at veya Google Books API kullan
            // Şimdilik mock veri
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Örnek: Google Books API'den otomatik çekilen bilgiler
            const mockBookData = {
                title: "Clean Code: A Handbook of Agile Software Craftsmanship",
                author: "Robert C. Martin",
                publisher: "Prentice Hall",
                year: "2008",
                language: "İngilizce",
                category: "Bilgisayar Bilimleri",
                pages: "464",
                summary: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees.",
                coverUrl: "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=300&h=400&fit=crop",
            };

            setFormData(prev => ({
                ...prev,
                ...mockBookData
            }));

            toast.success("Kitap bilgileri ISBN'den otomatik dolduruldu!");
        } catch (error) {
            toast.error("ISBN ile kitap bilgisi bulunamadı");
        } finally {
            setAutoFilling(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            // TODO: Backend API'ye kaydet
            await new Promise(resolve => setTimeout(resolve, 1000));

            toast.success(book ? "Kitap güncellendi!" : "Kitap eklendi!");
            onOpenChange(false);
        } catch (error) {
            toast.error("Bir hata oluştu");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>{book ? "Kitap Düzenle" : "Yeni Kitap Ekle"}</DialogTitle>
                    <DialogDescription>
                        ISBN numarası girildiğinde kitap bilgileri otomatik doldurulacak
                    </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleSubmit}>
                    <div className="space-y-4 py-4">
                        {/* ISBN - Otomatik Doldurma */}
                        <div className="space-y-2">
                            <Label htmlFor="isbn">
                                ISBN *
                                {autoFilling && <Loader2 className="inline ml-2 h-3 w-3 animate-spin" />}
                            </Label>
                            <div className="flex gap-2">
                                <Input
                                    id="isbn"
                                    placeholder="978-0-13-468599-1"
                                    value={formData.isbn}
                                    onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                                    disabled={loading || autoFilling}
                                    className="flex-1"
                                    required
                                />
                                <Button
                                    type="button"
                                    variant="secondary"
                                    onClick={handleIsbnLookup}
                                    disabled={loading || autoFilling || formData.isbn.length < 10}
                                    className="gap-2"
                                >
                                    {autoFilling ? (
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                        <Search className="h-4 w-4" />
                                    )}
                                    ISBN Ara
                                </Button>
                            </div>
                            <p className="text-xs text-muted-foreground">
                                Kitap bilgilerini otomatik doldurmak için ISBN numarasını girin ve "ISBN Ara" butonuna tıklayın
                            </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Kitap Adı */}
                            <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="title">Kitap Adı *</Label>
                                <Input
                                    id="title"
                                    placeholder="Clean Code"
                                    value={formData.title}
                                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                    disabled={loading}
                                    required
                                />
                            </div>

                            {/* Yazar */}
                            <div className="space-y-2">
                                <Label htmlFor="author">Yazar *</Label>
                                <Input
                                    id="author"
                                    placeholder="Robert C. Martin"
                                    value={formData.author}
                                    onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                                    disabled={loading}
                                    required
                                />
                            </div>

                            {/* Yayınevi */}
                            <div className="space-y-2">
                                <Label htmlFor="publisher">Yayınevi</Label>
                                <Input
                                    id="publisher"
                                    placeholder="Prentice Hall"
                                    value={formData.publisher}
                                    onChange={(e) => setFormData({ ...formData, publisher: e.target.value })}
                                    disabled={loading}
                                />
                            </div>

                            {/* Yayın Yılı */}
                            <div className="space-y-2">
                                <Label htmlFor="year">Yayın Yılı</Label>
                                <Input
                                    id="year"
                                    type="number"
                                    placeholder="2024"
                                    value={formData.year}
                                    onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                                    disabled={loading}
                                />
                            </div>

                            {/* Dil */}
                            <div className="space-y-2">
                                <Label htmlFor="language">Dil *</Label>
                                <Select
                                    value={formData.language}
                                    onValueChange={(value) => setFormData({ ...formData, language: value })}
                                    disabled={loading}
                                >
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Türkçe">Türkçe</SelectItem>
                                        <SelectItem value="İngilizce">İngilizce</SelectItem>
                                        <SelectItem value="Almanca">Almanca</SelectItem>
                                        <SelectItem value="Fransızca">Fransızca</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            {/* Kategori */}
                            <div className="space-y-2">
                                <Label htmlFor="category">Kategori *</Label>
                                <Input
                                    id="category"
                                    placeholder="Bilgisayar Bilimleri"
                                    value={formData.category}
                                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                                    disabled={loading}
                                    required
                                />
                            </div>

                            {/* Sayfa Sayısı */}
                            <div className="space-y-2">
                                <Label htmlFor="pages">Sayfa Sayısı</Label>
                                <Input
                                    id="pages"
                                    type="number"
                                    placeholder="464"
                                    value={formData.pages}
                                    onChange={(e) => setFormData({ ...formData, pages: e.target.value })}
                                    disabled={loading}
                                />
                            </div>

                            {/* Kopya Sayısı */}
                            <div className="space-y-2">
                                <Label htmlFor="totalCopies">Kopya Sayısı *</Label>
                                <Input
                                    id="totalCopies"
                                    type="number"
                                    min="1"
                                    placeholder="1"
                                    value={formData.totalCopies}
                                    onChange={(e) => setFormData({ ...formData, totalCopies: e.target.value })}
                                    disabled={loading}
                                    required
                                />
                            </div>

                            {/* Konum */}
                            <div className="space-y-2">
                                <Label htmlFor="location">Raf Konumu *</Label>
                                <Input
                                    id="location"
                                    placeholder="A-101"
                                    value={formData.location}
                                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                                    disabled={loading}
                                    required
                                />
                            </div>

                            {/* Özet */}
                            <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="summary">Özet</Label>
                                <Textarea
                                    id="summary"
                                    placeholder="Kitap hakkında kısa açıklama..."
                                    value={formData.summary}
                                    onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                                    disabled={loading}
                                    rows={3}
                                />
                            </div>

                            {/* Kapak URL */}
                            <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="coverUrl">Kapak Görseli URL</Label>
                                <Input
                                    id="coverUrl"
                                    type="url"
                                    placeholder="https://example.com/book-cover.jpg"
                                    value={formData.coverUrl}
                                    onChange={(e) => setFormData({ ...formData, coverUrl: e.target.value })}
                                    disabled={loading}
                                />
                            </div>
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                            İptal
                        </Button>
                        <Button type="submit" disabled={loading}>
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {book ? "Güncelle" : "Ekle"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
