import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Nfc, Scan, Search, Trash2, Loader2, CheckCircle2,
  AlertTriangle, XCircle, BookOpen, Tag, Wifi, WifiOff,
  CreditCard, RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { rfidAPI } from "@/lib/api";

// ── Types ──────────────────────────────────────────────────

interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publisher?: string;
  category?: string;
  total_copies: number;
  available_copies: number;
  location?: string;
  cover_image?: string;
}

interface BookCopy {
  id: string;
  book_id: string;
  rfid_uid: string;
  status: string;
  location?: string;
  notes?: string;
  book_title?: string;
  book_isbn?: string;
  book_author?: string;
  book_cover?: string;
  created_at?: string;
}

interface ScanResult {
  uid: string | null;
  found: boolean;
  copy?: BookCopy;
  message: string;
}

type AssignmentState = "idle" | "scanning" | "success" | "error";
type LookupState = "idle" | "scanning" | "found" | "not_found" | "error";

interface Props {
  books: Book[];
}

// ── Pulsing NFC Animation ─────────────────────────────────

function ScanAnimation({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center gap-4 py-8">
      <div className="relative flex items-center justify-center">
        {/* Pulse rings */}
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute rounded-full border-2 border-primary/30"
            initial={{ width: 60, height: 60, opacity: 0.8 }}
            animate={{
              width: [60, 120 + i * 30],
              height: [60, 120 + i * 30],
              opacity: [0.6, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.5,
              ease: "easeOut",
            }}
          />
        ))}
        {/* Center icon */}
        <motion.div
          className="relative z-10 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <Nfc className="h-8 w-8 text-primary" />
        </motion.div>
      </div>
      <div className="text-center space-y-1">
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">
          Kartı okuyucuya yaklaştırın...
        </p>
      </div>
    </div>
  );
}

// ── Status badge for copy status ─────────────────────────

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string }> = {
    available: { label: "Mevcut", className: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
    borrowed: { label: "Ödünç", className: "bg-amber-500/10 text-amber-600 border-amber-500/20" },
    lost: { label: "Kayıp", className: "bg-red-500/10 text-red-600 border-red-500/20" },
    damaged: { label: "Hasarlı", className: "bg-orange-500/10 text-orange-600 border-orange-500/20" },
    maintenance: { label: "Bakımda", className: "bg-blue-500/10 text-blue-600 border-blue-500/20" },
  };
  const c = config[status] || { label: status, className: "bg-muted text-muted-foreground" };
  return <Badge variant="outline" className={cn("text-[10px] font-semibold", c.className)}>{c.label}</Badge>;
}

// ═══════════════════════════════════════════════════════════
// RFID Manager Panel
// ═══════════════════════════════════════════════════════════

export function RFIDManagerPanel({ books }: Props) {
  // ── RFID Connection Status ─────────────────────────────
  const [rfidConnected, setRfidConnected] = useState<boolean | null>(null);

  useEffect(() => {
    rfidAPI.getStatus()
      .then((s) => setRfidConnected(s.connected))
      .catch(() => setRfidConnected(false));
  }, []);

  // ── Section A: Assignment ──────────────────────────────
  const [selectedBookId, setSelectedBookId] = useState("");
  const [assignState, setAssignState] = useState<AssignmentState>("idle");
  const [assignResult, setAssignResult] = useState<BookCopy | null>(null);
  const [assignError, setAssignError] = useState("");
  const [copies, setCopies] = useState<BookCopy[]>([]);
  const [copiesLoading, setCopiesLoading] = useState(false);
  const [bookSearch, setBookSearch] = useState("");

  const selectedBook = books.find((b) => b.id === selectedBookId);

  const filteredBooks = bookSearch.trim()
    ? books.filter(
        (b) =>
          b.title.toLowerCase().includes(bookSearch.toLowerCase()) ||
          b.author.toLowerCase().includes(bookSearch.toLowerCase()) ||
          b.isbn.includes(bookSearch)
      )
    : books;

  const fetchCopies = useCallback(async (bookId: string) => {
    if (!bookId) return;
    setCopiesLoading(true);
    try {
      const data = await rfidAPI.getCopies(bookId);
      setCopies(data);
    } catch {
      setCopies([]);
    } finally {
      setCopiesLoading(false);
    }
  }, []);

  useEffect(() => {
    if (selectedBookId) {
      fetchCopies(selectedBookId);
      setAssignState("idle");
      setAssignResult(null);
      setAssignError("");
    } else {
      setCopies([]);
    }
  }, [selectedBookId, fetchCopies]);

  const handleStartAssignment = async () => {
    if (!selectedBookId) return;
    setAssignState("scanning");
    setAssignResult(null);
    setAssignError("");
    try {
      const result = await rfidAPI.startAssignment(selectedBookId, 30);
      setAssignState("success");
      setAssignResult(result);
      toast.success(`RFID etiketi atandı: ${result.rfid_uid}`);
      fetchCopies(selectedBookId);
    } catch (error: any) {
      setAssignState("error");
      const detail = error.response?.data?.detail || "RFID atama başarısız";
      setAssignError(detail);
      if (error.response?.status === 408) {
        toast.error("Zaman aşımı — kart okunamadı");
      } else if (error.response?.status === 409) {
        toast.error(detail);
      } else {
        toast.error(detail);
      }
    }
  };

  const handleDeleteCopy = async (copyId: string, uid: string) => {
    if (!confirm(`'${uid}' RFID etiketini silmek istediğinize emin misiniz?`)) return;
    try {
      await rfidAPI.deleteCopy(copyId);
      toast.success("RFID etiketi silindi");
      fetchCopies(selectedBookId);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || "Silme başarısız");
    }
  };

  // ── Section B: Lookup ──────────────────────────────────
  const [lookupState, setLookupState] = useState<LookupState>("idle");
  const [lookupResult, setLookupResult] = useState<ScanResult | null>(null);
  const [manualUid, setManualUid] = useState("");

  const handleScanLookup = async () => {
    setLookupState("scanning");
    setLookupResult(null);
    try {
      const result: ScanResult = await rfidAPI.scanLookup(10);
      setLookupResult(result);
      if (result.found) {
        setLookupState("found");
        toast.success(result.message);
      } else if (result.uid) {
        setLookupState("not_found");
        toast.warning(result.message);
      } else {
        setLookupState("error");
        toast.error(result.message);
      }
    } catch (error: any) {
      setLookupState("error");
      toast.error(error.response?.data?.detail || "Tarama başarısız");
    }
  };

  const handleManualLookup = async () => {
    if (!manualUid.trim()) return;
    setLookupState("scanning");
    setLookupResult(null);
    try {
      const copy = await rfidAPI.lookupByUid(manualUid.trim());
      setLookupResult({
        uid: copy.rfid_uid,
        found: true,
        copy,
        message: `Kitap bulundu: ${copy.book_title}`,
      });
      setLookupState("found");
      toast.success(`Kitap bulundu: ${copy.book_title}`);
    } catch (error: any) {
      if (error.response?.status === 404) {
        setLookupResult({
          uid: manualUid.trim().toUpperCase(),
          found: false,
          message: "Bu UID'ye ait kayıt bulunamadı.",
        });
        setLookupState("not_found");
        toast.warning("UID bulunamadı");
      } else {
        setLookupState("error");
        toast.error(error.response?.data?.detail || "Arama başarısız");
      }
    }
  };

  // ── Render ─────────────────────────────────────────────

  return (
    <div className="space-y-8">
      {/* Connection Status Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className={cn(
          "flex items-center gap-3 p-4 rounded-xl border",
          rfidConnected === true
            ? "bg-emerald-500/5 border-emerald-500/20"
            : rfidConnected === false
            ? "bg-red-500/5 border-red-500/20"
            : "bg-muted/50 border-border"
        )}
      >
        {rfidConnected === null ? (
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        ) : rfidConnected ? (
          <Wifi className="h-5 w-5 text-emerald-500" />
        ) : (
          <WifiOff className="h-5 w-5 text-red-500" />
        )}
        <div className="flex-1">
          <p className="text-sm font-medium">
            RFID Okuyucu:{" "}
            {rfidConnected === null
              ? "Kontrol ediliyor..."
              : rfidConnected
              ? "Bağlı"
              : "Bağlı Değil"}
          </p>
          {rfidConnected === false && (
            <p className="text-xs text-muted-foreground mt-0.5">
              RFID_ENABLED=true ayarlayın ve okuyucuyu bağlayın. Manuel UID girişi kullanabilirsiniz.
            </p>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={async () => {
            setRfidConnected(null);
            try {
              const s = await rfidAPI.getStatus();
              setRfidConnected(s.connected);
            } catch {
              setRfidConnected(false);
            }
          }}
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </motion.div>

      {/* ═══════ Section A: RFID Assignment ═══════ */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="rounded-2xl border border-border bg-card p-6 space-y-5"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
            <Tag className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-display font-bold text-base">RFID Etiket Atama</h3>
            <p className="text-xs text-muted-foreground">Kitaba fiziksel RFID etiketi bağlayın</p>
          </div>
        </div>

        {/* Book selector */}
        <div className="space-y-2">
          <Label className="text-xs font-medium">Kitap Seçin</Label>
          <div className="space-y-2">
            <Input
              placeholder="Kitap ara (isim, yazar veya ISBN)..."
              value={bookSearch}
              onChange={(e) => setBookSearch(e.target.value)}
              className="h-9"
            />
            <Select value={selectedBookId} onValueChange={setSelectedBookId}>
              <SelectTrigger className="h-10">
                <SelectValue placeholder="Kitap seçin..." />
              </SelectTrigger>
              <SelectContent className="max-h-60">
                {filteredBooks.map((book) => (
                  <SelectItem key={book.id} value={book.id}>
                    <span className="truncate">
                      {book.title} — <span className="text-muted-foreground">{book.author}</span>
                    </span>
                  </SelectItem>
                ))}
                {filteredBooks.length === 0 && (
                  <div className="p-3 text-center text-sm text-muted-foreground">
                    Kitap bulunamadı
                  </div>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Selected book info */}
        <AnimatePresence mode="wait">
          {selectedBook && (
            <motion.div
              key={selectedBook.id}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="flex gap-4 p-4 rounded-xl bg-muted/50 border border-border">
                {selectedBook.cover_image ? (
                  <img
                    src={selectedBook.cover_image}
                    alt={selectedBook.title}
                    className="h-20 w-14 rounded-lg object-cover border border-border shadow-sm flex-shrink-0"
                    onError={(e) => (e.currentTarget.style.display = "none")}
                  />
                ) : (
                  <div className="h-20 w-14 rounded-lg bg-primary/5 border border-border flex items-center justify-center flex-shrink-0">
                    <BookOpen className="h-6 w-6 text-primary/40" />
                  </div>
                )}
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="font-semibold text-sm truncate">{selectedBook.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{selectedBook.author}</p>
                  <div className="flex items-center gap-2 text-xs">
                    <Badge variant="outline" className="text-[10px]">ISBN: {selectedBook.isbn}</Badge>
                    <Badge variant="outline" className="text-[10px]">
                      Kopya: {selectedBook.total_copies}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Assignment action */}
              <div className="mt-4">
                <AnimatePresence mode="wait">
                  {assignState === "idle" && (
                    <motion.div
                      key="idle"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      <Button
                        onClick={handleStartAssignment}
                        variant="default"
                        className="w-full gap-2 h-11 bg-primary hover:bg-primary/90"
                        disabled={!rfidConnected}
                      >
                        <Nfc className="h-5 w-5" />
                        RFID Atama Başlat
                      </Button>
                      {!rfidConnected && (
                        <p className="text-xs text-muted-foreground mt-2 text-center">
                          RFID okuyucu bağlı değil
                        </p>
                      )}
                    </motion.div>
                  )}

                  {assignState === "scanning" && (
                    <motion.div
                      key="scanning"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                    >
                      <ScanAnimation label="RFID etiketi bekleniyor..." />
                      <p className="text-xs text-center text-muted-foreground mt-1">
                        30 saniye içinde kartı okuyucuya yaklaştırın
                      </p>
                    </motion.div>
                  )}

                  {assignState === "success" && assignResult && (
                    <motion.div
                      key="success"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 space-y-3"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        <span className="font-semibold text-sm text-emerald-600">
                          RFID Etiketi Başarıyla Atandı
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CreditCard className="h-4 w-4 text-muted-foreground" />
                        <code className="font-mono text-xs bg-background px-2 py-1 rounded border">
                          {assignResult.rfid_uid}
                        </code>
                        <StatusBadge status={assignResult.status} />
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => {
                          setAssignState("idle");
                          setAssignResult(null);
                        }}
                      >
                        Yeni Etiket Ata
                      </Button>
                    </motion.div>
                  )}

                  {assignState === "error" && (
                    <motion.div
                      key="error"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="p-4 rounded-xl bg-red-500/5 border border-red-500/20 space-y-3"
                    >
                      <div className="flex items-center gap-2">
                        <XCircle className="h-5 w-5 text-red-500" />
                        <span className="font-semibold text-sm text-red-600">
                          Atama Başarısız
                        </span>
                      </div>
                      <p className="text-xs text-red-600/80">{assignError}</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setAssignState("idle");
                          setAssignError("");
                        }}
                      >
                        Tekrar Dene
                      </Button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Existing copies list */}
              <div className="mt-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <Tag className="h-4 w-4 text-muted-foreground" />
                    Atanmış RFID Etiketleri
                    {copies.length > 0 && (
                      <Badge variant="secondary" className="text-[10px]">{copies.length}</Badge>
                    )}
                  </h4>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => fetchCopies(selectedBookId)}
                    disabled={copiesLoading}
                  >
                    <RefreshCw className={cn("h-3.5 w-3.5", copiesLoading && "animate-spin")} />
                  </Button>
                </div>

                {copiesLoading ? (
                  <div className="flex items-center justify-center py-6">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  </div>
                ) : copies.length === 0 ? (
                  <div className="text-center py-6 text-sm text-muted-foreground">
                    Bu kitaba henüz RFID etiketi atanmamış
                  </div>
                ) : (
                  <div className="space-y-2">
                    {copies.map((copy, idx) => (
                      <motion.div
                        key={copy.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/5">
                            <CreditCard className="h-4 w-4 text-primary/60" />
                          </div>
                          <div>
                            <code className="font-mono text-xs font-semibold">{copy.rfid_uid}</code>
                            <div className="flex items-center gap-2 mt-0.5">
                              <StatusBadge status={copy.status} />
                              {copy.created_at && (
                                <span className="text-[10px] text-muted-foreground">
                                  {new Date(copy.created_at).toLocaleDateString("tr-TR")}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDeleteCopy(copy.id, copy.rfid_uid)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ═══════ Section B: RFID Lookup ═══════ */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-2xl border border-border bg-card p-6 space-y-5"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary/50">
            <Scan className="h-5 w-5 text-secondary-foreground" />
          </div>
          <div>
            <h3 className="font-display font-bold text-base">RFID Etiket Sorgulama</h3>
            <p className="text-xs text-muted-foreground">Etiket tarayın veya UID ile arayın</p>
          </div>
        </div>

        {/* Scan button */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Button
            onClick={handleScanLookup}
            variant="outline"
            className="h-12 gap-2 border-primary/20 hover:border-primary/40"
            disabled={lookupState === "scanning" || !rfidConnected}
          >
            <Nfc className="h-5 w-5" />
            Donanımdan Tara
          </Button>

          <div className="flex gap-2">
            <Input
              value={manualUid}
              onChange={(e) => setManualUid(e.target.value)}
              placeholder="Manuel UID girin..."
              className="h-12 font-mono text-sm"
              onKeyDown={(e) => {
                if (e.key === "Enter") handleManualLookup();
              }}
            />
            <Button
              onClick={handleManualLookup}
              variant="outline"
              className="h-12 px-4"
              disabled={!manualUid.trim() || lookupState === "scanning"}
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Lookup results */}
        <AnimatePresence mode="wait">
          {lookupState === "scanning" && (
            <motion.div
              key="scanning"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <ScanAnimation label="Kart okunuyor..." />
            </motion.div>
          )}

          {lookupState === "found" && lookupResult?.copy && (
            <motion.div
              key="found"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="relative overflow-hidden rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/5 via-background to-primary/5 p-5"
            >
              {/* Glassmorphism overlay */}
              <div className="absolute inset-0 bg-background/40 backdrop-blur-[1px]" />

              <div className="relative z-10 flex gap-4">
                {lookupResult.copy.book_cover ? (
                  <img
                    src={lookupResult.copy.book_cover}
                    alt={lookupResult.copy.book_title || ""}
                    className="h-28 w-20 rounded-xl object-cover border border-border shadow-md flex-shrink-0"
                    onError={(e) => (e.currentTarget.style.display = "none")}
                  />
                ) : (
                  <div className="h-28 w-20 rounded-xl bg-primary/5 border border-border flex items-center justify-center flex-shrink-0">
                    <BookOpen className="h-8 w-8 text-primary/30" />
                  </div>
                )}
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-base leading-tight">
                        {lookupResult.copy.book_title || "Bilinmeyen"}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {lookupResult.copy.book_author || ""}
                      </p>
                    </div>
                    <StatusBadge status={lookupResult.copy.status} />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-1.5">
                      <CreditCard className="h-3.5 w-3.5 text-muted-foreground" />
                      <code className="font-mono bg-background/80 px-1.5 py-0.5 rounded border text-[11px]">
                        {lookupResult.copy.rfid_uid}
                      </code>
                    </div>
                    {lookupResult.copy.book_isbn && (
                      <div className="flex items-center gap-1.5">
                        <Tag className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>ISBN: {lookupResult.copy.book_isbn}</span>
                      </div>
                    )}
                    {lookupResult.copy.location && (
                      <div className="text-muted-foreground">
                        📍 {lookupResult.copy.location}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {lookupState === "not_found" && lookupResult && (
            <motion.div
              key="not_found"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="p-5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-center space-y-2"
            >
              <AlertTriangle className="h-8 w-8 text-amber-500 mx-auto" />
              <p className="font-semibold text-sm">Etiket Bulunamadı</p>
              {lookupResult.uid && (
                <p className="text-xs text-muted-foreground">
                  UID: <code className="font-mono bg-background px-1.5 py-0.5 rounded border">{lookupResult.uid}</code>
                </p>
              )}
              <p className="text-xs text-muted-foreground">{lookupResult.message}</p>
            </motion.div>
          )}

          {lookupState === "error" && (
            <motion.div
              key="error"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="p-5 rounded-xl bg-red-500/5 border border-red-500/20 text-center space-y-2"
            >
              <XCircle className="h-8 w-8 text-red-500 mx-auto" />
              <p className="font-semibold text-sm">Tarama Başarısız</p>
              <p className="text-xs text-muted-foreground">
                {lookupResult?.message || "RFID okuyucu ile iletişim kurulamadı"}
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setLookupState("idle");
                  setLookupResult(null);
                }}
              >
                Tekrar Dene
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
