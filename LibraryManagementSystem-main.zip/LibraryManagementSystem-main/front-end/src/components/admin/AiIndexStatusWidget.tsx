import { useEffect, useState } from "react";
import { Brain, RefreshCw, Clock, Database, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { adminAPI } from "@/lib/supportApi";

type AiStatus = {
  artifacts: {
    index: { exists: boolean; mtime: string | null; ntotal: number | null; dim: number | null };
    metadata: { exists: boolean; mtime: string | null; len: number | null };
  };
  auto_indexing: {
    enabled: boolean;
    debounce_seconds: number;
    scheduled: boolean;
    running: boolean;
    next_run_at: string | null;
    last_run_at: string | null;
    last_error: string | null;
  };
};

export function AiIndexStatusWidget() {
  const [loading, setLoading] = useState(false);
  const [retraining, setRetraining] = useState(false);
  const [data, setData] = useState<AiStatus | null>(null);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await adminAPI.getAiStatus();
      setData(res);
    } catch (e: any) {
      toast.error("AI durumu alınamadı", { description: e?.response?.data?.detail || "API hatası" });
    } finally {
      setLoading(false);
    }
  };

  const retrain = async () => {
    setRetraining(true);
    try {
      await adminAPI.retrainAi();
      toast.success("AI retrain tetiklendi");
      await fetchStatus();
    } catch (e: any) {
      toast.error("AI retrain başarısız", { description: e?.response?.data?.detail || "API hatası" });
    } finally {
      setRetraining(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const t = setInterval(fetchStatus, 30_000);
    return () => clearInterval(t);
  }, []);

  const status = data?.auto_indexing;
  const running = !!status?.running;
  const scheduled = !!status?.scheduled;
  const hasError = !!status?.last_error;

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={cn("p-2 rounded-lg", hasError ? "bg-destructive/10" : "bg-primary/10")}>
            <Brain className={cn("h-5 w-5", hasError ? "text-destructive" : "text-primary")} />
          </div>
          <div>
            <h3 className="font-display font-semibold">AI İndeks Durumu</h3>
            <p className="text-xs text-muted-foreground">
              Yeni kitaplar otomatik indekslenir (debounce).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={fetchStatus} disabled={loading}>
            <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
          </Button>
          <Button size="sm" onClick={retrain} disabled={retraining || running}>
            <RefreshCw className={cn("h-4 w-4 mr-2", (retraining || running) && "animate-spin")} />
            Retrain
          </Button>
        </div>
      </div>

      {data ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-lg border border-border bg-muted/20 space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Database className="h-4 w-4 text-muted-foreground" /> FAISS Index
            </div>
            <div className="text-xs text-muted-foreground">
              {data.artifacts.index.exists ? (
                <>
                  <div>ntotal: <span className="text-foreground">{data.artifacts.index.ntotal ?? "-"}</span></div>
                  <div>dim: <span className="text-foreground">{data.artifacts.index.dim ?? "-"}</span></div>
                  <div>mtime: <span className="text-foreground">{data.artifacts.index.mtime ?? "-"}</span></div>
                </>
              ) : (
                <div className="text-destructive">Index bulunamadı (retrain gerekli)</div>
              )}
            </div>
          </div>

          <div className="p-4 rounded-lg border border-border bg-muted/20 space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Clock className="h-4 w-4 text-muted-foreground" /> Auto-Indexing
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              <div>enabled: <span className="text-foreground">{String(status?.enabled ?? false)}</span></div>
              <div>debounce: <span className="text-foreground">{status?.debounce_seconds ?? "-"}s</span></div>
              <div>scheduled: <span className="text-foreground">{String(scheduled)}</span></div>
              <div>running: <span className="text-foreground">{String(running)}</span></div>
              <div>last run: <span className="text-foreground">{status?.last_run_at ?? "-"}</span></div>
              {hasError && (
                <div className="flex items-start gap-2 text-destructive pt-1">
                  <AlertTriangle className="h-4 w-4 mt-0.5" />
                  <span>{status?.last_error}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="text-sm text-muted-foreground">Yükleniyor...</div>
      )}
    </div>
  );
}







