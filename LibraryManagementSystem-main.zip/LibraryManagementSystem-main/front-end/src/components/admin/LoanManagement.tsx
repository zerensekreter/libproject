import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LoanFormDialog } from "./LoanFormDialog";

export function LoanManagement() {
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    return (
        <Card>
            <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <CardTitle>Ödünç İşlemleri</CardTitle>
                        <CardDescription>Kullanıcılara kitap ödünç ver</CardDescription>
                    </div>
                    <Button onClick={() => setIsDialogOpen(true)} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Yeni Ödünç İşlemi
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                <div className="text-center py-12 text-muted-foreground">
                    <p>Ödünç işlemi oluşturmak için "Yeni Ödünç İşlemi" butonuna tıklayın.</p>
                    <p className="text-sm mt-2">Öğrenci numarası ve kitap bilgileri otomatik doldurulacaktır.</p>
                </div>

                <LoanFormDialog
                    open={isDialogOpen}
                    onOpenChange={setIsDialogOpen}
                />
            </CardContent>
        </Card>
    );
}
