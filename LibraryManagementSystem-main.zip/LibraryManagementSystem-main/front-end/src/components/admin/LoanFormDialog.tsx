import { useState } from "react";
import { Loader2, Search, Calendar as CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { mockUsers, mockBooks } from "@/data/mockData";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

interface LoanFormDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

export function LoanFormDialog({ open, onOpenChange }: LoanFormDialogProps) {
    const [loading, setLoading] = useState(false);
    const [searchingUser, setSearchingUser] = useState(false);
    const [searchingBook, setSearchingBook] = useState(false);

    const [studentId, setStudentId] = useState("");
    const [selectedUser, setSelectedUser] = useState<any>(null);

    const [bookSearch, setBookSearch] = useState("");
    const [selectedBook, setSelectedBook] = useState<any>(null);

    const [dueDate, setDueDate] = useState<Date>(
        new Date(Date.now() + 14 * 24 * 60 * 60 * 1000) // 14 gün sonra
    );

    // Öğrenci no ile kullanıcı bilgisi çekme
    const handleStudentIdSearch = async () => {
        if (studentId.length < 5) {
            toast.error("Geçerli bir öğrenci numarası girin");
            return;
        }

        setSearchingUser(true);
        try {
            // TODO: Backend API'den kullanıcı ara
            await new Promise(resolve => setTimeout(resolve, 800));

            const user = mockUsers.find(u => u.studentId === studentId);

            if (user) {
                setSelectedUser(user);
                toast.success("Kullanıcı bulundu!");
            } else {
                toast.error("Kullanıcı bulunamadı");
                setSelectedUser(null);
            }
        } catch (error) {
            toast.error("Kullanıcı arama hatası");
        } finally {
            setSearchingUser(false);
        }
    };

    // Kitap arama (ISBN veya başlık)
    const handleBookSearch = async () => {
        if (bookSearch.length < 3) {
            toast.error("En az 3 karakter girin");
            return;
        }

        setSearchingBook(true);
        try {
            // TODO: Backend API'den kitap ara
            await new Promise(resolve => setTimeout(resolve, 800));

            const book = mockBooks.find(b =>
                b.isbn.includes(bookSearch) ||
                b.title.toLowerCase().includes(bookSearch.toLowerCase())
            );

            if (book) {
                if (book.availableCopies > 0) {
                    setSelectedBook(book);
                    toast.success("Kitap bulundu!");
                } else {
                    toast.error("Bu kitabın mevcut kopyası yok");
                    setSelectedBook(null);
                }
            } else {
                toast.error("Kitap bulunamadı");
                setSelectedBook(null);
            }
        } catch (error) {
            toast.error("Kitap arama hatası");
        } finally {
            setSearchingBook(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!selectedUser) {
            toast.error("Önce bir kullanıcı seçin");
            return;
        }

        if (!selectedBook) {
            toast.error("Önce bir kitap seçin");
            return;
        }

        // Kullanıcı ödünç limitini kontrol et
        if (selectedUser.borrowedBooks >= selectedUser.maxBooks) {
            toast.error(`Bu kullanıcı maksimum ödünç limitine (${selectedUser.maxBooks}) ulaştı!`);
            return;
        }

        setLoading(true);
        try {
            // TODO: Backend API'ye ödünç kaydı oluştur
            await new Promise(resolve => setTimeout(resolve, 1000));

            toast.success("Ödünç işlemi başarıyla oluşturuldu!");

            // Reset form
            setStudentId("");
            setSelectedUser(null);
            setBookSearch("");
            setSelectedBook(null);
            setDueDate(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000));

            onOpenChange(false);
        } catch (error) {
            toast.error("Ödünç işlemi oluşturulamadı");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle>Yeni Ödünç İşlemi</DialogTitle>
                    <DialogDescription>
                        Kullanıcıya kitap ödünç vermek için bilgileri girin
                    </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleSubmit}>
                    <div className="space-y-6 py-4">
                        {/* Kullanıcı Seçimi */}
                        <div className="space-y-3">
                            <Label>Kullanıcı *</Label>
                            <div className="flex gap-2">
                                <Input
                                    placeholder="Öğrenci / Personel No"
                                    value={studentId}
                                    onChange={(e) => setStudentId(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleStudentIdSearch())}
                                    disabled={loading || searchingUser}
                                    className="flex-1"
                                />
                                <Button
                                    type="button"
                                    variant="secondary"
                                    onClick={handleStudentIdSearch}
                                    disabled={loading || searchingUser || studentId.length < 5}
                                    className="gap-2"
                                >
                                    {searchingUser ? (
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                        <Search className="h-4 w-4" />
                                    )}
                                    Ara
                                </Button>
                            </div>

                            {selectedUser && (
                                <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/30">
                                    <Avatar>
                                        <AvatarImage src={selectedUser.avatar} />
                                        <AvatarFallback>{selectedUser.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                        <p className="font-medium">{selectedUser.name}</p>
                                        <p className="text-sm text-muted-foreground">{selectedUser.email}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-xs text-muted-foreground">Ödünç</p>
                                        <p className={`font-medium ${selectedUser.borrowedBooks >= selectedUser.maxBooks ? 'text-destructive' : ''}`}>
                                            {selectedUser.borrowedBooks} / {selectedUser.maxBooks}
                                        </p>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Kitap Seçimi */}
                        <div className="space-y-3">
                            <Label>Kitap *</Label>
                            <div className="flex gap-2">
                                <Input
                                    placeholder="Kitap adı veya ISBN"
                                    value={bookSearch}
                                    onChange={(e) => setBookSearch(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleBookSearch())}
                                    disabled={loading || searchingBook}
                                    className="flex-1"
                                />
                                <Button
                                    type="button"
                                    variant="secondary"
                                    onClick={handleBookSearch}
                                    disabled={loading || searchingBook || bookSearch.length < 3}
                                    className="gap-2"
                                >
                                    {searchingBook ? (
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                        <Search className="h-4 w-4" />
                                    )}
                                    Ara
                                </Button>
                            </div>

                            {selectedBook && (
                                <div className="flex gap-3 p-3 border rounded-lg bg-muted/30">
                                    <img
                                        src={selectedBook.coverImage}
                                        alt={selectedBook.title}
                                        className="w-12 h-16 object-cover rounded"
                                    />
                                    <div className="flex-1">
                                        <p className="font-medium line-clamp-1">{selectedBook.title}</p>
                                        <p className="text-sm text-muted-foreground">{selectedBook.author}</p>
                                        <p className="text-xs text-muted-foreground font-mono mt-1">{selectedBook.isbn}</p>
                                    </div>
                                    <div className="text-right">
                                        <Badge variant={selectedBook.availableCopies > 0 ? "default" : "destructive"}>
                                            {selectedBook.availableCopies} / {selectedBook.totalCopies}
                                        </Badge>
                                        <p className="text-xs text-muted-foreground mt-1">{selectedBook.location}</p>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* İade Tarihi */}
                        <div className="space-y-2">
                            <Label>İade Tarihi *</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant="outline"
                                        className="w-full justify-start text-left font-normal"
                                        disabled={loading}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {format(dueDate, "dd MMMM yyyy", { locale: tr })}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        mode="single"
                                        selected={dueDate}
                                        onSelect={(date) => date && setDueDate(date)}
                                        disabled={(date) => date < new Date()}
                                        initialFocus
                                        locale={tr}
                                    />
                                </PopoverContent>
                            </Popover>
                            <p className="text-xs text-muted-foreground">
                                Varsayılan: 14 gün sonra
                            </p>
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                            İptal
                        </Button>
                        <Button type="submit" disabled={loading || !selectedUser || !selectedBook}>
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Ödünç Ver
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
