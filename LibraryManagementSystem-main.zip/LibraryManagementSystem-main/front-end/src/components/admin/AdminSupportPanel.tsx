import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
    MessageCircle,
    Send,
    Loader2,
    Check,
    CheckCheck,
    X,
    RefreshCw,
    User,
    Clock,
    Circle,
    Archive,
    RotateCcw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { getToken } from "@/lib/api";
import {
    supportAPI,
    SupportSession,
    ChatMessage,
    playNotificationSound
} from "@/lib/supportApi";
import { toast } from "sonner";

type AdminSupportPanelProps = {
    /** Parent (Admin page) unread counter sync */
    onUnreadChange?: (totalUnread: number) => void;
    /** If provided, panel will auto-select this session once sessions are loaded */
    focusSessionId?: string | null;
    /** Called after focus session is applied */
    onFocusApplied?: () => void;
};

export function AdminSupportPanel({ onUnreadChange, focusSessionId, onFocusApplied }: AdminSupportPanelProps) {
    const [sessions, setSessions] = useState<SupportSession[]>([]);
    const [selectedSession, setSelectedSession] = useState<string | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [newMessage, setNewMessage] = useState("");
    const [isLoading, setIsLoading] = useState(true);
    const [isLoadingMessages, setIsLoadingMessages] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const [typingUsers, setTypingUsers] = useState<Record<string, boolean>>({});
    const [statusFilter, setStatusFilter] = useState<"active" | "closed">("active");

    const wsRef = useRef<WebSocket | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    // Ref to track current selected session for WebSocket handlers
    const selectedSessionRef = useRef<string | null>(null);

    // Keep ref in sync with state
    useEffect(() => {
        selectedSessionRef.current = selectedSession;
    }, [selectedSession]);

    // Scroll to bottom when new message arrives
    const scrollToBottom = useCallback(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [messages, scrollToBottom]);

    // Connect WebSocket on mount - with proper cleanup
    const wsConnectedRef = useRef(false);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    const loadSessions = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await supportAPI.getSessions(statusFilter);
            setSessions(data);
        } catch (error) {
            console.error("Failed to load sessions:", error);
            toast.error("Oturumlar yüklenemedi");
        } finally {
            setIsLoading(false);
        }
    }, [statusFilter]);

    // Load sessions
    useEffect(() => {
        loadSessions();
    }, [loadSessions]);

    const handleNewMessage = useCallback((data: any) => {
        const { session_id, message } = data;
        const currentSelectedSession = selectedSessionRef.current;

        // Update session list
        setSessions((prev) => {
            const updated = prev.map((s) =>
                s.id === session_id
                    ? {
                        ...s,
                        last_message_at: message.created_at,
                        last_message_preview: message.content.substring(0, 50),
                        unread_count: s.id === currentSelectedSession ? 0 : s.unread_count + 1
                    }
                    : s
            );
            // Sort by last message
            return updated.sort((a, b) =>
                new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime()
            );
        });

        // If this session is selected, add message
        if (session_id === currentSelectedSession) {
            setMessages((prev) => [...prev, message]);
            // Mark as read
            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                wsRef.current.send(JSON.stringify({
                    type: "mark_read",
                    session_id
                }));
            }
        } else {
            // Play notification sound for unselected sessions
            playNotificationSound();
        }
    }, []);

    const handleMessageSent = useCallback((data: any) => {
        const { session_id, message } = data;
        const currentSelectedSession = selectedSessionRef.current;

        // Update session preview
        setSessions((prev) =>
            prev.map((s) =>
                s.id === session_id
                    ? {
                        ...s,
                        last_message_at: message.created_at,
                        last_message_preview: message.content.substring(0, 50)
                    }
                    : s
            )
        );

        // Add to messages if selected
        if (session_id === currentSelectedSession) {
            setMessages((prev) => {
                if (prev.find(m => m.id === message.id)) return prev;
                return [...prev, message];
            });
        }
    }, []);

    const connectWebSocket = useCallback(() => {
        // Prevent multiple connections
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            console.log("WebSocket already connected, skipping");
            return;
        }

        if (wsRef.current) {
            wsRef.current.close();
        }

        setIsConnecting(true);
        const wsUrl = supportAPI.getAdminWebSocketUrl();
        console.log("Connecting to WebSocket:", wsUrl);
        const ws = new WebSocket(wsUrl);

        ws.onopen = () => {
            setIsConnecting(false);
            console.log("Admin WebSocket connected successfully");
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            console.log("Admin WebSocket received:", data);

            switch (data.type) {
                case "new_message":
                    // New message from user
                    handleNewMessage(data);
                    break;

                case "message_sent":
                    // Our own message or another admin's message
                    handleMessageSent(data);
                    break;

                case "typing":
                    setTypingUsers((prev) => ({
                        ...prev,
                        [data.session_id]: data.is_typing
                    }));
                    break;

                case "error":
                    toast.error(data.message);
                    break;
            }
        };

        ws.onclose = (event) => {
            setIsConnecting(false);
            console.log("Admin WebSocket disconnected, code:", event.code, "reason:", event.reason);
            wsRef.current = null;

            // Only reconnect if component is still mounted and it wasn't intentional close
            if (wsConnectedRef.current && event.code !== 1000) {
                console.log("Scheduling reconnect in 3 seconds...");
                reconnectTimeoutRef.current = setTimeout(() => {
                    if (wsConnectedRef.current) {
                        connectWebSocket();
                    }
                }, 3000);
            }
        };

        ws.onerror = (error) => {
            console.error("WebSocket error:", error);
            setIsConnecting(false);
        };

        wsRef.current = ws;
    }, [handleMessageSent, handleNewMessage]);

    useEffect(() => {
        if (!wsConnectedRef.current) {
            wsConnectedRef.current = true;
            connectWebSocket();
        }

        return () => {
            wsConnectedRef.current = false;
            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current);
                reconnectTimeoutRef.current = null;
            }
            if (wsRef.current) {
                wsRef.current.close(1000, "Component unmounting");
                wsRef.current = null;
            }
        };
    }, [connectWebSocket]);

    // handleNewMessage / handleMessageSent are defined above via useCallback

    const loadMessages = async (sessionId: string) => {
        setIsLoadingMessages(true);
        try {
            const msgs = await supportAPI.getMessages(sessionId);
            setMessages(msgs);

            // Update unread count in local state
            setSessions((prev) =>
                prev.map((s) =>
                    s.id === sessionId ? { ...s, unread_count: 0 } : s
                )
            );

            // Mark as read via WebSocket
            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                wsRef.current.send(JSON.stringify({
                    type: "mark_read",
                    session_id: sessionId
                }));
            }
        } catch (error) {
            console.error("Failed to load messages:", error);
            toast.error("Mesajlar yüklenemedi");
        } finally {
            setIsLoadingMessages(false);
        }
    };

    const selectSession = (sessionId: string) => {
        setSelectedSession(sessionId);
        loadMessages(sessionId);
        setTypingUsers((prev) => ({ ...prev, [sessionId]: false }));
    };

    const sendMessage = () => {
        if (!newMessage.trim() || !selectedSession || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
            return;
        }

        wsRef.current.send(JSON.stringify({
            type: "message",
            session_id: selectedSession,
            content: newMessage.trim()
        }));

        setNewMessage("");
    };

    const handleTyping = (value: string) => {
        setNewMessage(value);

        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && selectedSession) {
            wsRef.current.send(JSON.stringify({
                type: "typing",
                session_id: selectedSession,
                is_typing: value.length > 0
            }));

            if (typingTimeoutRef.current) {
                clearTimeout(typingTimeoutRef.current);
            }

            if (value.length > 0) {
                typingTimeoutRef.current = setTimeout(() => {
                    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && selectedSession) {
                        wsRef.current.send(JSON.stringify({
                            type: "typing",
                            session_id: selectedSession,
                            is_typing: false
                        }));
                    }
                }, 2000);
            }
        }
    };

    const closeSession = async (sessionId: string) => {
        try {
            await supportAPI.closeSession(sessionId);
            toast.success("Oturum kapatıldı");
            loadSessions();
            if (selectedSession === sessionId) {
                setSelectedSession(null);
                setMessages([]);
            }
        } catch (error) {
            toast.error("Oturum kapatılamadı");
        }
    };

    const reopenSession = async (sessionId: string) => {
        try {
            await supportAPI.reopenSession(sessionId);
            toast.success("Oturum yeniden açıldı");
            loadSessions();
        } catch (error) {
            toast.error("Oturum açılamadı");
        }
    };

    const formatTime = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now.getTime() - date.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));

        if (days === 0) {
            return date.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
        } else if (days === 1) {
            return "Dün";
        } else if (days < 7) {
            return date.toLocaleDateString("tr-TR", { weekday: "short" });
        } else {
            return date.toLocaleDateString("tr-TR", { day: "numeric", month: "short" });
        }
    };

    const getSelectedSession = () => sessions.find((s) => s.id === selectedSession);
    const totalUnread = sessions.reduce((sum, s) => sum + s.unread_count, 0);

    // Sync unread to parent (badge on sidebar/header)
    useEffect(() => {
        onUnreadChange?.(totalUnread);
    }, [totalUnread, onUnreadChange]);

    // If parent wants to focus a session (from notification dropdown), apply it once.
    useEffect(() => {
        if (!focusSessionId) return;
        // Only focus if we have sessions loaded (avoid racing before loadSessions completes)
        const exists = sessions.some((s) => s.id === focusSessionId);
        if (!exists) return;
        setSelectedSession(focusSessionId);
        selectedSessionRef.current = focusSessionId;
        loadMessages(focusSessionId);
        onFocusApplied?.();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [focusSessionId, sessions]);

    return (
        <div className="h-[calc(100vh-200px)] min-h-[600px] flex flex-col">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <MessageCircle className="w-6 h-6 text-primary" />
                    <h2 className="text-xl font-bold">Canlı Destek</h2>
                    {totalUnread > 0 && (
                        <Badge variant="destructive">{totalUnread} yeni mesaj</Badge>
                    )}
                    {isConnecting && (
                        <Badge variant="secondary" className="gap-1">
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Bağlanıyor
                        </Badge>
                    )}
                </div>
                <Button variant="outline" size="sm" onClick={loadSessions}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Yenile
                </Button>
            </div>

            <div className="flex-1 border rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-3">
                {/* Sessions List */}
                <div className="border-r bg-muted/30 flex flex-col">
                    <Tabs value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)} className="w-full">
                        <TabsList className="w-full rounded-none border-b">
                            <TabsTrigger value="active" className="flex-1 gap-2">
                                <Circle className="w-3 h-3 fill-green-500 text-green-500" />
                                Aktif
                            </TabsTrigger>
                            <TabsTrigger value="closed" className="flex-1 gap-2">
                                <Archive className="w-3 h-3" />
                                Kapanan
                            </TabsTrigger>
                        </TabsList>
                    </Tabs>

                    <ScrollArea className="flex-1">
                        {isLoading ? (
                            <div className="flex items-center justify-center h-32">
                                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                            </div>
                        ) : sessions.length === 0 ? (
                            <div className="p-8 text-center text-muted-foreground">
                                <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                                <p>Henüz destek talebi yok</p>
                            </div>
                        ) : (
                            <div className="p-2 space-y-1">
                                {sessions.map((session) => (
                                    <button
                                        key={session.id}
                                        onClick={() => selectSession(session.id)}
                                        className={cn(
                                            "w-full p-3 rounded-lg transition-colors text-left relative group",
                                            selectedSession === session.id
                                                ? "bg-primary/10 border border-primary/20"
                                                : "hover:bg-accent"
                                        )}
                                    >
                                        <div className="flex items-start gap-3">
                                            <div className="relative">
                                                <Avatar>
                                                    <AvatarFallback className="bg-primary/10 text-primary">
                                                        {session.user_name.charAt(0).toUpperCase()}
                                                    </AvatarFallback>
                                                </Avatar>
                                                {session.is_online && (
                                                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                                                )}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center justify-between">
                                                    <span className="font-medium truncate">{session.user_name}</span>
                                                    <span className="text-xs text-muted-foreground">
                                                        {formatTime(session.last_message_at)}
                                                    </span>
                                                </div>
                                                <p className="text-sm text-muted-foreground truncate">
                                                    {typingUsers[session.id] ? (
                                                        <span className="text-primary italic">Yazıyor...</span>
                                                    ) : (
                                                        session.last_message_preview || "Yeni sohbet"
                                                    )}
                                                </p>
                                                <p className="text-xs text-muted-foreground/70 truncate">
                                                    {session.user_email}
                                                </p>
                                            </div>
                                            {session.unread_count > 0 && (
                                                <Badge variant="destructive" className="ml-2">
                                                    {session.unread_count}
                                                </Badge>
                                            )}
                                        </div>
                                    </button>
                                ))}
                            </div>
                        )}
                    </ScrollArea>
                </div>

                {/* Chat Area */}
                <div className="lg:col-span-2 flex flex-col">
                    {selectedSession ? (
                        <>
                            {/* Chat Header */}
                            <div className="p-4 border-b flex items-center justify-between bg-muted/30">
                                <div className="flex items-center gap-3">
                                    <Avatar>
                                        <AvatarFallback className="bg-primary/10 text-primary">
                                            {getSelectedSession()?.user_name.charAt(0).toUpperCase()}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <h3 className="font-medium">{getSelectedSession()?.user_name}</h3>
                                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                                            <span>{getSelectedSession()?.user_email}</span>
                                            {getSelectedSession()?.is_online && (
                                                <span className="text-green-600">• Çevrimiçi</span>
                                            )}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    {getSelectedSession()?.status === "active" ? (
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => closeSession(selectedSession)}
                                            className="text-destructive"
                                        >
                                            <X className="w-4 h-4 mr-1" />
                                            Kapat
                                        </Button>
                                    ) : (
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => reopenSession(selectedSession)}
                                        >
                                            <RotateCcw className="w-4 h-4 mr-1" />
                                            Yeniden Aç
                                        </Button>
                                    )}
                                </div>
                            </div>

                            {/* Messages */}
                            <ScrollArea className="flex-1 p-4">
                                {isLoadingMessages ? (
                                    <div className="flex items-center justify-center h-full">
                                        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                                    </div>
                                ) : (
                                    <div className="space-y-3">
                                        {messages.map((msg) => (
                                            <div
                                                key={msg.id}
                                                className={cn(
                                                    "flex gap-2",
                                                    msg.sender_type === "admin" ? "justify-end" : "justify-start"
                                                )}
                                            >
                                                {msg.sender_type !== "admin" && (
                                                    <Avatar className="w-8 h-8">
                                                        <AvatarFallback className={cn(
                                                            "text-xs",
                                                            msg.sender_type === "system" ? "bg-muted" : "bg-blue-100 text-blue-700"
                                                        )}>
                                                            {msg.sender_type === "system" ? "S" : msg.sender_name.charAt(0)}
                                                        </AvatarFallback>
                                                    </Avatar>
                                                )}
                                                <div
                                                    className={cn(
                                                        "max-w-[70%] rounded-2xl px-4 py-2 text-sm",
                                                        msg.sender_type === "admin"
                                                            ? "bg-primary text-primary-foreground rounded-br-md"
                                                            : msg.sender_type === "system"
                                                                ? "bg-muted text-muted-foreground rounded-bl-md"
                                                                : "bg-secondary rounded-bl-md"
                                                    )}
                                                >
                                                    {msg.sender_type !== "admin" && msg.sender_type !== "system" && (
                                                        <p className="text-xs font-medium mb-1 opacity-70">{msg.sender_name}</p>
                                                    )}
                                                    <p>{msg.content}</p>
                                                    <div className="flex items-center gap-1 justify-end mt-1">
                                                        <span className="text-[10px] opacity-70">
                                                            {formatTime(msg.created_at)}
                                                        </span>
                                                        {msg.sender_type === "admin" && (
                                                            msg.is_read ? (
                                                                <CheckCheck className="w-3 h-3 opacity-70" />
                                                            ) : (
                                                                <Check className="w-3 h-3 opacity-70" />
                                                            )
                                                        )}
                                                    </div>
                                                </div>
                                                {msg.sender_type === "admin" && (
                                                    <Avatar className="w-8 h-8">
                                                        <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                                                            A
                                                        </AvatarFallback>
                                                    </Avatar>
                                                )}
                                            </div>
                                        ))}

                                        {/* Typing indicator */}
                                        {typingUsers[selectedSession] && (
                                            <div className="flex items-center gap-2">
                                                <Avatar className="w-8 h-8">
                                                    <AvatarFallback className="bg-blue-100 text-blue-700 text-xs">
                                                        {getSelectedSession()?.user_name.charAt(0)}
                                                    </AvatarFallback>
                                                </Avatar>
                                                <div className="bg-secondary rounded-2xl rounded-bl-md px-4 py-2">
                                                    <div className="flex gap-1">
                                                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                                                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                                                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                                                    </div>
                                                </div>
                                            </div>
                                        )}

                                        <div ref={messagesEndRef} />
                                    </div>
                                )}
                            </ScrollArea>

                            {/* Input */}
                            {getSelectedSession()?.status === "active" ? (
                                <div className="p-4 border-t">
                                    <form
                                        onSubmit={(e) => {
                                            e.preventDefault();
                                            sendMessage();
                                        }}
                                        className="flex gap-2"
                                    >
                                        <Input
                                            value={newMessage}
                                            onChange={(e) => handleTyping(e.target.value)}
                                            placeholder="Yanıtınızı yazın..."
                                            className="flex-1"
                                        />
                                        <Button type="submit" disabled={!newMessage.trim()}>
                                            <Send className="w-4 h-4 mr-2" />
                                            Gönder
                                        </Button>
                                    </form>
                                </div>
                            ) : (
                                <div className="p-4 border-t bg-muted/50 text-center">
                                    <p className="text-sm text-muted-foreground">Bu oturum kapatılmış</p>
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="flex-1 flex items-center justify-center text-muted-foreground">
                            <div className="text-center">
                                <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-30" />
                                <p className="text-lg font-medium">Bir görüşme seçin</p>
                                <p className="text-sm">Sol taraftan bir kullanıcı seçerek sohbete başlayın</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
