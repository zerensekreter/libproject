import { Edit, Trash2, Ban, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface User {
    id: string;
    name: string;
    email: string;
    studentId: string;
    department: string;
    avatar: string;
    role: 'student' | 'faculty' | 'admin';
    joinDate: string;
    borrowedBooks: number;
    maxBooks: number;
    is_verified: boolean;
}

interface UsersTableProps {
    users: User[];
    onEdit: (user: User) => void;
    onApprove?: (userId: string) => void;
}

export function UsersTable({ users, onEdit }: UsersTableProps) {
    const getRoleBadge = (role: string) => {
        const variants: Record<string, any> = {
            admin: 'destructive',
            faculty: 'default',
            student: 'secondary'
        };
        const labels: Record<string, string> = {
            admin: 'Admin',
            faculty: 'Öğretim Üyesi',
            student: 'Öğrenci'
        };
        return <Badge variant={variants[role]}>{labels[role]}</Badge>;
    };

    return (
        <div className="rounded-md border">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Kullan</TableHead>
                        <TableHead>Öğrenci No</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Bölüm</TableHead>
                        <TableHead>Rol</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead>Ödünç</TableHead>
                        <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {users.map((user) => (
                        <TableRow key={user.id}>
                            <TableCell>
                                <div className="flex items-center gap-3">
                                    <Avatar className="h-8 w-8">
                                        <AvatarImage src={user.avatar} alt={user.name} />
                                        <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <div className="font-medium">{user.name}</div>
                                        <div className="text-xs text-muted-foreground">{new Date(user.joinDate).toLocaleDateString('tr-TR')}</div>
                                    </div>
                                </div>
                            </TableCell>
                            <TableCell className="font-mono text-sm">{user.studentId}</TableCell>
                            <TableCell className="text-sm">{user.email}</TableCell>
                            <TableCell>{user.department}</TableCell>
                            <TableCell>{getRoleBadge(user.role)}</TableCell>
                            <TableCell>
                                {user.is_verified ? (
                                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 gap-1"><CheckCircle className="w-3 h-3"/> Onaylı</Badge>
                                ) : (
                                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Bekliyor</Badge>
                                )}
                            </TableCell>
                            <TableCell>
                                <span className={user.borrowedBooks >= user.maxBooks ? 'text-destructive font-medium' : ''}>
                                    {user.borrowedBooks} / {user.maxBooks}
                                </span>
                            </TableCell>
                            <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                    {!user.is_verified && onApprove && (
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => onApprove(user.id)}
                                            className="text-green-600 hover:text-green-700 hover:bg-green-50 border-green-200"
                                            title="Hesabı Onayla"
                                        >
                                            <CheckCircle className="h-4 w-4 mr-1" /> Onayla
                                        </Button>
                                    )}
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => onEdit(user)}
                                    >
                                        <Edit className="h-4 w-4" />
                                    </Button>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        className="text-destructive hover:text-destructive"
                                    >
                                        <Ban className="h-4 w-4" />
                                    </Button>
                                </div>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}
