import { useState, useEffect } from "react";
import { Search, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface UserFormDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    user?: any;
}

export function UserFormDialog({ open, onOpenChange, user }: UserFormDialogProps) {
    const [loading, setLoading] = useState(false);
    const [autoFilling, setAutoFilling] = useState(false);
    const [formData, setFormData] = useState({
        studentId: "",
        fullName: "",
        email: "",
        department: "",
        role: "student",
    });

    useEffect(() => {
        if (user) {
            setFormData({
                studentId: user.studentId || "",
                fullName: user.name || "",
                email: user.email || "",
                department: user.department || "",
                role: user.role || "student",
            });
        } else {
            setFormData({
                studentId: "",
                fullName: "",
                email: "",
                department: "",
                role: "student",
            });
        }
    }, [user]);

    // Otomatik bilgi çekme - Öğrenci no girildiğinde
    const handleStudentIdBlur = async () => {
        if (formData.studentId.length < 5) return;

        setAutoFilling(true);
        try {
            // TODO: Backend API'den kullanıcı bilgilerini çek
            // Şimdilik mock veri
            await new Promise(resolve => setTimeout(resolve, 800));

            // Örnek: Üniversite sisteminden otomatik çekilen bilgiler
            const mockUserData = {
                fullName: "Ahmet Yılmaz",
                email: `${formData.studentId}@university.edu.tr`,
                department: "Bilgisayar Mühendisliği",
            };

            setFormData(prev => ({
                ...prev,
                ...mockUserData
            }));

            toast.success("Kullanıcı bilgileri otomatik dolduruldu!");
        } catch (error) {
            toast.error("Kullanıcı bilgileri getirilemedi");
        } finally {
            setAutoFilling(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            // TODO: Backend API'ye kaydet
            await new Promise(resolve => setTimeout(resolve, 1000));

            toast.success(user ? "Kullanıcı güncellendi!" : "Kullanıcı eklendi!");
            onOpenChange(false);
        } catch (error) {
            toast.error("Bir hata oluştu");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle>{user ? "Kullanıcı Düzenle" : "Yeni Kullanıcı Ekle"}</DialogTitle>
                    <DialogDescription>
                        {user ? "Kullanıcı bilgilerini güncelleyin" : "Öğrenci no girildiğinde bilgiler otomatik doldurulacak"}
                    </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleSubmit}>
                    <div className="space-y-4 py-4">
                        {/* Öğrenci No - Otomatik Doldurma */}
                        <div className="space-y-2">
                            <Label htmlFor="studentId">
                                Öğrenci / Personel No *
                                {autoFilling && <Loader2 className="inline ml-2 h-3 w-3 animate-spin" />}
                            </Label>
                            <div className="relative">
                                <Input
                                    id="studentId"
                                    placeholder="20210100001"
                                    value={formData.studentId}
                                    onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                                    onBlur={handleStudentIdBlur}
                                    disabled={loading || autoFilling}
                                    required
                                />
                                {autoFilling && (
                                    <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                                    </div>
                                )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                                Öğrenci numarasını girin ve otomatik bilgi doldurma için bekleyin
                            </p>
                        </div>

                        {/* Ad Soyad */}
                        <div className="space-y-2">
                            <Label htmlFor="fullName">Ad Soyad *</Label>
                            <Input
                                id="fullName"
                                placeholder="Ahmet Yılmaz"
                                value={formData.fullName}
                                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                                disabled={loading}
                                required
                            />
                        </div>

                        {/* Email */}
                        <div className="space-y-2">
                            <Label htmlFor="email">Email *</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="ahmet@university.edu.tr"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                disabled={loading}
                                required
                            />
                        </div>

                        {/* Bölüm */}
                        <div className="space-y-2">
                            <Label htmlFor="department">Bölüm *</Label>
                            <Input
                                id="department"
                                placeholder="Bilgisayar Mühendisliği"
                                value={formData.department}
                                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                                disabled={loading}
                                required
                            />
                        </div>

                        {/* Rol */}
                        <div className="space-y-2">
                            <Label htmlFor="role">Rol *</Label>
                            <Select
                                value={formData.role}
                                onValueChange={(value) => setFormData({ ...formData, role: value })}
                                disabled={loading}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="student">Öğrenci</SelectItem>
                                    <SelectItem value="faculty">Öğretim Üyesi</SelectItem>
                                    <SelectItem value="admin">Admin</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                            İptal
                        </Button>
                        <Button type="submit" disabled={loading}>
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {user ? "Güncelle" : "Ekle"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
