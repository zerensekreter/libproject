import { useState } from "react";
import { motion } from "framer-motion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ConfirmModal } from "@/components/shared/ConfirmModal";
import { BookFormDialog } from "./BookFormDialog";
import {
  Search,
  Plus,
  Edit,
  Trash2,
  MoreHorizontal,
  Eye,
  BookCopy,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { mockBooks, type Book } from "@/data/mockData";
import { toast } from "sonner";

export function BooksTable() {
  const [books, setBooks] = useState<Book[]>(mockBooks);
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteModal, setDeleteModal] = useState<{ open: boolean; book: Book | null }>({
    open: false,
    book: null,
  });
  const [bookFormDialog, setBookFormDialog] = useState<{ open: boolean; book: Book | null }>({
    open: false,
    book: null,
  });

  const filteredBooks = books.filter(
    (book) =>
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery)
  );

  const handleDelete = (book: Book) => {
    setDeleteModal({ open: true, book });
  };

  const confirmDelete = () => {
    if (!deleteModal.book) return;

    setBooks((prev) => prev.filter((b) => b.id !== deleteModal.book!.id));

    toast.success("Kitap Silindi", {
      description: `"${deleteModal.book.title}" kitabı başarıyla silindi.`,
    });

    setDeleteModal({ open: false, book: null });
  };

  const handleAddBook = () => {
    setBookFormDialog({ open: true, book: null });
  };

  const handleEditBook = (book: Book) => {
    setBookFormDialog({ open: true, book });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Kitap adı, yazar veya ISBN ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button onClick={handleAddBook} className="gap-2">
          <Plus className="h-4 w-4" />
          Yeni Kitap
        </Button>
      </div>

      {/* Table */}
      <div className="border border-border rounded-xl overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-[80px]">Kapak</TableHead>
              <TableHead>Kitap Adı</TableHead>
              <TableHead>Yazar</TableHead>
              <TableHead>Kategori</TableHead>
              <TableHead>Konum</TableHead>
              <TableHead>Durum</TableHead>
              <TableHead className="text-right">İşlemler</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredBooks.map((book, index) => (
              <motion.tr
                key={book.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: index * 0.03 }}
                className="border-b border-border hover:bg-muted/30 transition-colors"
              >
                <TableCell>
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-12 h-16 object-cover rounded-md shadow-sm"
                  />
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium line-clamp-1">{book.title}</p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {book.isbn}
                    </p>
                  </div>
                </TableCell>
                <TableCell>{book.author}</TableCell>
                <TableCell>
                  <Badge variant="secondary">{book.category}</Badge>
                </TableCell>
                <TableCell className="font-mono text-sm">{book.location}</TableCell>
                <TableCell>
                  {book.availableCopies > 0 ? (
                    <Badge variant="default" className="bg-success hover:bg-success/90">
                      {book.availableCopies}/{book.totalCopies}
                    </Badge>
                  ) : (
                    <Badge variant="destructive">Tükendi</Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">İşlemler</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        Görüntüle
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEditBook(book)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Düzenle
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <BookCopy className="h-4 w-4 mr-2" />
                        Kopya Ekle
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => handleDelete(book)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Sil
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
        <span>Toplam: <strong className="text-foreground">{books.length}</strong> kitap</span>
        <span>Mevcut: <strong className="text-foreground">{books.filter(b => b.availableCopies > 0).length}</strong></span>
        <span>Tükenen: <strong className="text-destructive">{books.filter(b => b.availableCopies === 0).length}</strong></span>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        open={deleteModal.open}
        onOpenChange={(open) => setDeleteModal({ open, book: deleteModal.book })}
        title="Kitabı Sil"
        description={`"${deleteModal.book?.title}" kitabını silmek istediğinize emin misiniz? Bu işlem geri alınamaz.`}
        variant="destructive"
        confirmText="Sil"
        onConfirm={confirmDelete}
      />

      {/* Book Form Dialog */}
      <BookFormDialog
        open={bookFormDialog.open}
        onOpenChange={(open) => setBookFormDialog({ open, book: null })}
        book={bookFormDialog.book}
      />
    </div>
  );
}
