import { useState } from "react";
import { motion } from "framer-motion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ConfirmModal } from "@/components/shared/ConfirmModal";
import { TableRowSkeleton } from "@/components/shared/SkeletonCard";
import {
  Search,
  RotateCcw,
  AlertCircle,
  CheckCircle2,
  Clock,
  MoreHorizontal,
  Eye,
  Bell,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { mockLoans, type Loan } from "@/data/mockData";
import { toast } from "sonner";

const statusConfig = {
  active: { label: "Aktif", variant: "default" as const, icon: Clock },
  returned: { label: "İade Edildi", variant: "secondary" as const, icon: CheckCircle2 },
  overdue: { label: "Gecikmiş", variant: "destructive" as const, icon: AlertCircle },
};

export function AdminLoansPanel() {
  const [loans, setLoans] = useState<Loan[]>(mockLoans);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [returnModal, setReturnModal] = useState<{ open: boolean; loan: Loan | null }>({
    open: false,
    loan: null,
  });

  const filteredLoans = loans.filter((loan) => {
    const matchesSearch =
      loan.bookTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loan.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loan.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || loan.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const handleReturn = (loan: Loan) => {
    setReturnModal({ open: true, loan });
  };

  const confirmReturn = () => {
    if (!returnModal.loan) return;
    
    setLoans((prev) =>
      prev.map((l) =>
        l.id === returnModal.loan!.id
          ? { ...l, status: "returned" as const, returnDate: new Date().toISOString().split("T")[0] }
          : l
      )
    );
    
    toast.success("İade İşlemi Başarılı", {
      description: `"${returnModal.loan.bookTitle}" kitabı iade edildi.`,
    });
    
    setReturnModal({ open: false, loan: null });
  };

  const sendReminder = (loan: Loan) => {
    toast.info("Hatırlatma Gönderildi", {
      description: `${loan.userName} kullanıcısına hatırlatma e-postası gönderildi.`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Kitap, kullanıcı veya ID ile ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Durum filtrele" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tüm Durumlar</SelectItem>
            <SelectItem value="active">Aktif</SelectItem>
            <SelectItem value="returned">İade Edildi</SelectItem>
            <SelectItem value="overdue">Gecikmiş</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="border border-border rounded-xl overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>Kitap</TableHead>
              <TableHead>Kullanıcı</TableHead>
              <TableHead>Ödünç Tarihi</TableHead>
              <TableHead>İade Tarihi</TableHead>
              <TableHead>Durum</TableHead>
              <TableHead>Ceza</TableHead>
              <TableHead className="text-right">İşlemler</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => <TableRowSkeleton key={i} />)
            ) : filteredLoans.length > 0 ? (
              filteredLoans.map((loan, index) => {
                const status = statusConfig[loan.status];
                const StatusIcon = status.icon;
                
                return (
                  <motion.tr
                    key={loan.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-border hover:bg-muted/30 transition-colors"
                  >
                    <TableCell className="font-mono text-sm">{loan.id}</TableCell>
                    <TableCell className="font-medium">{loan.bookTitle}</TableCell>
                    <TableCell>{loan.userName}</TableCell>
                    <TableCell>{loan.borrowDate}</TableCell>
                    <TableCell>{loan.dueDate}</TableCell>
                    <TableCell>
                      <Badge variant={status.variant} className="gap-1">
                        <StatusIcon className="h-3 w-3" />
                        {status.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {loan.fine > 0 ? (
                        <span className="text-destructive font-medium">
                          ₺{loan.fine.toFixed(2)}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">İşlemler</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            Detaylar
                          </DropdownMenuItem>
                          {loan.status === "active" && (
                            <DropdownMenuItem onClick={() => handleReturn(loan)}>
                              <RotateCcw className="h-4 w-4 mr-2" />
                              İade Al
                            </DropdownMenuItem>
                          )}
                          {loan.status === "overdue" && (
                            <>
                              <DropdownMenuItem onClick={() => handleReturn(loan)}>
                                <RotateCcw className="h-4 w-4 mr-2" />
                                İade Al
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => sendReminder(loan)}>
                                <Bell className="h-4 w-4 mr-2" />
                                Hatırlatma Gönder
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="h-32 text-center">
                  <div className="text-muted-foreground">
                    <p className="text-lg mb-1">Kayıt Bulunamadı</p>
                    <p className="text-sm">Arama kriterlerinize uygun ödünç kaydı yok.</p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Summary */}
      <div className="flex flex-wrap gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-primary" />
          <span className="text-muted-foreground">
            Aktif: {loans.filter((l) => l.status === "active").length}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-secondary" />
          <span className="text-muted-foreground">
            İade: {loans.filter((l) => l.status === "returned").length}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-destructive" />
          <span className="text-muted-foreground">
            Gecikmiş: {loans.filter((l) => l.status === "overdue").length}
          </span>
        </div>
      </div>

      {/* Return Confirmation Modal */}
      <ConfirmModal
        open={returnModal.open}
        onOpenChange={(open) => setReturnModal({ open, loan: returnModal.loan })}
        title="İade Onayı"
        description={`"${returnModal.loan?.bookTitle}" kitabını iade almak istediğinize emin misiniz?${
          returnModal.loan?.fine ? ` Gecikme cezası: ₺${returnModal.loan.fine.toFixed(2)}` : ""
        }`}
        variant={returnModal.loan?.fine ? "warning" : "success"}
        confirmText="İade Al"
        onConfirm={confirmReturn}
      />
    </div>
  );
}
