import { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockMonthlyStats, mockCategoryDistribution } from "@/data/mockData";

export function LoanTrendsChart() {
  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="mb-6">
        <h3 className="font-display font-semibold text-lg">Ödünç Trendleri</h3>
        <p className="text-sm text-muted-foreground">Aylık ödünç alma ve iade istatistikleri</p>
      </div>
      
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={mockMonthlyStats}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis 
              dataKey="month" 
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
              axisLine={{ stroke: "hsl(var(--border))" }}
            />
            <YAxis 
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
              axisLine={{ stroke: "hsl(var(--border))" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                boxShadow: "var(--shadow-lg)",
              }}
              labelStyle={{ color: "hsl(var(--foreground))" }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="loans"
              name="Ödünç"
              stroke="hsl(222, 91%, 51%)"
              strokeWidth={2}
              dot={{ fill: "hsl(222, 91%, 51%)", strokeWidth: 2 }}
              activeDot={{ r: 6, fill: "hsl(222, 91%, 51%)" }}
            />
            <Line
              type="monotone"
              dataKey="returns"
              name="İade"
              stroke="hsl(158, 67%, 41%)"
              strokeWidth={2}
              dot={{ fill: "hsl(158, 67%, 41%)", strokeWidth: 2 }}
              activeDot={{ r: 6, fill: "hsl(158, 67%, 41%)" }}
            />
            <Line
              type="monotone"
              dataKey="newBooks"
              name="Yeni Kitap"
              stroke="hsl(41, 100%, 56%)"
              strokeWidth={2}
              dot={{ fill: "hsl(41, 100%, 56%)", strokeWidth: 2 }}
              activeDot={{ r: 6, fill: "hsl(41, 100%, 56%)" }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function CategoryDistributionChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(null);
  };

  const total = mockCategoryDistribution.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="mb-6">
        <h3 className="font-display font-semibold text-lg">Kategori Dağılımı</h3>
        <p className="text-sm text-muted-foreground">Kitapların kategorilere göre dağılımı</p>
      </div>

      <div className="flex flex-col lg:flex-row items-center gap-6">
        <div className="h-[250px] w-full lg:w-1/2">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={mockCategoryDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
                onMouseEnter={onPieEnter}
                onMouseLeave={onPieLeave}
              >
                {mockCategoryDistribution.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    opacity={activeIndex === null || activeIndex === index ? 1 : 0.5}
                    style={{ transition: "opacity 0.2s" }}
                  />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                }}
                formatter={(value: number) => [
                  `${value.toLocaleString("tr-TR")} kitap (${((value / total) * 100).toFixed(1)}%)`,
                  "Adet",
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Legend */}
        <div className="flex-1 space-y-2 w-full lg:w-1/2">
          {mockCategoryDistribution.map((item, index) => (
            <div
              key={item.name}
              className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
              onMouseEnter={() => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm font-medium">{item.name}</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-semibold">{item.value.toLocaleString("tr-TR")}</span>
                <span className="text-xs text-muted-foreground ml-2">
                  ({((item.value / total) * 100).toFixed(1)}%)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
