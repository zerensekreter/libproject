import { useState, useEffect } from "react";
import { Search, Plus, UserPlus, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usersAPI } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { UserFormDialog } from "./UserFormDialog";
import { UsersTable } from "./UsersTable";

export function UserManagement() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await usersAPI.getAll({ limit: 100 });
      const mapped = data.map((u: any) => ({
        id: u.id,
        name: u.full_name,
        email: u.email,
        studentId: u.student_id,
        department: u.department || "Belirtilmemiş",
        avatar: "",  
        role: u.role,
        is_verified: u.is_verified,
        joinDate: new Date().toISOString(), 
        borrowedBooks: u.borrowed_books || 0,
        maxBooks: u.max_books || 5
      }));
      setUsers(mapped);
    } catch (error) {
      console.error(error);
      toast({
        title: "Hata",
        description: "Kullanıcılar yüklenirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleApproveUser = async (userId: string) => {
    try {
      await usersAPI.update(userId, { is_verified: true });
      toast({
        title: "Başarılı",
        description: "Kullanıcı hesabı başarıyla onaylandı.",
      });
      fetchUsers(); 
    } catch (error) {
      toast({
        title: "Hata",
        description: "Kullanıcı onaylanırken bir sorun oluştu.",
        variant: "destructive",
      });
    }
  };

  const handleAddUser = () => {
    setEditingUser(null);
    setIsDialogOpen(true);
  };

  const handleEditUser = (user: any) => {
    setEditingUser(user);
    setIsDialogOpen(true);
  };

  const handleDialogClose = (open: boolean) => {
    setIsDialogOpen(open);
    if (!open) {
      fetchUsers(); 
    }
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.studentId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pendingUsers = filteredUsers.filter(u => !u.is_verified);
  const verifiedUsers = filteredUsers.filter(u => u.is_verified);

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle>Kullanıcı Yönetimi</CardTitle>
            <CardDescription>Tüm kullanıcıları görüntüle ve yönet</CardDescription>
          </div>
          <div className="flex gap-2">
             <Button variant="outline" onClick={fetchUsers} disabled={loading} size="icon">
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
             </Button>
            <Button onClick={handleAddUser} className="gap-2">
              <UserPlus className="h-4 w-4" />
              Yeni Kullanıcı
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Ad, email veya öğrenci no ile ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <Tabs defaultValue="pending" className="w-full">
            <TabsList className="mb-4 border-b w-full justify-start rounded-none bg-transparent h-auto p-0">
              <TabsTrigger 
                  value="pending" 
                  className="flex gap-2 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none py-3"
              >
                Onay Bekleyenler
                {pendingUsers.length > 0 && (
                  <span className="bg-primary/20 text-primary px-2 py-0.5 rounded-full text-xs">
                    {pendingUsers.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger 
                  value="all" 
                  className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none py-3"
              >
                 Kayıtlı Kullanıcılar
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="pending" className="m-0 pt-4">
               {pendingUsers.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground border rounded-lg bg-muted/20">
                     Onay bekleyen hesap bulunmuyor. 🎉
                  </div>
               ) : (
                  <UsersTable 
                     users={pendingUsers}  
                     onEdit={handleEditUser}
                     onApprove={handleApproveUser}
                  />
               )}
            </TabsContent>
            
            <TabsContent value="all" className="m-0 pt-4">
               <UsersTable 
                  users={verifiedUsers}  
                  onEdit={handleEditUser}
               />
            </TabsContent>
          </Tabs>
        </div>

        <UserFormDialog
          open={isDialogOpen}
          onOpenChange={handleDialogClose}
          user={editingUser}
        />
      </CardContent>
    </Card>
  );
}
