import { Link } from "react-router-dom";
import { BookOpen, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-sidebar text-sidebar-foreground">
      <div className="container mx-auto py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary">
                <BookOpen className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-display font-bold">Üniversite Kütüphanesi</h3>
              </div>
            </Link>
            <p className="text-sm text-sidebar-foreground/70">
              Bilgiye açılan kapınız. 1950'den beri akademik başarınız için yanınızdayız.
            </p>
            <div className="flex gap-3">
              <a href="#" className="p-2 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary transition-colors" aria-label="Facebook">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary transition-colors" aria-label="Twitter">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary transition-colors" aria-label="Instagram">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary transition-colors" aria-label="LinkedIn">
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold mb-4">Hızlı Bağlantılar</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/books" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Kitap Kataloğu</Link></li>
              <li><Link to="/announcements" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Duyurular</Link></li>
              <li><Link to="/profile" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Hesabım</Link></li>
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">E-Kaynaklar</a></li>
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Çalışma Odaları</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-display font-semibold mb-4">Hizmetler</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Ödünç Alma</a></li>
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Kütüphanelerarası</a></li>
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Araştırma Desteği</a></li>
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">Eğitimler</a></li>
              <li><a href="#" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">SSS</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-semibold mb-4">İletişim</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-sidebar-foreground/70" />
                <span className="text-sidebar-foreground/70">Merkez Kampüs, A Blok<br />İstanbul, Türkiye</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-sidebar-foreground/70" />
                <a href="tel:+902121234567" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">+90 (212) 123 45 67</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-sidebar-foreground/70" />
                <a href="mailto:kutuphane@university.edu.tr" className="text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">kutuphane@university.edu.tr</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-sidebar-border flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-sidebar-foreground/60">
          <p>© 2025 Üniversite Kütüphanesi. Tüm hakları saklıdır.</p>
          <p>© 2025 | Developed by Yusufcan Esener</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-sidebar-foreground transition-colors">Gizlilik Politikası</a>
            <a href="#" className="hover:text-sidebar-foreground transition-colors">Kullanım Koşulları</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
