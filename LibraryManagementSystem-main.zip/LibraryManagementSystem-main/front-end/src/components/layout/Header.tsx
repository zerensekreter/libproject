import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen,
  BookCopy,
  MessageCircle,
  Menu,
  X,
  Search,
  User,
  Bell,
  LogIn,
  LogOut,
  Home,
  Library,
  Megaphone,
  Phone,
  LayoutDashboard,
  Check,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { getUser, getToken, removeToken, notificationsAPI } from "@/lib/api";
import { toast } from "sonner";
import { playNotificationSound, supportAPI } from "@/lib/supportApi";
import { ThemeToggle } from "@/components/theme/ThemeToggle";

const navLinks = [
  { href: "/", label: "Ana Sayfa", icon: Home },
  { href: "/books", label: "Kitaplar", icon: Library },
  { href: "/announcements", label: "Duyurular", icon: Megaphone },
  { href: "/contact", label: "İletişim", icon: Phone },
];

interface Notification {
  id: string;
  announcement_id?: string;
  announcement_title?: string;
  book_id?: string;
  notification_type: string;
  message?: string;
  is_read: boolean;
  created_at: string;
}

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [supportUnread, setSupportUnread] = useState(0);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  const [isNotificationDetailOpen, setIsNotificationDetailOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const token = getToken();
    const storedUser = getUser();
    if (token && storedUser) {
      setUser(storedUser);
      fetchNotifications();
    }
  }, [location.pathname]);

  // Admin support unread (on non-admin pages): poll to keep badge + sound
  useEffect(() => {
    const token = getToken();
    const storedUser = getUser();
    if (!token || storedUser?.role !== "admin") return;

    let prev = 0;
    const tick = async () => {
      try {
        const d = await supportAPI.getAdminUnreadCount();
        const next = d.unread_count || 0;
        if (next > prev) {
          playNotificationSound();
          toast.info("Yeni destek mesajı", { description: "Admin panelinden yanıtlayabilirsiniz." });
        }
        prev = next;
        setSupportUnread(next);
      } catch {
        // ignore
      }
    };

    tick();
    const interval = setInterval(tick, 5000);
    return () => clearInterval(interval);
  }, []);

  // Polling for real-time notifications (every 30 seconds)
  useEffect(() => {
    const token = getToken();
    if (!token) return;

    const pollInterval = setInterval(() => {
      fetchNotifications();
    }, 5000); // 5 seconds for real-time feel

    return () => clearInterval(pollInterval);
  }, []);

  const fetchNotifications = async () => {
    try {
      const [notifs, countData] = await Promise.all([
        notificationsAPI.getAll(),
        notificationsAPI.getUnreadCount()
      ]);
      setNotifications(notifs);
      setUnreadCount(countData.count);
    } catch (error) {
      console.error("Failed to fetch notifications:", error);
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await notificationsAPI.markAsRead(notificationId);
      setNotifications(prev => prev.map(n =>
        n.id === notificationId ? { ...n, is_read: true } : n
      ));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Failed to mark as read:", error);
    }
  };

  const openNotificationDetail = async (notif: Notification) => {
    setSelectedNotification(notif);
    setIsNotificationDetailOpen(true);
    // Mark as read as soon as user opens it (best UX)
    if (!notif.is_read) {
      await handleMarkAsRead(notif.id);
    }
  };

  const selectNotificationByIndex = (idx: number) => {
    if (idx < 0 || idx >= notifications.length) return;
    openNotificationDetail(notifications[idx]);
  };

  const getSelectedIndex = () => {
    if (!selectedNotification) return -1;
    return notifications.findIndex((n) => n.id === selectedNotification.id);
  };

  const closeNotificationDetail = () => {
    setIsNotificationDetailOpen(false);
    setSelectedNotification(null);
  };

  // Keyboard navigation inside notification detail dialog
  useEffect(() => {
    if (!isNotificationDetailOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      // Support both arrow keys and Vim-like shortcuts (j/k)
      const idx = getSelectedIndex();
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        if (idx > 0) selectNotificationByIndex(idx - 1);
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        if (idx >= 0 && idx < notifications.length - 1) selectNotificationByIndex(idx + 1);
      } else if (e.key === "k") {
        e.preventDefault();
        if (idx > 0) selectNotificationByIndex(idx - 1);
      } else if (e.key === "j") {
        e.preventDefault();
        if (idx >= 0 && idx < notifications.length - 1) selectNotificationByIndex(idx + 1);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNotificationDetailOpen, selectedNotification, notifications]);

  const handleMarkAllAsRead = async () => {
    try {
      await notificationsAPI.markAllAsRead();
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
      toast.success("Tüm bildirimler okundu olarak işaretlendi");
    } catch (error) {
      console.error("Failed to mark all as read:", error);
    }
  };

  const handleDismissNotification = (e: React.MouseEvent, notificationId: string) => {
    e.stopPropagation();
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
    // Update unread count if dismissed notification was unread
    const dismissedNotif = notifications.find(n => n.id === notificationId);
    if (dismissedNotif && !dismissedNotif.is_read) {
      setUnreadCount(prev => Math.max(0, prev - 1));
    }
  };

  const isActive = (path: string) => location.pathname === path;
  const isLoggedIn = !!user;
  const totalBadgeCount = unreadCount + (user?.role === "admin" ? supportUnread : 0);

  const handleLogout = () => {
    removeToken();
    setUser(null);
    setNotifications([]);
    setUnreadCount(0);
    toast.success("Çıkış yapıldı");
    navigate("/");
  };

  const handleSearch = () => {
    navigate("/books");
  };

  return (
    <header className="sticky top-0 z-50 w-full glass-effect shadow-card">
      <div className="container mx-auto">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary shadow-md group-hover:shadow-glow transition-shadow">
              <BookOpen className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="hidden sm:block">
              <h1 className="font-display text-lg font-bold text-foreground">
                Üniversite
              </h1>
              <p className="text-xs text-muted-foreground -mt-1">Kütüphanesi</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                  isActive(link.href)
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                <link.icon className="h-4 w-4" />
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              className="hidden sm:flex"
              aria-label="Arama"
              onClick={handleSearch}
            >
              <Search className="h-5 w-5" />
            </Button>

            {isLoggedIn ? (
              <>
                {/* Notification Bell */}
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative hidden sm:flex"
                    onClick={() => setShowNotifications(!showNotifications)}
                  >
                    <Bell className="h-5 w-5" />
                    {totalBadgeCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-destructive">
                        {totalBadgeCount > 9 ? "9+" : totalBadgeCount}
                      </Badge>
                    )}
                  </Button>

                  {/* Notification Dropdown */}
                  <AnimatePresence>
                    {showNotifications && (
                      <>
                        <div
                          className="fixed inset-0 z-40"
                          onClick={() => setShowNotifications(false)}
                        />
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="absolute right-0 mt-2 w-80 bg-card rounded-lg shadow-xl border border-border z-50 overflow-hidden"
                        >
                          <div className="flex items-center justify-between p-3 border-b border-border">
                            <h3 className="font-semibold">Bildirimler</h3>
                            {unreadCount > 0 && (
                              <Button variant="ghost" size="sm" onClick={handleMarkAllAsRead} className="text-xs h-7">
                                <Check className="h-3 w-3 mr-1" /> Tümünü oku
                              </Button>
                            )}
                          </div>
                          <div className="max-h-72 overflow-y-auto">
                            {/* Support shortcut for admins */}
                            {user?.role === "admin" && (
                              <button
                                className={cn(
                                  "w-full text-left p-3 border-b border-border hover:bg-muted/50 transition-colors",
                                  supportUnread > 0 && "bg-primary/5"
                                )}
                                onClick={() => {
                                  setShowNotifications(false);
                                  navigate("/admin");
                                }}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <MessageCircle className="h-4 w-4 text-primary" />
                                    <span className="text-sm font-medium">Canlı Destek</span>
                                  </div>
                                  {supportUnread > 0 && (
                                    <Badge variant="destructive" className="text-xs">
                                      {supportUnread > 9 ? "9+" : supportUnread}
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">Yeni mesajları görüntülemek için admin paneli aç</p>
                              </button>
                            )}

                            {notifications.length === 0 ? (
                              <div className="p-4 text-center text-muted-foreground text-sm">
                                Henüz bildirim yok
                              </div>
                            ) : (
                              notifications.map((notif) => (
                                <div
                                  key={notif.id}
                                  className={cn(
                                    "p-3 border-b border-border last:border-0 cursor-pointer hover:bg-muted/50 transition-colors relative group",
                                    !notif.is_read && "bg-primary/5"
                                  )}
                                  onClick={() => {
                                    openNotificationDetail(notif);
                                    setShowNotifications(false);
                                  }}
                                >
                                  {/* Dismiss Button - Always Visible */}
                                  <button
                                    onClick={(e) => handleDismissNotification(e, notif.id)}
                                    className="absolute top-2 right-2 p-1 rounded-md hover:bg-destructive/20 transition-all text-muted-foreground hover:text-destructive"
                                    aria-label="Bildirimi kapat"
                                  >
                                    <X className="h-3.5 w-3.5" />
                                  </button>
                                  <div className="flex items-start gap-2 pr-6">
                                    {notif.notification_type === "borrow_request" ? (
                                      <BookCopy className={cn("h-4 w-4 mt-0.5 flex-shrink-0", !notif.is_read && "text-success")} />
                                    ) : (
                                      <Megaphone className={cn("h-4 w-4 mt-0.5 flex-shrink-0", !notif.is_read && "text-primary")} />
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <p className={cn("text-sm truncate", !notif.is_read && "font-medium")}>
                                        {notif.message || notif.announcement_title || "Bildirim"}
                                      </p>
                                      <p className="text-xs text-muted-foreground">
                                        {new Date(notif.created_at).toLocaleDateString("tr-TR")}
                                      </p>
                                    </div>
                                    {!notif.is_read && (
                                      <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                                    )}
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
                {/* Notification Detail Dialog (large readable area) */}
                <Dialog open={isNotificationDetailOpen} onOpenChange={(open) => (open ? null : closeNotificationDetail())}>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        {selectedNotification?.notification_type === "borrow_request" ? (
                          <>
                            <BookCopy className="h-5 w-5 text-success" />
                            Ödünç İşlemi Bildirimi
                          </>
                        ) : selectedNotification?.notification_type === "support" ? (
                          <>
                            <MessageCircle className="h-5 w-5 text-primary" />
                            Canlı Destek Bildirimi
                          </>
                        ) : (
                          <>
                            <Megaphone className="h-5 w-5 text-primary" />
                            Duyuru Bildirimi
                          </>
                        )}
                      </DialogTitle>
                      <DialogDescription>
                        {selectedNotification?.created_at
                          ? new Date(selectedNotification.created_at).toLocaleString("tr-TR")
                          : ""}
                      </DialogDescription>
                    </DialogHeader>

                    <div className="rounded-lg border border-border bg-muted/30 p-4 max-h-[60vh] overflow-y-auto">
                      <div className="text-sm leading-relaxed whitespace-pre-line break-words">
                        {selectedNotification?.message || selectedNotification?.announcement_title || "Bildirim içeriği bulunamadı."}
                      </div>
                    </div>

                    <DialogFooter>
                      <div className="flex w-full items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={getSelectedIndex() <= 0}
                            onClick={() => selectNotificationByIndex(getSelectedIndex() - 1)}
                            title="Önceki (← / k)"
                          >
                            <ChevronLeft className="h-4 w-4 mr-1" /> Önceki
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={getSelectedIndex() < 0 || getSelectedIndex() >= notifications.length - 1}
                            onClick={() => selectNotificationByIndex(getSelectedIndex() + 1)}
                            title="Sonraki (→ / j)"
                          >
                            Sonraki <ChevronRight className="h-4 w-4 ml-1" />
                          </Button>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* Context-aware CTAs */}
                          {selectedNotification?.notification_type === "borrow_request" && selectedNotification?.book_id && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                closeNotificationDetail();
                                navigate(`/books/${selectedNotification.book_id}`);
                              }}
                            >
                              Kitaba Git
                            </Button>
                          )}
                          {selectedNotification?.notification_type === "borrow_request" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                closeNotificationDetail();
                                navigate("/profile");
                              }}
                            >
                              Profilde Gör
                            </Button>
                          )}
                          {selectedNotification?.notification_type === "announcement" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                closeNotificationDetail();
                                navigate("/announcements");
                              }}
                            >
                              Duyurulara Git
                            </Button>
                          )}
                          <Button size="sm" onClick={closeNotificationDetail}>Kapat</Button>
                        </div>
                      </div>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {user?.role === "admin" && (
                  <Link to="/admin" className="hidden sm:block">
                    <Button variant="outline" size="sm" className="gap-2 border-primary/50 text-primary hover:bg-primary/10">
                      <LayoutDashboard className="h-4 w-4" />
                      Admin Panel
                    </Button>
                  </Link>
                )}
                <Link to="/profile" className="hidden sm:block">
                  <Button variant="ghost" size="sm" className="gap-2">
                    <User className="h-4 w-4" />
                    <span className="max-w-24 truncate">{user?.full_name?.split(' ')[0] || 'Profil'}</span>
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  size="icon"
                  className="hidden sm:flex text-destructive hover:text-destructive"
                  onClick={handleLogout}
                  aria-label="Çıkış"
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </>
            ) : (
              <Link to="/auth">
                <Button variant="hero" size="sm" className="hidden sm:flex gap-2">
                  <LogIn className="h-4 w-4" />
                  Giriş
                </Button>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? "Menüyü kapat" : "Menüyü aç"}
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setIsMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed top-0 right-0 h-full w-72 bg-card shadow-xl z-50 md:hidden"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <span className="font-display font-semibold">Menü</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsMobileMenuOpen(false)}
                    aria-label="Menüyü kapat"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
                <nav className="flex-1 p-4 space-y-1">
                  {navLinks.map((link) => (
                    <Link
                      key={link.href}
                      to={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={cn(
                        "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all",
                        isActive(link.href)
                          ? "bg-primary/10 text-primary"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      )}
                    >
                      <link.icon className="h-5 w-5" />
                      {link.label}
                    </Link>
                  ))}
                </nav>
                <div className="p-4 border-t border-border space-y-2">
                  {isLoggedIn ? (
                    <>
                      {/* Mobile Notifications */}
                      {unreadCount > 0 && (
                        <Link to="/announcements" onClick={() => setIsMobileMenuOpen(false)}>
                          <Button variant="outline" className="w-full justify-start gap-2">
                            <Bell className="h-4 w-4" />
                            Bildirimler
                            <Badge className="ml-auto" variant="destructive">{unreadCount}</Badge>
                          </Button>
                        </Link>
                      )}
                      {user?.role === "admin" && (
                        <Link to="/admin" onClick={() => setIsMobileMenuOpen(false)}>
                          <Button variant="outline" className="w-full justify-start gap-2 border-primary/50 text-primary">
                            <LayoutDashboard className="h-4 w-4" />
                            Admin Panel
                          </Button>
                        </Link>
                      )}
                      <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)}>
                        <Button variant="outline" className="w-full justify-start gap-2">
                          <User className="h-4 w-4" />
                          {user?.full_name || 'Profilim'}
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        className="w-full justify-start gap-2 text-destructive hover:text-destructive"
                        onClick={() => {
                          handleLogout();
                          setIsMobileMenuOpen(false);
                        }}
                      >
                        <LogOut className="h-4 w-4" />
                        Çıkış Yap
                      </Button>
                    </>
                  ) : (
                    <Link to="/auth" onClick={() => setIsMobileMenuOpen(false)}>
                      <Button variant="hero" className="w-full justify-start gap-2">
                        <LogIn className="h-4 w-4" />
                        Giriş Yap
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
