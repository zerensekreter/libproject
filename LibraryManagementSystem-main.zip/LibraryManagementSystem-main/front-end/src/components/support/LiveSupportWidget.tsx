import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
    MessageCircle,
    X,
    Send,
    LogIn,
    Loader2,
    Check,
    CheckCheck,
    History,
    ChevronLeft,
    Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { eventsAPI, getToken, getUser, recommendationsAPI } from "@/lib/api";
import {
    supportAPI,
    SupportSession,
    ChatMessage,
    playNotificationSound
} from "@/lib/supportApi";
import { toast } from "sonner";

export function LiveSupportWidget() {
    const [isOpen, setIsOpen] = useState(false);
    const [showHistory, setShowHistory] = useState(false);
    const [mode, setMode] = useState<"ai" | "support">("ai");
    const [session, setSession] = useState<SupportSession | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [newMessage, setNewMessage] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const [isAdminOnline, setIsAdminOnline] = useState(false);
    const [isTyping, setIsTyping] = useState(false);
    const [unreadCount, setUnreadCount] = useState(0);
    const [supportWsOpen, setSupportWsOpen] = useState(false);
    const [sessionHistory, setSessionHistory] = useState<SupportSession[]>([]);
    const [selectedHistorySession, setSelectedHistorySession] = useState<string | null>(null);

    const wsRef = useRef<WebSocket | null>(null);
    const supportReconnectTimerRef = useRef<number | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const aiEndRef = useRef<HTMLDivElement>(null);
    const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const sessionInitializedRef = useRef(false);
    const initInFlightRef = useRef(false);
    const isOpenRef = useRef(false);
    const modeRef = useRef<"ai" | "support">("ai");
    const location = useLocation();
    const navigate = useNavigate();

    const user = getUser();
    const isAdminPage = location.pathname === "/admin";
    const isAdminUser = user?.role === "admin";
    const isLoggedIn = !!getToken();

    const shouldHideWidget = isAdminPage || isAdminUser;

    // Keep refs in sync to avoid stale closures in WebSocket handlers
    useEffect(() => {
        isOpenRef.current = isOpen;
    }, [isOpen]);

    useEffect(() => {
        modeRef.current = mode;
    }, [mode]);

    // --- AI assistant state ---
    type AiMsg =
        | { id: string; role: "user"; text: string }
        | { id: string; role: "assistant"; text: string; books?: any[] };
    const AI_WELCOME: AiMsg = {
        id: "ai-welcome",
        role: "assistant",
        text: "Merhaba! Bana doğal dilde ne aradığınızı yazın, size kitap önereyim.",
    };

    const aiStorageKey = `ai_assistant_chat_v1:${String(user?.id || "anon")}`;
    const aiPersistReadyRef = useRef(false);
    const aiSaveTimerRef = useRef<number | null>(null);

    const [aiMessages, setAiMessages] = useState<AiMsg[]>([AI_WELCOME]);
    const [aiInput, setAiInput] = useState("");
    const [aiLoading, setAiLoading] = useState(false);

    // Load persisted AI chat (so navigating to book detail and back does NOT wipe chat)
    useEffect(() => {
        if (shouldHideWidget) return;
        aiPersistReadyRef.current = false;
        try {
            const raw = localStorage.getItem(aiStorageKey);
            if (!raw) {
                aiPersistReadyRef.current = true;
                return;
            }
            const parsed = JSON.parse(raw) as { messages?: AiMsg[]; input?: string; updatedAt?: number; v?: number };
            const msgs = Array.isArray(parsed?.messages) ? parsed.messages : null;
            if (msgs && msgs.length > 0) {
                setAiMessages(msgs);
            } else {
                setAiMessages([AI_WELCOME]);
            }
            setAiInput(typeof parsed?.input === "string" ? parsed.input : "");
        } catch {
            setAiMessages([AI_WELCOME]);
            setAiInput("");
        } finally {
            aiPersistReadyRef.current = true;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [aiStorageKey, shouldHideWidget]);

    // Persist AI chat (debounced, size-limited)
    useEffect(() => {
        if (shouldHideWidget) return;
        if (!aiPersistReadyRef.current) return;

        if (aiSaveTimerRef.current) window.clearTimeout(aiSaveTimerRef.current);
        aiSaveTimerRef.current = window.setTimeout(() => {
            try {
                const capped = aiMessages.slice(-80);
                localStorage.setItem(
                    aiStorageKey,
                    JSON.stringify({
                        v: 1,
                        updatedAt: Date.now(),
                        messages: capped,
                        input: aiInput,
                    })
                );
            } catch {
                // ignore quota / serialization failures
            }
        }, 350);

        return () => {
            if (aiSaveTimerRef.current) window.clearTimeout(aiSaveTimerRef.current);
        };
    }, [aiMessages, aiInput, aiStorageKey, shouldHideWidget]);

    // Scroll to bottom when new message arrives
    const scrollToBottom = useCallback(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, []);

    useEffect(() => {
        if (shouldHideWidget) return;
        scrollToBottom();
    }, [messages, shouldHideWidget, scrollToBottom]);

    useEffect(() => {
        if (shouldHideWidget) return;
        if (!isOpen || mode !== "support") return;
        // Ensure typing indicator / last message is visible
        scrollToBottom();
    }, [isTyping, isOpen, mode, shouldHideWidget, scrollToBottom]);

    const scrollAiToBottom = useCallback(() => {
        aiEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, []);

    useEffect(() => {
        // Chat app UX: while AI panel is open, keep the view pinned to the latest message
        if (!isOpen || mode !== "ai") return;
        scrollAiToBottom();
    }, [aiMessages, aiLoading, isOpen, mode, scrollAiToBottom]);

    const checkUnreadCount = useCallback(async () => {
        try {
            const data = await supportAPI.getMyUnreadCount();
            setUnreadCount(data.unread_count);
        } catch (error) {
            console.error("Failed to get unread count:", error);
        }
    }, []);

    // Check for existing session + unread count (run when user is available and widget is closed)
    useEffect(() => {
        if (shouldHideWidget) return;
        if (user && !isOpen) {
            checkUnreadCount();
        }
    }, [shouldHideWidget, user, isOpen, checkUnreadCount]);

    // Check admin online status periodically
    useEffect(() => {
        if (shouldHideWidget) return;
        const checkAdminStatus = async () => {
            try {
                const status = await supportAPI.getAdminOnlineStatus();
                setIsAdminOnline(status.online);
            } catch (error) {
                console.error("Failed to check admin status:", error);
            }
        };

        checkAdminStatus();
        const interval = setInterval(checkAdminStatus, 30000);
        return () => clearInterval(interval);
    }, [shouldHideWidget]);

    const connectWebSocket = useCallback((sessionId: string) => {
        if (supportReconnectTimerRef.current) {
            window.clearTimeout(supportReconnectTimerRef.current);
            supportReconnectTimerRef.current = null;
        }
        if (wsRef.current) {
            wsRef.current.close();
        }

        setIsConnecting(true);
        setSupportWsOpen(false);
        const wsUrl = supportAPI.getUserWebSocketUrl(sessionId);
        console.log("User WebSocket connecting:", wsUrl);
        const ws = new WebSocket(wsUrl);

        ws.onopen = () => {
            setIsConnecting(false);
            setSupportWsOpen(true);
            console.log("User WebSocket connected successfully");
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            console.log("User WebSocket received:", data);

            switch (data.type) {
                case "admin_status":
                    setIsAdminOnline(data.online);
                    break;

                case "typing":
                    setIsTyping(data.is_typing);
                    break;

                case "messages_delivered":
                    // Admin is online -> upgrade user-sent messages to "delivered" (double tick)
                    if (data.session_id && session?.id && data.session_id !== session.id) break;
                    setMessages((prev) =>
                        prev.map((m) =>
                            m.sender_type === "user" ? { ...m, delivered: true } : m
                        )
                    );
                    break;

                case "messages_read":
                    // Admin opened chat/read -> upgrade user ticks to "read" (blue double tick)
                    if (data.session_id && session?.id && data.session_id !== session.id) break;
                    setMessages((prev) =>
                        prev.map((m) =>
                            m.sender_type === "user" ? { ...m, is_read: true, delivered: true } : m
                        )
                    );
                    break;

                case "new_message":
                    setMessages((prev) => [...prev, data.message]);
                    playNotificationSound();
                    // If widget is closed, surface it as a lightweight notification + badge
                    if (!isOpenRef.current) {
                        setUnreadCount((prev) => prev + 1);
                    }
                    break;

                case "message_sent":
                    // Our own message confirmed
                    setMessages((prev) => {
                        // Avoid duplicates
                        if (prev.find(m => m.id === data.message.id)) return prev;
                        return [...prev, data.message];
                    });
                    break;

                case "session_closed":
                    setSession((prev) => prev ? { ...prev, status: "closed" } : null);
                    break;
            }
        };

        ws.onclose = (event) => {
            setIsConnecting(false);
            setSupportWsOpen(false);
            console.log("User WebSocket disconnected, code:", event.code, "reason:", event.reason);
            // If widget is open and we're still in support mode, try a light reconnect.
            if (isOpenRef.current && modeRef.current === "support" && sessionId) {
                // Avoid reconnect storms; attempt once after short delay
                supportReconnectTimerRef.current = window.setTimeout(() => {
                    if (modeRef.current === "support") {
                        connectWebSocket(sessionId);
                    }
                }, 1200);
            }
        };

        ws.onerror = (error) => {
            console.error("User WebSocket error:", error);
            setIsConnecting(false);
            setSupportWsOpen(false);
        };

        wsRef.current = ws;
    }, []);

    const initSession = useCallback(async () => {
        // Prevent double calls without making this callback re-create when isLoading flips.
        if (initInFlightRef.current) return;
        initInFlightRef.current = true;

        setIsLoading(true);
        try {
            // Get or create session
            const sessionData = await supportAPI.createOrGetSession();
            setSession(sessionData);
            setIsAdminOnline(sessionData.is_online);

            // Load messages
            const msgs = await supportAPI.getMessages(sessionData.id);
            setMessages(msgs);
            setUnreadCount(0);

            // Connect WebSocket
            connectWebSocket(sessionData.id);
        } catch (error) {
            console.error("Failed to init session:", error);
            sessionInitializedRef.current = false; // Allow retry on error
        } finally {
            setIsLoading(false);
            initInFlightRef.current = false;
        }
    }, [connectWebSocket]);

    // Initialize support session and WebSocket when panel opens (support mode only)
    useEffect(() => {
        if (shouldHideWidget) return;
        if (mode !== "support") return;
        if (isOpen && user && !showHistory && !sessionInitializedRef.current) {
            sessionInitializedRef.current = true;
            initSession();
        }

        // Reset when panel closes
        if (!isOpen) {
            sessionInitializedRef.current = false;
            if (wsRef.current) {
                wsRef.current.close();
                wsRef.current = null;
            }
            setSupportWsOpen(false);
        }

        return () => {
            if (supportReconnectTimerRef.current) {
                window.clearTimeout(supportReconnectTimerRef.current);
                supportReconnectTimerRef.current = null;
            }
        };
    }, [isOpen, showHistory, mode, shouldHideWidget, user, initSession]);

    // Unmount safety: close websocket (avoid leaking connections)
    useEffect(() => {
        return () => {
            if (supportReconnectTimerRef.current) {
                window.clearTimeout(supportReconnectTimerRef.current);
                supportReconnectTimerRef.current = null;
            }
            if (wsRef.current) {
                wsRef.current.close();
                wsRef.current = null;
            }
        };
    }, []);

    // When switching away from support, close WS to avoid background connections.
    useEffect(() => {
        if (shouldHideWidget) return;
        if (mode !== "support" && wsRef.current) {
            wsRef.current.close(1000, "Switching to AI mode");
            wsRef.current = null;
            setSupportWsOpen(false);
        }
    }, [mode, shouldHideWidget]);

    const sendMessage = () => {
        if (!newMessage.trim()) return;
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
            toast.error("Bağlantı kurulamadı", { description: "Canlı destek bağlantısı yeniden kuruluyor, lütfen tekrar deneyin." });
            // Best-effort: reconnect
            if (session?.id) {
                connectWebSocket(session.id);
            } else {
                initSession();
            }
            return;
        }

        wsRef.current.send(JSON.stringify({
            type: "message",
            content: newMessage.trim()
        }));

        setNewMessage("");
        setIsTyping(false);
    };

    const handleTyping = (value: string) => {
        setNewMessage(value);

        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            // Send typing indicator
            wsRef.current.send(JSON.stringify({
                type: "typing",
                is_typing: value.length > 0
            }));

            // Clear previous timeout
            if (typingTimeoutRef.current) {
                clearTimeout(typingTimeoutRef.current);
            }

            // Stop typing after 2 seconds of inactivity
            if (value.length > 0) {
                typingTimeoutRef.current = setTimeout(() => {
                    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                        wsRef.current.send(JSON.stringify({
                            type: "typing",
                            is_typing: false
                        }));
                    }
                }, 2000);
            }
        }
    };

    const loadHistory = async () => {
        setShowHistory(true);
        setIsLoading(true);
        try {
            const history = await supportAPI.getSessionHistory();
            setSessionHistory(history);
        } catch (error) {
            console.error("Failed to load history:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const viewHistorySession = async (sessionId: string) => {
        setIsLoading(true);
        try {
            const msgs = await supportAPI.getMessages(sessionId);
            setMessages(msgs);
            setSelectedHistorySession(sessionId);
        } catch (error) {
            console.error("Failed to load session messages:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const backToHistory = () => {
        setSelectedHistorySession(null);
        setMessages([]);
    };

    const backToChat = () => {
        setShowHistory(false);
        setSelectedHistorySession(null);
        // Reset and reinitialize session
        sessionInitializedRef.current = false;
    };

    const sendAiMessage = async () => {
        const q = aiInput.trim();
        if (!q || aiLoading) return;

        const normalize = (s: string) =>
            s
                .toLowerCase()
                .replace(/[^\p{L}\p{N}\s]/gu, " ")
                .replace(/\s+/g, " ")
                .trim();

        const qn = normalize(q);
        const hasAny = (haystack: string, needles: string[]) => needles.some((n) => haystack.includes(n));

        const isThanks = hasAny(qn, ["tesekkur", "teşekkür", "sag ol", "sağ ol", "eyvallah", "çok iyi", "harika", "eline sağlık", "super", "süper"]);
        const isGreeting = hasAny(qn, ["merhaba", "selam", "günaydın", "iyi akşamlar", "iyi geceler", "iyi günler"]);
        const isBookIntent = hasAny(qn, [
            "kitap",
            "oner",
            "öner",
            "tavsiye",
            "roman",
            "yazar",
            "isbn",
            "kategori",
            "okuma",
            "okumak",
            "başlangıç",
            "giriş",
            "temel",
            "yapay zeka",
            "ai",
            "machine learning",
            "makine öğrenmesi",
            "derin öğrenme",
            "programlama",
            "python",
        ]);

        const id = `${Date.now()}`;
        setAiMessages((prev) => [...prev, { id: `u-${id}`, role: "user", text: q }]);
        setAiInput("");

        // Guardrails / small-talk handling (LLM-like UX without actually using an LLM)
        if (isThanks) {
            setAiMessages((prev) => [
                ...prev,
                {
                    id: `a-${id}`,
                    role: "assistant",
                    text: "Rica ederim! İstersen seviyeni (başlangıç/orta/ileri), dili (TR/EN) ve ilgi alanını yaz; sana daha nokta atışı kitaplar önereyim.",
                },
            ]);
            return;
        }

        if (isGreeting) {
            setAiMessages((prev) => [
                ...prev,
                {
                    id: `a-${id}`,
                    role: "assistant",
                    text: "Merhaba! Hangi konuda kitap arıyorsun? (Örn: 'yapay zekaya giriş', 'psikoloji', 'tarih romanı' gibi)",
                },
            ]);
            return;
        }

        if (!isBookIntent) {
            setAiMessages((prev) => [
                ...prev,
                {
                    id: `a-${id}`,
                    role: "assistant",
                    text:
                        "Ben bu uygulamada kitap önerisi ve kitap araması için varım. Bu yüzden “hava nasıl?” gibi gerçek-zamanlı genel soruları yanıtlayamam.\n\n" +
                        "Ama istersen şu şekilde sorabilirsin:\n" +
                        "- “Yapay zekaya yeni başlayan biri için 3 kitap öner”\n" +
                        "- “Python öğrenmek için Türkçe başlangıç kitabı”\n" +
                        "- “Bilim kurgu klasiklerinden öner”",
                },
            ]);
            return;
        }

        setAiLoading(true);

        // Track search signal for personalization (best-effort)
        if (isLoggedIn) {
            eventsAPI.trackSearch(q).catch(() => {});
        }

        try {
            const books = await recommendationsAPI.query({ text: q, limit: 5 });
            setAiMessages((prev) => [
                ...prev,
                {
                    id: `a-${id}`,
                    role: "assistant",
                    text: books?.length
                        ? "Bunları önerebilirim:"
                        : "Bu soruya uygun bir öneri bulamadım. İstersen daha spesifik bir soru sor (örn. 'yapay zekaya giriş, Türkçe, başlangıç seviye').",
                    books: books || [],
                },
            ]);
        } catch (e: any) {
            setAiMessages((prev) => [
                ...prev,
                {
                    id: `a-${id}`,
                    role: "assistant",
                    text: e?.response?.data?.detail || "Şu an öneri sistemine erişemedim. Lütfen tekrar deneyin.",
                },
            ]);
        } finally {
            setAiLoading(false);
        }
    };

    const autosize = (el: HTMLTextAreaElement | null) => {
        if (!el) return;
        el.style.height = "0px";
        el.style.height = `${Math.min(el.scrollHeight, 120)}px`; // cap to keep layout stable
    };

    const formatTime = (dateString: string) => {
        const date = new Date(dateString);
        return date.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
    };

    const formatDate = (dateString: string) => {
        const date = new Date(dateString);
        return date.toLocaleDateString("tr-TR", { day: "numeric", month: "short" });
    };

    // Login prompt for unauthenticated users
    const renderLoginPrompt = () => (
        <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-80 bg-card border rounded-xl shadow-2xl overflow-hidden"
        >
            <div className="p-6 text-center space-y-4">
                <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                    <MessageCircle className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Canlı Destek</h3>
                <p className="text-muted-foreground text-sm">
                    Mesajlaşmak için giriş yapınız
                </p>
                <Button onClick={() => navigate("/auth")} className="w-full gap-2">
                    <LogIn className="w-4 h-4" />
                    Giriş Yap
                </Button>
            </div>
        </motion.div>
    );

    // History view
    const renderHistory = () => (
        <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-80 sm:w-96 bg-card border rounded-xl shadow-2xl overflow-hidden flex flex-col"
            style={{ height: "500px" }}
        >
            {/* Header */}
            <div className="p-4 border-b bg-gradient-to-r from-primary/10 to-primary/5 flex items-center gap-3">
                <Button variant="ghost" size="icon" onClick={backToChat}>
                    <ChevronLeft className="w-5 h-5" />
                </Button>
                <History className="w-5 h-5 text-primary" />
                <span className="font-semibold">Görüşme Geçmişi</span>
            </div>

            {/* Content */}
            <ScrollArea className="flex-1">
                {isLoading ? (
                    <div className="flex items-center justify-center h-32">
                        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                    </div>
                ) : selectedHistorySession ? (
                    // Show messages of selected session
                    <div className="p-4 space-y-3">
                        <Button variant="ghost" size="sm" onClick={backToHistory} className="mb-2">
                            <ChevronLeft className="w-4 h-4 mr-1" />
                            Geri
                        </Button>
                        {messages.map((msg) => (
                            <div
                                key={msg.id}
                                className={cn(
                                    "flex gap-2",
                                    msg.sender_type === "user" ? "justify-end" : "justify-start"
                                )}
                            >
                                {msg.sender_type !== "user" && (
                                    <Avatar className="w-8 h-8">
                                        <AvatarFallback className={cn(
                                            "text-xs",
                                            msg.sender_type === "system" ? "bg-muted" : "bg-primary text-primary-foreground"
                                        )}>
                                            {msg.sender_type === "system" ? "S" : "A"}
                                        </AvatarFallback>
                                    </Avatar>
                                )}
                                <div
                                    className={cn(
                                        "max-w-[75%] rounded-2xl px-4 py-2 text-sm",
                                        msg.sender_type === "user"
                                            ? "bg-primary text-primary-foreground rounded-br-md"
                                            : msg.sender_type === "system"
                                                ? "bg-muted text-muted-foreground rounded-bl-md"
                                                : "bg-secondary rounded-bl-md"
                                    )}
                                >
                                    <p>{msg.content}</p>
                                    <span className="text-[10px] opacity-70 mt-1 block">
                                        {formatTime(msg.created_at)}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    // Show session list
                    <div className="p-2">
                        {sessionHistory.length === 0 ? (
                            <p className="text-center text-muted-foreground py-8">
                                Henüz görüşme geçmişiniz yok
                            </p>
                        ) : (
                            sessionHistory.map((s) => (
                                <button
                                    key={s.id}
                                    onClick={() => viewHistorySession(s.id)}
                                    className="w-full p-3 hover:bg-accent rounded-lg transition-colors text-left"
                                >
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm font-medium">
                                            {formatDate(s.created_at)}
                                        </span>
                                        <Badge variant={s.status === "active" ? "default" : "secondary"}>
                                            {s.status === "active" ? "Aktif" : "Kapandı"}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-muted-foreground truncate mt-1">
                                        {s.last_message_preview || "Mesaj yok"}
                                    </p>
                                </button>
                            ))
                        )}
                    </div>
                )}
            </ScrollArea>
        </motion.div>
    );

    const renderAiPanel = () => (
        <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-80 sm:w-96 bg-card border rounded-xl shadow-2xl overflow-hidden flex flex-col"
            style={{ height: "500px" }}
        >
            {/* Header */}
            <div className="p-4 border-b bg-gradient-to-r from-primary/10 to-primary/5">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                            <Sparkles className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-semibold">AI Asistan</h3>
                            <p className="text-xs text-muted-foreground">Doğal dilde sor, öneri al</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                            <X className="w-4 h-4" />
                        </Button>
                    </div>
                </div>

                {/* Mode Switch */}
                <div className="mt-3 grid grid-cols-2 gap-2">
                    <Button
                        variant={mode === "ai" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setMode("ai")}
                    >
                        AI Asistan
                    </Button>
                    <Button
                        variant={mode === "support" ? "default" : "outline"}
                        size="sm"
                        onClick={() => {
                            if (!user) {
                                toast.info("Canlı destek için giriş yapmalısınız.");
                                navigate("/auth");
                                return;
                            }
                            setMode("support");
                        }}
                    >
                        Canlı Destek
                    </Button>
                </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
                <div className="space-y-3">
                    {aiMessages.map((m) => (
                        <div key={m.id} className={cn("flex gap-2", m.role === "user" ? "justify-end" : "justify-start")}>
                            {m.role !== "user" && (
                                <Avatar className="w-8 h-8">
                                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">AI</AvatarFallback>
                                </Avatar>
                            )}
                            <div className={cn("max-w-[75%] rounded-2xl px-4 py-2 text-sm", m.role === "user" ? "bg-primary text-primary-foreground rounded-br-md" : "bg-muted rounded-bl-md")}>
                                <p>{m.text}</p>
                                {"books" in m && m.books && m.books.length > 0 && (
                                    <div className="mt-3 space-y-2">
                                        {m.books.map((b: any) => (
                                            <Link
                                                key={b.id}
                                                to={`/books/${b.id}`}
                                                className="block rounded-lg border border-border bg-card/60 hover:bg-card transition-colors p-2"
                                                onClick={() => {
                                                    if (!isLoggedIn) return;
                                                    eventsAPI.trackRecommendationClick(b.id).catch(() => {});
                                                }}
                                            >
                                                <div className="text-sm font-medium line-clamp-1">{b.title}</div>
                                                <div className="text-xs text-muted-foreground line-clamp-1">{b.author}</div>
                                                <div className="flex items-center justify-between mt-1">
                                                    <span className="text-[10px] text-muted-foreground">{b.category || "Genel"}</span>
                                                    <span className="text-[10px] text-muted-foreground">{b.score_pct ?? Math.round((b.score || 0) * 100)}%</span>
                                                </div>
                                            </Link>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}

                    {aiLoading && (
                        <div className="flex items-center gap-2 text-muted-foreground text-sm">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Düşünüyorum...
                        </div>
                    )}
                    <div ref={aiEndRef} />
                </div>
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t">
                <form
                    onSubmit={(e) => {
                        e.preventDefault();
                        sendAiMessage();
                    }}
                    className="flex gap-2"
                >
                    <Textarea
                        value={aiInput}
                        onChange={(e) => {
                            setAiInput(e.target.value);
                            autosize(e.currentTarget);
                        }}
                        onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                sendAiMessage();
                            }
                        }}
                        placeholder="Örn: Yapay zekaya yeni başlayan birine kitap öner..."
                        className="flex-1 resize-none min-h-[40px] max-h-[120px]"
                        disabled={aiLoading}
                        rows={1}
                    />
                    <Button type="submit" size="icon" disabled={!aiInput.trim() || aiLoading}>
                        <Send className="w-4 h-4" />
                    </Button>
                </form>
            </div>
        </motion.div>
    );

    // Main chat panel (support)
    const renderChatPanel = () => (
        <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-80 sm:w-96 bg-card border rounded-xl shadow-2xl overflow-hidden flex flex-col"
            style={{ height: "500px" }}
        >
            {/* Header */}
            <div className="p-4 border-b bg-gradient-to-r from-primary/10 to-primary/5">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="relative">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                                <MessageCircle className="w-5 h-5 text-primary" />
                            </div>
                            <div
                                className={cn(
                                    "absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-card",
                                    isAdminOnline ? "bg-green-500" : "bg-gray-400"
                                )}
                            />
                        </div>
                        <div>
                            <h3 className="font-semibold">Canlı Destek</h3>
                            <p className="text-xs text-muted-foreground">
                                {isConnecting ? (
                                    "Bağlanıyor..."
                                ) : isAdminOnline ? (
                                    <span className="text-green-600">Çevrimiçi</span>
                                ) : (
                                    "Mesajınız kaydedildi"
                                )}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setMode("ai")}
                            className="hidden sm:inline-flex"
                        >
                            <Sparkles className="w-4 h-4 mr-2" />
                            AI Asistan
                        </Button>
                        <Button variant="ghost" size="icon" onClick={loadHistory}>
                            <History className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                            <X className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
                {isLoading ? (
                    <div className="flex items-center justify-center h-full">
                        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                    </div>
                ) : (
                    <div className="space-y-3">
                        {messages.map((msg) => (
                            <div
                                key={msg.id}
                                className={cn(
                                    "flex gap-2",
                                    msg.sender_type === "user" ? "justify-end" : "justify-start"
                                )}
                            >
                                {msg.sender_type !== "user" && (
                                    <Avatar className="w-8 h-8">
                                        <AvatarFallback className={cn(
                                            "text-xs",
                                            msg.sender_type === "system" ? "bg-muted" : "bg-primary text-primary-foreground"
                                        )}>
                                            {msg.sender_type === "system" ? "S" : "A"}
                                        </AvatarFallback>
                                    </Avatar>
                                )}
                                <div
                                    className={cn(
                                        "max-w-[75%] rounded-2xl px-4 py-2 text-sm",
                                        msg.sender_type === "user"
                                            ? "bg-primary text-primary-foreground rounded-br-md"
                                            : msg.sender_type === "system"
                                                ? "bg-muted text-muted-foreground rounded-bl-md"
                                                : "bg-secondary rounded-bl-md"
                                    )}
                                >
                                    <p>{msg.content}</p>
                                    <div className="flex items-center gap-1 justify-end mt-1">
                                        <span className="text-[10px] opacity-70">
                                            {formatTime(msg.created_at)}
                                        </span>
                                        {msg.sender_type === "user" && (
                                            msg.is_read ? (
                                                <CheckCheck className="w-3 h-3 text-sky-500" />
                                            ) : msg.delivered ? (
                                                <CheckCheck className="w-3 h-3 opacity-70" />
                                            ) : (
                                                <Check className="w-3 h-3 opacity-70" />
                                            )
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}

                        {/* Typing indicator */}
                        {isTyping && (
                            <div className="flex items-center gap-2">
                                <Avatar className="w-8 h-8">
                                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                                        A
                                    </AvatarFallback>
                                </Avatar>
                                <div className="bg-secondary rounded-2xl rounded-bl-md px-4 py-2">
                                    <div className="flex gap-1">
                                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="h-10" />
                        <div ref={messagesEndRef} />
                    </div>
                )}
            </ScrollArea>

            {/* Input */}
            {session?.status === "closed" ? (
                <div className="p-4 border-t bg-muted/50 text-center">
                    <p className="text-sm text-muted-foreground">Bu görüşme kapatıldı</p>
                    <Button variant="link" size="sm" onClick={initSession}>
                        Yeni görüşme başlat
                    </Button>
                </div>
            ) : (
                <div className="p-4 border-t">
                    <form
                        onSubmit={(e) => {
                            e.preventDefault();
                            sendMessage();
                        }}
                        className="flex gap-2"
                    >
                        <Textarea
                            value={newMessage}
                            onChange={(e) => {
                                handleTyping(e.target.value);
                                autosize(e.currentTarget);
                            }}
                            onKeyDown={(e) => {
                                if (e.key === "Enter" && !e.shiftKey) {
                                    e.preventDefault();
                                    sendMessage();
                                }
                            }}
                            placeholder="Mesajınızı yazın..."
                            className="flex-1 resize-none min-h-[40px] max-h-[120px]"
                            // Important UX: allow typing even while connecting; only disable the send action.
                            disabled={false}
                            rows={1}
                        />
                        <Button
                            type="submit"
                            size="icon"
                            disabled={!newMessage.trim() || isConnecting || !supportWsOpen}
                        >
                            <Send className="w-4 h-4" />
                        </Button>
                    </form>
                </div>
            )}
        </motion.div>
    );

    if (shouldHideWidget) return null;

    return (
        <div className="fixed bottom-6 right-6 z-50">
            <AnimatePresence>
                {isOpen && (
                    mode === "ai"
                        ? renderAiPanel()
                        : user
                        ? showHistory
                            ? renderHistory()
                            : renderChatPanel()
                        : renderLoginPrompt()
                )}
            </AnimatePresence>

            {/* Floating button */}
            <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsOpen(!isOpen)}
                className={cn(
                    "relative w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-colors",
                    isOpen
                        ? "bg-secondary text-secondary-foreground"
                        : "bg-primary text-primary-foreground hover:bg-primary/90"
                )}
            >
                {isOpen ? (
                    <X className="w-6 h-6" />
                ) : (
                    <>
                        <MessageCircle className="w-6 h-6" />
                        {unreadCount > 0 && (
                            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                                {unreadCount > 9 ? "9+" : unreadCount}
                            </span>
                        )}
                    </>
                )}
            </motion.button>
        </div>
    );
}
